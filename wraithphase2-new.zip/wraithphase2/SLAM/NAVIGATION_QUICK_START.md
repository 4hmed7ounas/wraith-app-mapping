# 🚀 Quick Start - Auto-Waypoint Navigation

**5-Minute Guide to Label-Based Navigation**

---

## What You Get

✅ **Automatic waypoint generation** during mapping (Point_A, Point_B, Point_C...)
✅ **Simple navigation commands**: `go_to Point_B`
✅ **No manual clicking** in RViz to create waypoints
✅ **No coordinate math** - just use labels!

---

## Phase 1: Create Map with Auto-Waypoints (One Time)

### Terminal 1: Start Mapping
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
```

### Terminal 2: Activate SLAM
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

### Watch Waypoints Being Created
You'll see:
```
[INFO] ✓ Created Point_A at (0.00, 0.00) [start]
[INFO] ✓ Created Point_B at (2.30, 1.50) [16.2s elapsed]
[INFO] ✓ Created Point_C at (4.10, 3.20) [2.7m traveled]
...
```

**Waypoint created every:**
- 15 seconds, OR
- 2.5 meters traveled

### Save Everything (After 3-5 Minutes)
```bash
# Stop mapping (Ctrl+C in Terminal 1)

# Terminal 2: Save map + waypoints
python3 src/slam_robot/scripts/save_map.py my_office
```

**Creates:**
- `~/slam_maps/my_office.pgm` (map image)
- `~/slam_maps/my_office.yaml` (map metadata)
- `~/slam_maps/my_office_waypoints.yaml` (**auto-generated waypoints!**)

---

## Phase 2: Navigate Using Labels (Daily Use)

### Terminal 1: Launch Navigation
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_office
```

### Terminal 2: Set Starting Position

**Option A - RViz (Recommended):**
```bash
rviz2
```
1. Add display: **Map** (topic: `/map`)
2. Add display: **LaserScan** (topic: `/scan`)
3. Click **"2D Pose Estimate"** button
4. Click where robot is, drag to set orientation

**Option B - Command (if robot starts at 0,0):**
```bash
ros2 topic pub --once /initialpose geometry_msgs/msg/PoseWithCovarianceStamped '{
  header: {frame_id: "map"},
  pose: {pose: {position: {x: 0.0, y: 0.0}, orientation: {w: 1.0}}}
}'
```

### Terminal 3: Navigate!

**List available waypoints:**
```bash
ros2 run slam_robot list_waypoints
```

Output:
```
Point_A      → (  0.00,   0.00)
Point_B      → (  2.30,   1.50)
Point_C      → (  4.10,   3.20)
Point_D      → (  6.20,   2.80)
...
```

**Navigate to any point:**
```bash
ros2 run slam_robot go_to Point_B
ros2 run slam_robot go_to Point_D
ros2 run slam_robot go_to Point_A  # Return home
```

**That's it!** Robot navigates autonomously, avoids obstacles, and reaches the labeled waypoint.

---

## 🎯 Example Session

```bash
# === MAPPING (One Time) ===
Terminal 1: ros2 launch slam_robot mapping.launch.py
Terminal 2: ros2 lifecycle set /slam_toolbox configure
Terminal 2: ros2 lifecycle set /slam_toolbox activate
# ... wait 3-5 minutes while robot explores ...
Terminal 1: Ctrl+C
Terminal 2: python3 src/slam_robot/scripts/save_map.py office_floor1

# === NAVIGATION (Daily) ===
Terminal 1: ros2 launch slam_robot navigation.launch.py map:=office_floor1
Terminal 2: rviz2  # Set initial pose
Terminal 3: ros2 run slam_robot list_waypoints
Terminal 3: ros2 run slam_robot go_to Point_C
# Robot drives to Point_C automatically! ✓
```

---

## 🔧 Adjust Waypoint Density

Edit `slam_ws/src/slam_robot/launch/mapping.launch.py`:

```python
auto_waypoint_generator = Node(
    parameters=[{
        'waypoint_interval_time': 15.0,   # ← Change this (seconds)
        'waypoint_interval_distance': 2.5, # ← Change this (meters)
    }]
)
```

**More waypoints:**
- Time: `10.0` seconds
- Distance: `2.0` meters

**Fewer waypoints:**
- Time: `30.0` seconds
- Distance: `5.0` meters

Then rebuild:
```bash
cd ~/SLAM/slam_ws
colcon build --packages-select slam_robot
```

---

## 📋 Files Created

### Your Workspace
```
~/SLAM/
├── NAVIGATION_GUIDE.md           ← Full documentation
├── NAVIGATION_QUICK_START.md     ← This file
└── slam_ws/
    └── src/slam_robot/
        ├── slam_robot/
        │   ├── auto_waypoint_generator.py   (NEW)
        │   └── waypoint_navigator.py        (NEW)
        ├── scripts/
        │   ├── go_to.py                     (NEW)
        │   └── list_waypoints.py            (NEW)
        ├── launch/
        │   └── navigation.launch.py         (NEW)
        └── config/
            ├── amcl_params.yaml             (NEW)
            └── nav2_params.yaml             (NEW)
```

### Your Maps
```
~/slam_maps/
├── my_office.pgm
├── my_office.yaml
└── my_office_waypoints.yaml    ← Auto-generated!
```

---

## 🐛 Common Issues

### "No waypoints created during mapping"
**Fix:** Make sure SLAM is activated:
```bash
ros2 lifecycle set /slam_toolbox activate
```

### "Unknown waypoint: Point_B"
**Fix:** Check map name matches:
```bash
# List files
ls ~/slam_maps/

# Launch with correct name
ros2 launch slam_robot navigation.launch.py map:=<actual_name>
```

### "Robot doesn't move during navigation"
**Fix:**
1. Check motor controller is running: `ros2 node list | grep motor`
2. Set initial pose in RViz (2D Pose Estimate)
3. Check velocity commands: `ros2 topic echo /cmd_vel`

### "AMCL particles scattered everywhere"
**Fix:**
1. Set initial pose more accurately in RViz
2. Drive robot around a bit to help AMCL converge
3. Make sure you're using the correct map

---

## 📚 Full Documentation

See **NAVIGATION_GUIDE.md** for:
- Detailed architecture explanation
- Configuration parameters
- Troubleshooting guide
- Performance tuning
- Advanced features

---

## ✅ Summary

**Before:** Manual waypoint creation in RViz, remembering coordinates like (2.34, -5.67, 1.23)

**Now:**
```bash
# Mapping creates Point_A, Point_B, Point_C... automatically
ros2 run slam_robot go_to Point_B  # Just this!
```

**Benefits:**
- 🎯 User-friendly labels instead of coordinates
- ⚡ Fully automatic waypoint generation
- 🤖 Complete autonomous navigation
- 🔄 Reusable across sessions

---

*Wraith Robot - Auto-Waypoint Navigation System*
*Built with ROS2, Nav2, AMCL, and SLAM Toolbox*
