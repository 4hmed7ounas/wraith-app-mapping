# Manual Control Mode for SLAM Mapping

## Overview

The mapping system now supports **TWO control modes**:

1. **AUTO mode** - Robot explores autonomously (original behavior)
2. **MANUAL mode** - Control robot via HTTP API from any device

## Quick Start

### Option 1: Autonomous Mapping (Default)

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=auto
```

### Option 2: Manual Control Mapping

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=manual
```

When you start manual mode, you'll see:
```
============================================================
Manual Control Server Starting...
============================================================
Robot IP: 192.168.1.100
Control URL: http://192.168.1.100:5000/control
============================================================
Available commands:
  forward_start, forward_stop
  backward_start, backward_stop
  left_start, left_stop
  right_start, right_stop
  speed+, speed- (adjust speed)
  auto_start, auto_stop (autonomous mode)
============================================================
```

## Controlling the Robot

From **any device on your network** (laptop, phone, another terminal), use curl:

```bash
# Replace <robot-ip> with the IP shown at startup

# Move forward
curl -X POST http://<robot-ip>:5000/control -d "forward_start"
sleep 2
curl -X POST http://<robot-ip>:5000/control -d "forward_stop"

# Turn left
curl -X POST http://<robot-ip>:5000/control -d "left_start"
sleep 1
curl -X POST http://<robot-ip>:5000/control -d "left_stop"

# Turn right
curl -X POST http://<robot-ip>:5000/control -d "right_start"
sleep 1
curl -X POST http://<robot-ip>:5000/control -d "right_stop"

# Move backward
curl -X POST http://<robot-ip>:5000/control -d "backward_start"
sleep 2
curl -X POST http://<robot-ip>:5000/control -d "backward_stop"

# Increase speed
curl -X POST http://<robot-ip>:5000/control -d "speed+"

# Decrease speed
curl -X POST http://<robot-ip>:5000/control -d "speed-"
```

## Full Mapping Workflow (Manual Mode)

**Terminal 1: Start mapping**
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=manual
# Note the robot IP from the output
```

**Terminal 2: Activate SLAM**
```bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

**Terminal 3: Control robot**
```bash
# Drive the robot around to explore your space
curl -X POST http://192.168.1.100:5000/control -d "forward_start"
# ... drive around for 3-5 minutes
curl -X POST http://192.168.1.100:5000/control -d "forward_stop"
```

**Terminal 4: Save map**
```bash
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_office_map
```

## Advanced Features

### Toggle Autonomous Mode During Manual Session

You can switch to autonomous mode without restarting:

```bash
# Enable autonomous obstacle avoidance
curl -X POST http://<robot-ip>:5000/control -d "auto_start"

# The robot now explores autonomously

# Return to manual control
curl -X POST http://<robot-ip>:5000/control -d "auto_stop"
```

### Check Obstacle Distance

```bash
curl http://<robot-ip>:5000/get_distance
# Returns: {"distance": 45.23}  (in centimeters)
```

### Get Robot IP

```bash
curl http://<robot-ip>:5000/get_ip
# Returns: {"ip": "192.168.1.100"}
```

## Available HTTP Endpoints

| Method | Endpoint | Data | Description |
|--------|----------|------|-------------|
| GET | `/` | - | Check server status |
| GET | `/get_ip` | - | Get robot's IP address |
| GET | `/get_distance` | - | Get ultrasonic sensor reading (cm) |
| POST | `/control` | command | Send control command |

## All Control Commands

### Movement
- `forward_start` - Start moving forward
- `forward_stop` - Stop forward movement
- `backward_start` - Start moving backward
- `backward_stop` - Stop backward movement
- `left_start` - Start turning left (in-place rotation)
- `left_stop` - Stop turning left
- `right_start` - Start turning right (in-place rotation)
- `right_stop` - Stop turning right

### Speed Control
- `speed+` - Increase speed by 10% (max 100%)
- `speed-` - Decrease speed by 10% (min 0%)

### Autonomous Toggle
- `auto_start` - Enable autonomous obstacle avoidance
- `auto_stop` - Disable autonomous mode

## Creating a Control Script

You can create a simple script for easier control:

```bash
#!/bin/bash
# control_robot.sh

ROBOT_IP="192.168.1.100"  # Change to your robot's IP

case "$1" in
    f)  curl -s -X POST http://$ROBOT_IP:5000/control -d "forward_start" ;;
    b)  curl -s -X POST http://$ROBOT_IP:5000/control -d "backward_start" ;;
    l)  curl -s -X POST http://$ROBOT_IP:5000/control -d "left_start" ;;
    r)  curl -s -X POST http://$ROBOT_IP:5000/control -d "right_start" ;;
    s)  curl -s -X POST http://$ROBOT_IP:5000/control -d "forward_stop"
        curl -s -X POST http://$ROBOT_IP:5000/control -d "backward_stop"
        curl -s -X POST http://$ROBOT_IP:5000/control -d "left_stop"
        curl -s -X POST http://$ROBOT_IP:5000/control -d "right_stop" ;;
    +)  curl -s -X POST http://$ROBOT_IP:5000/control -d "speed+" ;;
    -)  curl -s -X POST http://$ROBOT_IP:5000/control -d "speed-" ;;
    a)  curl -s -X POST http://$ROBOT_IP:5000/control -d "auto_start" ;;
    *)  echo "Usage: $0 {f|b|l|r|s|+|-|a}"
        echo "  f - forward, b - backward, l - left, r - right"
        echo "  s - stop, + - speed up, - - slow down, a - auto mode"
        exit 1 ;;
esac
```

Usage:
```bash
chmod +x control_robot.sh
./control_robot.sh f  # Forward
./control_robot.sh s  # Stop
./control_robot.sh l  # Left
```

## Web Interface (Optional)

You can create a simple HTML page to control the robot:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Robot Control</title>
    <style>
        button { font-size: 20px; padding: 20px; margin: 5px; }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; max-width: 400px; }
    </style>
</head>
<body>
    <h1>Robot Control</h1>
    <div class="grid">
        <button onclick="sendCommand('forward_start')">▲ Forward</button>
        <button onclick="sendCommand('left_start')">◀ Left</button>
        <button onclick="sendCommand('right_start')">▶ Right</button>
        <button onclick="sendCommand('backward_start')">▼ Backward</button>
        <button onclick="sendCommand('forward_stop')" style="background:red">STOP</button>
        <button onclick="sendCommand('speed+')">Speed +</button>
        <button onclick="sendCommand('speed-')">Speed -</button>
        <button onclick="sendCommand('auto_start')">Auto Mode</button>
    </div>
    <script>
        const ROBOT_IP = '192.168.1.100';  // Change this!

        function sendCommand(cmd) {
            fetch(`http://${ROBOT_IP}:5000/control`, {
                method: 'POST',
                body: cmd
            }).then(r => r.text()).then(console.log);
        }

        // Auto-stop on key release
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowUp') sendCommand('forward_start');
            if (e.key === 'ArrowDown') sendCommand('backward_start');
            if (e.key === 'ArrowLeft') sendCommand('left_start');
            if (e.key === 'ArrowRight') sendCommand('right_start');
        });

        document.addEventListener('keyup', (e) => {
            if (e.key.startsWith('Arrow')) {
                sendCommand('forward_stop');
                sendCommand('backward_stop');
                sendCommand('left_stop');
                sendCommand('right_stop');
            }
        });
    </script>
</body>
</html>
```

Save as `robot_control.html` and open in your browser. Use arrow keys or click buttons!

## Troubleshooting

**Can't connect to robot:**
- Check robot IP with `curl http://<robot-ip>:5000/get_ip`
- Ensure both devices are on same network
- Check firewall isn't blocking port 5000

**Robot doesn't move:**
- Check GPIO permissions: `sudo usermod -a -G gpio $USER`
- Verify motors enabled (should see message in Terminal 1)
- Try increasing speed: `curl -X POST http://<ip>:5000/control -d "speed+"`

**Commands not working:**
- Ensure you're using POST method for `/control` endpoint
- Check command spelling (case-sensitive)
- View server logs in Terminal 1 for errors

## Comparison: Auto vs Manual Mode

| Feature | Auto Mode | Manual Mode |
|---------|-----------|-------------|
| Robot Movement | Autonomous exploration | HTTP API control |
| User Control | None | Full control via HTTP |
| Best For | Quick mapping, testing | Precise mapping, demonstrations |
| Network Required | No | Yes (for remote control) |
| SLAM Active | Yes | Yes |
| Waypoints Generated | Yes | Yes |
| Speed Adjustable | No (50% fixed) | Yes (0-100%) |
| Remote Control | No | Yes |

## Summary

Manual mode gives you **full control** over the robot during SLAM mapping via a simple HTTP API. This is perfect for:
- Precise room mapping
- Demonstrations
- Remote operation
- Areas where autonomous navigation is difficult
- Testing and debugging

All SLAM features (mapping, waypoint generation, map saving) work identically in both modes!

---

*Created for Wraith Robot SLAM System*
*Manual Control Mode v1.0*
