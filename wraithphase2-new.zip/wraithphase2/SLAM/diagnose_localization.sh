#!/bin/bash
# Localization Diagnostic Script
# Run this while navigation is active to check localization health

echo "======================================================================"
echo "LOCALIZATION DIAGNOSTICS"
echo "======================================================================"
echo ""

echo "1. Checking AMCL Particle Count..."
PARTICLE_COUNT=$(ros2 topic echo /particlecloud --field poses --once 2>/dev/null | grep -c "position:")
echo "   Particles: $PARTICLE_COUNT"
if [ "$PARTICLE_COUNT" -gt 1000 ]; then
    echo "   ✓ Good particle count"
else
    echo "   ⚠ Low particle count - may indicate poor localization"
fi
echo ""

echo "2. Checking Odometry Stability (5 second test)..."
echo "   Robot should be STATIONARY..."
ros2 topic echo /odom --field pose.pose.position --once > /tmp/odom1.txt
sleep 5
ros2 topic echo /odom --field pose.pose.position --once > /tmp/odom2.txt
echo "   Start: $(cat /tmp/odom1.txt)"
echo "   End:   $(cat /tmp/odom2.txt)"
echo "   (Values should be nearly identical if robot is still)"
echo ""

echo "3. Checking AMCL Pose..."
ros2 topic echo /amcl_pose --field pose.pose.position --once
echo ""

echo "4. Checking Transform Tree..."
echo "   Running tf2_tools..."
timeout 3 ros2 run tf2_tools view_frames 2>/dev/null && echo "   ✓ TF tree saved to frames.pdf" || echo "   ⚠ Could not generate TF tree"
echo ""

echo "5. Checking Laser Scan..."
SCAN_COUNT=$(ros2 topic echo /scan --field ranges --once 2>/dev/null | grep -o "[0-9]\+\.[0-9]\+" | wc -l)
echo "   Scan points: $SCAN_COUNT"
if [ "$SCAN_COUNT" -gt 100 ]; then
    echo "   ✓ Lidar working well"
else
    echo "   ⚠ Low scan points - check lidar"
fi
echo ""

echo "6. Checking Localization Topics..."
echo "   /amcl_pose frequency:"
timeout 5 ros2 topic hz /amcl_pose 2>/dev/null | grep "average rate" || echo "   ⚠ No AMCL poses published"
echo ""
echo "   /particlecloud frequency:"
timeout 5 ros2 topic hz /particlecloud 2>/dev/null | grep "average rate" || echo "   ⚠ No particles published"
echo ""

echo "======================================================================"
echo "DIAGNOSTICS COMPLETE"
echo "======================================================================"
echo ""
echo "RECOMMENDATIONS:"
echo "- Particles should be > 1000 and clustered in RViz"
echo "- Odometry should be stable when robot is stationary"
echo "- AMCL pose should update at ~2Hz"
echo "- If robot model jumps in RViz, increase particle count or check odometry"
echo ""
