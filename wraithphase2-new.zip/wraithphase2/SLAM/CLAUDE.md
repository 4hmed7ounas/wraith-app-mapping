# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

This is a ROS2 Jazzy SLAM and autonomous navigation system for a differential drive robot with:
- RPLidar A2 M12 for mapping
- MPU6050 IMU for orientation
- Wheel encoders (500 PPR) for odometry
- BTS7960 motor drivers
- HC-SR04 ultrasonic sensor for obstacle avoidance
- Automatic waypoint generation during mapping
- Label-based navigation (Point_A, Point_B, etc.)

**Hardware Platform:** Raspberry Pi with GPIO peripherals
**Robot Name:** Wraith Robot

## Build Commands

```bash
# Build the workspace
cd ~/SLAM/slam_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash

# Build single package (faster during development)
colcon build --packages-select slam_robot --symlink-install
```

**Important:** Always use `--symlink-install` to avoid rebuilding for Python changes.

## Running the System

### Mapping Phase (SLAM)

The mapping system supports TWO control modes:

**Option 1: Autonomous Mapping (default)**
```bash
# Terminal 1: Start mapping with autonomous exploration
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=auto

# Terminal 2: Activate SLAM (required after launch)
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# Terminal 3: Save map after exploration (3-5 minutes)
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_map_name
```

**Option 2: Manual Control via HTTP**
```bash
# Terminal 1: Start mapping with manual control server
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=manual

# Terminal 2: Activate SLAM (required after launch)
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# Terminal 3: Control the robot via HTTP (from any device on network)
# Get robot IP from Terminal 1 output, then use curl or web interface
curl -X POST http://<robot-ip>:5000/control -d "forward_start"
curl -X POST http://<robot-ip>:5000/control -d "forward_stop"
curl -X POST http://<robot-ip>:5000/control -d "left_start"
curl -X POST http://<robot-ip>:5000/control -d "right_start"
curl -X POST http://<robot-ip>:5000/control -d "speed+"
curl -X POST http://<robot-ip>:5000/control -d "auto_start"  # Toggle autonomous mode

# Terminal 4: Save map when done
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_map_name
```

### Navigation Phase
```bash
# Terminal 1: Launch navigation with saved map
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_map_name

# Terminal 2: Set initial pose in RViz (required for AMCL)
rviz2
# Use "2D Pose Estimate" button to set robot location

# Terminal 3: Navigate to waypoints
ros2 run slam_robot list_waypoints
ros2 run slam_robot go_to Point_B
```

## Hardware Permissions

Run these after reboot or when facing permission errors:

```bash
# RPLidar
sudo chmod 666 /dev/ttyUSB0

# I2C (for IMU)
sudo chmod 666 /dev/i2c-1

# GPIO (for motors, encoders, ultrasonic)
sudo usermod -a -G gpio $USER  # requires logout
```

## Architecture

### Two-Phase System

**Phase 1 - Mapping:**
- Robot explores autonomously using obstacle avoidance
- SLAM Toolbox builds 2D occupancy grid map
- Auto-waypoint generator creates labeled waypoints (Point_A, Point_B...) every 15 seconds OR 2.5 meters
- Map and waypoints saved to `~/slam_maps/` on shutdown

**Phase 2 - Navigation:**
- AMCL localizes robot on saved map
- Nav2 plans paths to goal locations
- Waypoint navigator translates labels to coordinates
- User commands like `go_to Point_B` trigger autonomous navigation

### Node Architecture

**Sensor Nodes:**
- `rplidar_node` - Publishes `/scan` (LaserScan)
- `imu_publisher` - Publishes `/imu/data_raw` (MPU6050)
- `odometry_publisher` - Publishes `/odom` from wheel encoders
- `imu_filter_madgwick_node` - Filters IMU to `/imu/data`
- `ekf_filter_node` - Fuses odometry + IMU to `/odometry/filtered`

**Control Nodes:**
- `motor_controller` - Subscribes to `/cmd_vel`, controls BTS7960 motors via GPIO
- `obstacle_avoidance` - Publishes `/cmd_vel` for autonomous exploration (auto mode only)
- `manual_control_server` - HTTP API for manual robot control (manual mode only)

**SLAM/Navigation Nodes:**
- `slam_toolbox` - SLAM mapping (mapping phase)
- `auto_waypoint_generator` - Creates labeled waypoints during mapping
- `map_server` - Serves saved map (navigation phase)
- `amcl` - Localization on saved map (navigation phase)
- `nav2` stack - Path planning and control (navigation phase)
- `waypoint_navigator` - Translates waypoint labels to navigation goals

### TF Tree
```
map → odom → base_footprint → base_link
                                  ├─ laser
                                  ├─ imu_link
                                  ├─ left_wheel
                                  └─ right_wheel
```

**Critical:**
- In mapping: `slam_toolbox` provides `map→odom`
- In navigation: `amcl` provides `map→odom`
- `ekf_filter_node` always provides `odom→base_footprint`

### Key Topics

| Topic | Type | Publisher | Purpose |
|-------|------|-----------|---------|
| `/scan` | LaserScan | rplidar_node | Lidar data for SLAM/obstacles |
| `/odom` | Odometry | odometry_publisher | Raw wheel encoder odometry |
| `/imu/data` | Imu | imu_filter | Filtered IMU orientation |
| `/odometry/filtered` | Odometry | ekf_filter_node | Fused odometry (odom+IMU) |
| `/cmd_vel` | Twist | obstacle_avoidance OR nav2 | Velocity commands for motors |
| `/map` | OccupancyGrid | slam_toolbox OR map_server | Occupancy grid map |
| `/goal_pose` | PoseStamped | waypoint_navigator | Navigation goals |

## File Structure

```
slam_ws/src/slam_robot/
├── slam_robot/                    # Python nodes
│   ├── motor_controller.py       # BTS7960 motor control via GPIO
│   ├── odometry_publisher.py     # Wheel encoder odometry
│   ├── imu_publisher.py          # MPU6050 IMU reading
│   ├── obstacle_avoidance.py     # Random exploration with obstacle detection (auto mode)
│   ├── manual_control_server.py  # Flask HTTP API for manual control (manual mode)
│   ├── auto_waypoint_generator.py # Automatic waypoint labeling during mapping
│   └── waypoint_navigator.py     # Label-based navigation interface
├── scripts/
│   ├── save_map.py               # Save map+waypoints CLI
│   ├── go_to.py                  # Navigate to waypoint CLI
│   └── list_waypoints.py         # List available waypoints CLI
├── launch/
│   ├── mapping.launch.py         # Full mapping stack with auto-waypoints
│   ├── navigation.launch.py      # Full navigation stack with AMCL+Nav2
│   ├── rplidar.launch.py         # RPLidar driver only
│   └── slam_toolbox.launch.py    # SLAM Toolbox only
├── config/
│   ├── slam_toolbox_params.yaml  # SLAM configuration
│   ├── amcl_params.yaml          # Localization parameters
│   └── nav2_params.yaml          # Navigation stack parameters
├── urdf/
│   └── robot.urdf                # Robot model (wheel base, sensor positions)
├── setup.py                      # Package installation/entry points
└── package.xml                   # ROS2 package dependencies
```

## Development Notes

### When Modifying Python Nodes

Python nodes are in `slam_robot/` and registered in `setup.py` entry_points. After changes:
- If using `--symlink-install`: Changes take effect immediately
- If not: Must rebuild with `colcon build`

### When Adding New Nodes

1. Create Python file in `slam_robot/`
2. Add entry point in `setup.py`:
   ```python
   'console_scripts': [
       'my_new_node = slam_robot.my_new_node:main',
   ]
   ```
3. Rebuild: `colcon build --packages-select slam_robot`

### When Modifying Launch Files

Launch files are in `launch/` and installed via `setup.py` data_files. With `--symlink-install`, changes are immediate. Without it, must rebuild.

### When Modifying Config Files

Config files in `config/` are installed to `install/slam_robot/share/slam_robot/config/`. With `--symlink-install`, changes are immediate.

### GPIO Pin Assignments (Reference)

From hardware setup:
- Motors: BTS7960 drivers (various GPIO pins)
- Encoders: GPIO 17, 4, 19, 13
- Ultrasonic: GPIO 20 (trigger), 21 (echo)
- Servo: GPIO 12

**Don't modify pin assignments without checking physical wiring.**

## Manual Control HTTP API

When using `control_mode:=manual`, the robot starts an HTTP server on port 5000. You can control it from any device on the network.

### Available Commands

**Movement Commands:**
- `forward_start` - Start moving forward at current speed
- `forward_stop` - Stop forward movement
- `backward_start` - Start moving backward
- `backward_stop` - Stop backward movement
- `left_start` - Start turning left
- `left_stop` - Stop turning left
- `right_start` - Start turning right
- `right_stop` - Stop turning right

**Speed Control:**
- `speed+` - Increase speed by 10% (max 100%)
- `speed-` - Decrease speed by 10% (min 0%)

**Autonomous Mode Toggle:**
- `auto_start` - Enable autonomous obstacle avoidance
- `auto_stop` - Disable autonomous mode, return to manual control

**Information Endpoints:**
- `GET /` - Check server status
- `GET /get_ip` - Get robot's IP address
- `GET /get_distance` - Get ultrasonic sensor reading (cm)

### Usage Examples

```bash
# Get robot IP
curl http://<robot-ip>:5000/get_ip

# Move forward
curl -X POST http://<robot-ip>:5000/control -d "forward_start"
sleep 2
curl -X POST http://<robot-ip>:5000/control -d "forward_stop"

# Turn right
curl -X POST http://<robot-ip>:5000/control -d "right_start"
sleep 1
curl -X POST http://<robot-ip>:5000/control -d "right_stop"

# Increase speed and move
curl -X POST http://<robot-ip>:5000/control -d "speed+"
curl -X POST http://<robot-ip>:5000/control -d "forward_start"

# Enable autonomous mode during manual mapping session
curl -X POST http://<robot-ip>:5000/control -d "auto_start"

# Check obstacle distance
curl http://<robot-ip>:5000/get_distance
```

**Pro Tip:** You can create a simple web interface or mobile app that sends these HTTP requests for easier control.

## Testing Individual Components

```bash
# Test RPLidar
ros2 launch slam_robot rplidar.launch.py
ros2 topic echo /scan

# Test odometry
ros2 run slam_robot odometry_publisher
ros2 topic echo /odom

# Test IMU
ros2 run slam_robot imu_publisher
ros2 topic echo /imu/data_raw

# Test motor control
ros2 run slam_robot motor_controller
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.1}}"
```

## Tuning Parameters

### Waypoint Generation
In `launch/mapping.launch.py`:
- `waypoint_interval_time`: Seconds between waypoints (default: 15.0)
- `waypoint_interval_distance`: Meters between waypoints (default: 2.5)
- `min_distance_between_waypoints`: Minimum spacing (default: 0.5)

### SLAM Quality
In `config/slam_toolbox_params.yaml`:
- `resolution`: Map resolution in meters (default: 0.05)
- `max_laser_range`: Max lidar range (default: 12.0)
- `minimum_travel_distance`: Min distance before map update (default: 0.2)

### Navigation Speed
In `config/nav2_params.yaml`:
- `max_vel_x`: Max forward speed m/s (default: 0.3)
- `max_vel_theta`: Max rotation speed rad/s (default: 1.0)
- `xy_goal_tolerance`: Goal reached threshold (default: 0.15)

## Common Issues

**"No scan received" during mapping:**
- Check `/dev/ttyUSB0` permissions: `sudo chmod 666 /dev/ttyUSB0`
- Verify lidar spinning: `ros2 topic hz /scan` should show ~8Hz

**"IMU not found":**
- Check I2C connection: `i2cdetect -y 1` should show device at 0x68
- Fix permissions: `sudo chmod 666 /dev/i2c-1`

**Robot doesn't move:**
- Check GPIO permissions (may need logout after adding to gpio group)
- Verify motor controller is running: `ros2 node list | grep motor_controller`
- Check `/cmd_vel` is being published: `ros2 topic echo /cmd_vel`

**AMCL particles scattered (poor localization):**
- Set initial pose accurately in RViz (2D Pose Estimate)
- Drive robot around to let particles converge
- Ensure map quality is good (distinctive features, not empty space)

**"Unknown waypoint: Point_B":**
- Verify waypoint file exists: `ls ~/slam_maps/*_waypoints.yaml`
- Check map name matches: launch uses correct `map:=` argument
- List available waypoints: `ros2 run slam_robot list_waypoints`

## Important Conventions

- **Control modes:** `control_mode:=auto` (default, autonomous) or `control_mode:=manual` (HTTP API)
- **Maps saved to:** `~/slam_maps/` (outside workspace)
- **Map format:** `.pgm` (grayscale), `.yaml` (metadata), `_waypoints.yaml` (navigation labels)
- **Waypoint naming:** Point_A, Point_B, ..., Point_Z, Point_AA, Point_AB, ...
- **Always source workspace:** `source install/setup.bash` before running any commands
- **SLAM lifecycle:** Must manually configure/activate after launch
- **Navigation requires:** Setting initial pose in RViz before first navigation
- **Manual control:** HTTP server runs on port 5000, accessible from any device on network

## Documentation Files

- `README.md` - Basic hardware setup and mapping usage
- `NAVIGATION_GUIDE.md` - Complete 60-page navigation system guide
- `NAVIGATION_QUICK_START.md` - 5-minute quick start
- `IMPLEMENTATION_SUMMARY.md` - Technical implementation details
- `START_HERE.md` - User-facing quick start with automated scripts
- `EXACT_COMMANDS.md` - Copy-paste command reference

## Dependencies

ROS2 packages (in `package.xml`):
- `slam_toolbox` - SLAM mapping
- `rplidar_ros` - Lidar driver
- `nav2_bringup` - Navigation stack
- `nav2_map_server` - Map loading/saving
- `nav2_amcl` - Localization
- `robot_localization` - EKF sensor fusion
- `imu_filter_madgwick` - IMU filtering

Python packages:
- `gpiozero` - GPIO control (motors, sensors)
- `smbus2` - I2C communication (IMU)
- `Pillow` - Image conversion (map saving)
- `flask` - HTTP server for manual control API
