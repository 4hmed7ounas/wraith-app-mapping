#!/bin/bash
# Test script for waypoint generation system

cd /home/zaid/SLAM/slam_ws
source install/setup.bash

echo "========================================"
echo "Waypoint System Diagnostic Test"
echo "========================================"
echo ""

echo "1. Checking if executables exist..."
ros2 pkg executables slam_robot | grep waypoint
echo ""

echo "2. Checking installed launch file..."
if grep -q "auto_waypoint_generator" install/slam_robot/share/slam_robot/launch/mapping.launch.py; then
    echo "✓ Launch file contains auto_waypoint_generator node"
else
    echo "✗ Launch file missing auto_waypoint_generator node"
fi
echo ""

echo "3. Testing auto_waypoint_generator node standalone..."
timeout 3 ros2 run slam_robot auto_waypoint_generator &
PID=$!
sleep 2
if ps -p $PID > /dev/null; then
    echo "✓ Node starts successfully"
    kill $PID 2>/dev/null
else
    echo "✓ Node started and stopped (expected)"
fi
echo ""

echo "4. Checking required topics exist (if mapping is running)..."
ros2 topic list 2>/dev/null | grep -E "(pose|odom)" || echo "  No ROS nodes running (expected if mapping not started)"
echo ""

echo "========================================"
echo "Diagnostic Complete"
echo "========================================"
echo ""
echo "To start mapping with waypoint generation:"
echo "  Terminal 1: ros2 launch slam_robot mapping.launch.py"
echo "  Terminal 2: ros2 lifecycle set /slam_toolbox configure"
echo "  Terminal 2: ros2 lifecycle set /slam_toolbox activate"
echo ""
echo "To verify waypoint node is running during mapping:"
echo "  ros2 node list | grep auto_waypoint"
echo ""
