# Complete Commands for SLAM with Flutter App

## System Overview

Your robot is controlled by a **Flutter mobile app** that connects via HTTP to the robot's IP address.

**App Features:**
- Manual control buttons (Forward, Backward, Left, Right)
- Speed control (Increase/Decrease)
- Auto mode toggle (Robot explores autonomously)

---

## MAPPING PHASE - Complete Workflow

### Terminal 1: Start Mapping System

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
```

**What You'll See:**
```
======================================================================
      MANUAL CONTROL SERVER - WAITING FOR FLUTTER APP
======================================================================
[✓] Motors enabled

  █████████████████████████████████████████████████████████████
  ███  ROBOT IP ADDRESS: 192.168.1.100                      ███
  ███  PORT: 5000                                           ███
  █████████████████████████████████████████████████████████████

[★] Enter this IP in your Flutter app: 192.168.1.100
[★] Server listening on: http://192.168.1.100:5000

======================================================================
Flutter App Commands Supported:
======================================================================
  • forward_start, forward_stop    - Move forward/stop
  • backward_start, backward_stop  - Move backward/stop
  • left_start, left_stop          - Turn left/stop
  • right_start, right_stop        - Turn right/stop
  • speed+, speed-                 - Increase/decrease speed
  • auto_start, auto_stop          - Toggle autonomous mode
======================================================================
Current speed: 30%
======================================================================

[✓] HTTP server started successfully
[⏳] Waiting for Flutter app to connect...

======================================================================
```

**Copy the IP address shown** (e.g., 192.168.1.100)

---

### Flutter App: Connect to Robot

1. Open your Flutter app
2. Enter the IP address: `192.168.1.100`
3. Enter port: `5000`
4. Click "Connect"

**Terminal 1 will show:**
```
[📱] Flutter app connected - Status check
```

---

### Terminal 2: Activate SLAM

```bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

**You'll see:**
```
Transitioning successful
```

Now SLAM is active and building the map!

---

### Flutter App: Control the Robot

**Option A: Manual Control**

Use the app buttons to drive around and map your space:

- Press **Forward** button → Terminal shows:
  ```
  [⬆️] Moving FORWARD at 30% speed
  ```

- Press **Stop** button → Terminal shows:
  ```
  [⏹️] STOPPED
  ```

- Press **Left** button → Terminal shows:
  ```
  [⬅️] Turning LEFT at 30% speed
  ```

- Press **Right** button → Terminal shows:
  ```
  [➡️] Turning RIGHT at 30% speed
  ```

- Press **Backward** button → Terminal shows:
  ```
  [⬇️] Moving BACKWARD at 30% speed
  ```

- Press **Speed +** button → Terminal shows:
  ```
  [⚡] Speed INCREASED to 40%
  ```

- Press **Speed -** button → Terminal shows:
  ```
  [🐌] Speed DECREASED to 30%
  ```

**Option B: Autonomous Mode**

Toggle the **Auto Mode** switch in your app:

- Enable Auto Mode → Terminal shows:
  ```
  ======================================================================
  [🤖] AUTO MODE ENABLED - Robot exploring autonomously
  ======================================================================
  [INFO] ✓ Created Point_A at (0.00, 0.00, 0.00) [start]
  ```

  Robot now explores by itself with obstacle avoidance!

- Disable Auto Mode → Terminal shows:
  ```
  ======================================================================
  [👤] MANUAL MODE ENABLED - Waiting for app commands
  ======================================================================
  ```

  You can now control manually again.

**Drive around for 3-5 minutes to map your space thoroughly**

---

### Terminal 3: Save the Map

When you're done mapping:

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
python3 src/slam_robot/scripts/save_map.py my_office_map
```

**Output:**
```
Saving map to: /home/zaid/slam_maps/my_office_map

=== Map Saved Successfully ===
Location: /home/zaid/slam_maps
Files created:
  - my_office_map.pgm (original)
  - my_office_map.png (for visualization)
  - my_office_map.yaml (metadata for navigation)
  - my_office_map_waypoints.yaml (auto-generated waypoints)

✓ 12 waypoints saved: Point_A through Point_L
```

**Stop everything:** Press `Ctrl+C` in Terminal 1 and Terminal 2

---

## NAVIGATION PHASE - Complete Workflow

### Terminal 1: Launch Navigation

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_office_map
```

Replace `my_office_map` with your actual map name.

---

### Terminal 2: Set Initial Pose (REQUIRED!)

**Option A: Using RViz (Recommended)**

```bash
rviz2
```

1. Click **"Add"** → Add **Map** → Set topic: `/map`
2. Click **"Add"** → Add **LaserScan** → Set topic: `/scan`
3. Click **"Add"** → Add **PoseArray** → Set topic: `/particlecloud`
4. Click **"2D Pose Estimate"** button in toolbar
5. Click where robot is on the map
6. Drag to set orientation
7. Watch particles converge around robot location

**Option B: Command Line**

```bash
ros2 topic pub --once /initialpose geometry_msgs/msg/PoseWithCovarianceStamped '{
  header: {frame_id: "map"},
  pose: {
    pose: {
      position: {x: 0.0, y: 0.0, z: 0.0},
      orientation: {x: 0.0, y: 0.0, z: 0.0, w: 1.0}
    },
    covariance: [0.25, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.25, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.068]
  }
}'
```

---

### Terminal 3: Navigate to Waypoints

**List available waypoints:**
```bash
ros2 run slam_robot list_waypoints
```

**Output:**
```
============================================================
Available Waypoints (12 total):
============================================================
  Point_A      → (  0.00,   0.00,  0.00 rad)
  Point_B      → (  2.30,   1.50,  1.57 rad)
  Point_C      → (  4.10,   3.20,  0.00 rad)
  Point_D      → (  6.20,   2.80,  3.14 rad)
  Point_E      → (  7.50,   4.20,  1.57 rad)
  ...
============================================================
```

**Navigate to waypoints:**
```bash
# Go to Point_B
ros2 run slam_robot go_to Point_B

# Go to Point_C
ros2 run slam_robot go_to Point_C

# Go to Point_F
ros2 run slam_robot go_to Point_F

# Return to start
ros2 run slam_robot go_to Point_A
```

**What you'll see:**
```
============================================================
✓ Navigation goal sent: Point_B
  Target: (2.30, 1.50, 1.57 rad)
============================================================
```

The robot will navigate autonomously to the waypoint!

---

## QUICK REFERENCE

### Mapping Commands (3 Terminals)

```bash
# Terminal 1
cd ~/SLAM/slam_ws && source install/setup.bash
ros2 launch slam_robot mapping.launch.py

# Terminal 2
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# Terminal 3 (when done)
python3 ~/SLAM/slam_ws/src/slam_robot/scripts/save_map.py my_map
```

### Navigation Commands (3 Terminals)

```bash
# Terminal 1
cd ~/SLAM/slam_ws && source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_map

# Terminal 2
rviz2
# Set initial pose with "2D Pose Estimate"

# Terminal 3
ros2 run slam_robot list_waypoints
ros2 run slam_robot go_to Point_B
```

---

## Flutter App HTTP Commands

Your app sends these POST requests to control the robot:

| Command | HTTP Request | What It Does |
|---------|--------------|--------------|
| Forward | `POST /control` data: `forward_start` | Move forward |
| Stop | `POST /control` data: `forward_stop` | Stop movement |
| Backward | `POST /control` data: `backward_start` | Move backward |
| Left | `POST /control` data: `left_start` | Turn left |
| Right | `POST /control` data: `right_start` | Turn right |
| Speed + | `POST /control` data: `speed+` | Increase speed 10% |
| Speed - | `POST /control` data: `speed-` | Decrease speed 10% |
| Auto On | `POST /control` data: `auto_start` | Enable autonomous mode |
| Auto Off | `POST /control` data: `auto_stop` | Disable autonomous mode |

**Get Info:**
- `GET /` - Check connection status
- `GET /get_ip` - Get robot IP
- `GET /get_distance` - Get ultrasonic sensor reading

---

## Terminal Log Examples

### When App Connects:
```
[📱] Flutter app connected - Status check
```

### Manual Control:
```
[⬆️] Moving FORWARD at 30% speed
[⏹️] STOPPED
[⬅️] Turning LEFT at 30% speed
[➡️] Turning RIGHT at 40% speed
[⬇️] Moving BACKWARD at 40% speed
```

### Speed Changes:
```
[⚡] Speed INCREASED to 40%
[⚡] Speed INCREASED to 50%
[🐌] Speed DECREASED to 40%
```

### Auto Mode Toggle:
```
======================================================================
[🤖] AUTO MODE ENABLED - Robot exploring autonomously
======================================================================
[INFO] ✓ Created Point_A at (0.00, 0.00, 0.00) [start]
[INFO] ✓ Created Point_B at (2.30, 1.50, 1.57) [16.2s elapsed]

======================================================================
[👤] MANUAL MODE ENABLED - Waiting for app commands
======================================================================
```

### Waypoint Generation:
```
[INFO] ✓ Created Point_A at (0.00, 0.00, 0.00) [start]
[INFO] ✓ Created Point_B at (2.30, 1.50, 1.57) [16.2s elapsed]
[INFO] ✓ Created Point_C at (4.10, 3.20, 0.00) [2.7m traveled]
[INFO] ✓ Created Point_D at (6.20, 2.80, 3.14) [15.1s elapsed]
```

---

## Troubleshooting

### "Cannot connect to robot" in app:

1. Check robot IP is correct:
   ```bash
   hostname -I
   ```

2. Check server is running:
   ```bash
   ros2 node list | grep manual_control_server
   ```

3. Test connection:
   ```bash
   curl http://192.168.1.100:5000/
   ```
   Should return: `Manual Control Server Online - ROS2 SLAM Robot`

### Robot doesn't move when pressing buttons:

1. Check Terminal 1 for command logs
2. Verify GPIO permissions:
   ```bash
   sudo usermod -a -G gpio $USER
   # Logout and login
   ```

3. Check motors enabled:
   Terminal 1 should show: `[✓] Motors enabled`

### SLAM not working:

Check Terminal 2 shows:
```
Transitioning successful
```

If not, run again:
```bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

### No waypoints in saved map:

- Make sure you drove around for at least 3-5 minutes
- Check waypoints file exists:
  ```bash
  ls ~/slam_maps/*_waypoints.yaml
  ```

---

## Tips for Best Mapping Results

1. **Start with low speed** (30%) for precise mapping
2. **Drive slowly** through rooms
3. **Use auto mode** for open areas
4. **Use manual mode** for tight spaces
5. **Map for 3-5 minutes** minimum
6. **Cover all areas** you want the robot to navigate later
7. **Watch Terminal 1** to see waypoints being created
8. **Speed up/down** as needed using app buttons

---

## Complete Example Session

**Starting Mapping:**
```bash
# Terminal 1
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
# Note IP: 192.168.1.100

# Terminal 2 (after Terminal 1 ready)
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# Flutter App
# Connect to 192.168.1.100:5000
# Drive around for 5 minutes
# Use auto mode for open areas
# Use manual for tight spots

# Terminal 3 (when done)
python3 src/slam_robot/scripts/save_map.py office_floor1

# Ctrl+C in Terminals 1 & 2
```

**Starting Navigation:**
```bash
# Terminal 1
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=office_floor1

# Terminal 2
rviz2
# Click "2D Pose Estimate"
# Click robot location on map

# Terminal 3
ros2 run slam_robot list_waypoints
ros2 run slam_robot go_to Point_C
# Wait for robot to reach...
ros2 run slam_robot go_to Point_F
```

---

**That's it! Simple 3-terminal workflow with your Flutter app! 🚀**

*Remember: Always source the workspace before running commands!*
