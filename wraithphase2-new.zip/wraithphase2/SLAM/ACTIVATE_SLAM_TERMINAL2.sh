#!/bin/bash
# Terminal 2 script: Activate SLAM and monitor waypoint generation

cd /home/zaid/SLAM/slam_ws
source install/setup.bash

echo "╔══════════════════════════════════════════════════════════╗"
echo "║         Terminal 2: SLAM Activation & Monitoring        ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Wait for user confirmation that Terminal 1 is ready
echo "BEFORE PROCEEDING, verify Terminal 1 shows:"
echo "  ✓ All nodes started"
echo "  ✓ [auto_waypoint_generator]: Auto-Waypoint Generator Started"
echo ""
read -p "Press ENTER when Terminal 1 is ready..."
echo ""

echo "════════════════════════════════════════════════════════════"
echo " Step 1: Activating SLAM Toolbox"
echo "════════════════════════════════════════════════════════════"
echo ""

echo "Configuring SLAM..."
ros2 lifecycle set /slam_toolbox configure
if [ $? -eq 0 ]; then
    echo "✓ SLAM configured"
else
    echo "✗ SLAM configure failed - check if mapping is running"
    exit 1
fi
echo ""

sleep 1

echo "Activating SLAM..."
ros2 lifecycle set /slam_toolbox activate
if [ $? -eq 0 ]; then
    echo "✓ SLAM activated"
else
    echo "✗ SLAM activate failed"
    exit 1
fi
echo ""

echo "════════════════════════════════════════════════════════════"
echo " Step 2: Verifying Auto-Waypoint Generator"
echo "════════════════════════════════════════════════════════════"
echo ""

sleep 2

echo "Checking if auto_waypoint_generator node is running..."
if ros2 node list | grep -q "auto_waypoint_generator"; then
    echo "✓ auto_waypoint_generator is RUNNING"
else
    echo "✗ auto_waypoint_generator NOT FOUND"
    echo ""
    echo "Active nodes:"
    ros2 node list
    echo ""
    echo "This is the problem! The node didn't start."
    echo "Please stop mapping (Ctrl+C) and report this issue."
    exit 1
fi
echo ""

echo "Checking if /pose topic is publishing..."
HZ=$(timeout 3 ros2 topic hz /pose 2>&1 | grep "average rate" | awk '{print $3}')
if [ ! -z "$HZ" ]; then
    echo "✓ /pose topic is publishing at $HZ Hz"
else
    echo "⚠ /pose topic may not be publishing yet (robot might not be moving)"
fi
echo ""

echo "════════════════════════════════════════════════════════════"
echo " Step 3: Monitoring Waypoint Creation"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "Waypoint parameters:"
ros2 param get /auto_waypoint_generator waypoint_interval_time 2>/dev/null
ros2 param get /auto_waypoint_generator waypoint_interval_distance 2>/dev/null
echo ""

echo "════════════════════════════════════════════════════════════"
echo " ✓ SYSTEM READY - Waypoint Generation Active"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "What's happening now:"
echo "  • Robot is exploring autonomously"
echo "  • SLAM is building the map"
echo "  • Waypoints created every 15s OR 2.5m"
echo ""
echo "You should see in Terminal 1:"
echo "  [auto_waypoint_generator]: ✓ Created Point_A at (0.00, 0.00)"
echo "  [auto_waypoint_generator]: ✓ Created Point_B at (2.30, 1.50)"
echo "  ..."
echo ""
echo "Let the robot explore for 3-5 minutes, then:"
echo ""
echo "  1. Press Ctrl+C in Terminal 1 to stop mapping"
echo "  2. Run: python3 src/slam_robot/scripts/save_map.py <map_name>"
echo "  3. Verify: ls ~/slam_maps/<map_name>_waypoints.yaml"
echo ""
echo "════════════════════════════════════════════════════════════"
echo ""

# Keep monitoring
echo "Press Ctrl+C to exit monitoring, or wait..."
echo ""
echo "Live waypoint count monitoring (refreshes every 5 seconds):"
echo ""

while true; do
    COUNT=$(ros2 node list 2>/dev/null | grep -c auto_waypoint)
    if [ $COUNT -eq 0 ]; then
        echo "[$(date +%H:%M:%S)] ⚠ auto_waypoint_generator stopped running!"
        break
    fi

    echo -n "[$(date +%H:%M:%S)] Monitoring... "

    # Try to get parameter (this will work if node is properly configured)
    MAP_NAME=$(ros2 param get /auto_waypoint_generator map_name 2>/dev/null | grep -oP "String value is '\K[^']+")
    if [ ! -z "$MAP_NAME" ]; then
        echo "Map: $MAP_NAME"
    else
        echo "Node running ✓"
    fi

    sleep 5
done
