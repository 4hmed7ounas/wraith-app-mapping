# SLAM Robot - Autonomous Mapping System

Complete SLAM implementation for differential drive robot with RPLidar A2 M12, MPU6050 IMU, wheel encoders, ultrasonic sensor, and servo.

## Hardware Setup
- **Lidar**: RPLidar A2 M12 on `/dev/ttyUSB0`
- **IMU**: MPU6050 on I2C address 0x68
- **Motors**: 2x BTS7960 motor drivers (GPIO pins configured)
- **Encoders**: 500 pulses/rev on GPIO 17,4,19,13
- **Ultrasonic**: HC-SR04 on GPIO 20,21
- **Servo**: On GPIO 12
- **Wheel specs**: 6.5cm diameter, 0.7 feet separation

## System Architecture

### Core Nodes
1. **motor_controller** - Controls BTS7960 motors via cmd_vel
2. **odometry_publisher** - Calculates odometry from wheel encoders
3. **imu_publisher** - Publishes MPU6050 IMU data
4. **obstacle_avoidance** - Random exploration with obstacle avoidance
5. **slam_toolbox** - SLAM mapping algorithm
6. **ekf_filter** - Fuses odometry and IMU data

## Installation & Setup

### 1. Install Dependencies (if needed)
```bash
sudo apt install ros-jazzy-slam-toolbox ros-jazzy-rplidar-ros \
                 ros-jazzy-imu-tools ros-jazzy-robot-localization \
                 ros-jazzy-nav2-map-server
pip3 install gpiozero smbus2 pillow
```

### 2. Build Workspace
```bash
cd ~/SLAM/slam_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash
```

### 3. Setup Permissions
```bash
# RPLidar access
sudo chmod 666 /dev/ttyUSB0

# I2C access
sudo usermod -a -G i2c $USER
sudo chmod 666 /dev/i2c-1

# GPIO access (reboot may be required)
sudo usermod -a -G gpio $USER
```

## Usage

### Start Mapping
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
```

This will:
- Start all sensors (RPLidar, IMU)
- Launch odometry from encoders
- Start obstacle avoidance (robot moves randomly at 50% speed)
- Run SLAM to build the map
- Fuse odometry + IMU with EKF

### Save Map
While mapping is running, in a new terminal:
```bash
cd ~/SLAM/slam_ws
source install/setup.bash

# Save with auto-generated timestamp name
python3 src/slam_robot/scripts/save_map.py

# Or specify a custom name
python3 src/slam_robot/scripts/save_map.py my_house_map
```

Maps are saved to `~/slam_maps/` in formats:
- `.pgm` - Original grayscale map
- `.png` - PNG version for visualization
- `.yaml` - Metadata for Nav2 navigation

### Visualize with RViz2 (Optional)
On another computer or via X11 forwarding:
```bash
ros2 run rviz2 rviz2
```
Add displays:
- **Map** topic: `/map`
- **LaserScan** topic: `/scan`
- **TF** - to see robot frames
- **Odometry** topic: `/odometry/filtered`

## Configuration Files

### slam_toolbox_params.yaml
Located in `config/slam_toolbox_params.yaml`
- Resolution: 0.05m/pixel
- Loop closure enabled
- Optimized for real-time mapping

### Robot URDF
Located in `urdf/robot.urdf`
- Defines robot geometry and sensor positions
- Wheel separation: 0.21336m (0.7 feet)
- Wheel radius: 0.0325m (6.5cm)

## File Structure
```
slam_ws/
├── src/
│   └── slam_robot/
│       ├── slam_robot/          # Python nodes
│       │   ├── motor_controller.py
│       │   ├── odometry_publisher.py
│       │   ├── imu_publisher.py
│       │   └── obstacle_avoidance.py
│       ├── launch/              # Launch files
│       │   ├── mapping.launch.py
│       │   ├── rplidar.launch.py
│       │   └── slam_toolbox.launch.py
│       ├── config/              # Configuration
│       │   └── slam_toolbox_params.yaml
│       ├── urdf/                # Robot model
│       │   └── robot.urdf
│       └── scripts/             # Utilities
│           └── save_map.py
└── install/                     # Built packages
```

## Behavior

### Obstacle Avoidance & Exploration
- Robot moves forward at 50% speed with random variations
- Ultrasonic sensor detects obstacles at 30cm threshold
- When obstacle detected:
  1. Stop and scan (servo sweeps left/center/right)
  2. Back up
  3. Turn toward open space
  4. Continue exploration
- This random exploration ensures good map coverage

### Odometry
- Calculated from wheel encoders (500 pulses/rev)
- Differential drive kinematics
- Published at 50Hz on `/odom` topic

### Sensor Fusion
- EKF fuses wheel odometry and IMU angular velocity
- Provides filtered odometry on `/odometry/filtered`
- Improves SLAM accuracy

## Troubleshooting

### RPLidar Not Detected
```bash
ls /dev/ttyUSB*
sudo chmod 666 /dev/ttyUSB0
```

### IMU Not Found
```bash
i2cdetect -y 1
# Should show device at 0x68
```

### Motors Not Moving
- Check GPIO permissions
- Verify wiring to BTS7960 drivers
- Check enable pins are HIGH

### Map Quality Issues
- Ensure robot moves slowly (current: 50% speed)
- Check encoder connections
- Verify IMU calibration (auto-calibrated on startup)
- Reduce `minimum_travel_distance` in slam_toolbox_params.yaml

### Permission Denied Errors
```bash
sudo usermod -a -G dialout,i2c,gpio $USER
# Then logout and login again
```

## Advanced Usage

### Tune SLAM Parameters
Edit `config/slam_toolbox_params.yaml`:
- `resolution`: Map resolution (default 0.05m)
- `max_laser_range`: Lidar max range (default 12m)
- `minimum_travel_distance`: Min distance before update (default 0.2m)

### Manual Control
Stop obstacle_avoidance node and control via:
```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard
```

### View Topics
```bash
ros2 topic list
ros2 topic echo /scan
ros2 topic echo /odom
```

## Next Steps

Once you have a saved map, you can use it for:
- **Navigation** with Nav2
- **Localization** with AMCL
- **Path planning** and autonomous navigation

The `.yaml` and `.pgm` files are compatible with ROS2 Nav2 stack.
