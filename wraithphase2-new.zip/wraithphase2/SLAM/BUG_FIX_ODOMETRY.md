# BUG FIX: Waypoints Not Being Created in Manual Mode

## The Problem

Only Point_A at (0,0) was created, no waypoints during robot movement.

## Root Cause

**The `manual_control_server` controlled motors but didn't publish odometry data.**

### Why This Broke Waypoints:

1. **MANUAL mode**: `manual_control_server` runs, controls motors via Flask
2. **MISSING**: No `/odom` topic published (encoders read but not published!)
3. **EKF node**: Subscribes to `/odom` but gets NO DATA
4. **Result**: EKF can't publish `/odometry/filtered`
5. **SLAM Toolbox**: Needs odometry, can't publish `/pose` properly
6. **Waypoint Generator**: Subscribes to `/pose` and `/odometry/filtered`, gets NO DATA
7. **Final Result**: Only initial waypoint at (0,0), no movement tracking

### Why This Worked in AUTO Mode:

In AUTO mode, `odometry_publisher` runs separately and publishes `/odom` correctly.
But we disabled it in MANUAL mode to prevent GPIO conflicts.

## The Fix

Added odometry publishing directly to `manual_control_server.py`:

```python
# Added imports
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
import math

# Added to __init__:
self.odom_pub = self.create_publisher(Odometry, 'odom', 50)
self.tf_broadcaster = TransformBroadcaster(self)
self.odom_timer = self.create_timer(0.02, self.update_odometry)  # 50Hz

# Added update_odometry() method:
# - Reads encoder ticks (already being tracked)
# - Calculates position (x, y, theta)
# - Publishes Odometry message to /odom
# - Broadcasts TF transform (odom → base_footprint)
```

Now in MANUAL mode:
- `manual_control_server` handles BOTH motor control AND odometry publishing
- EKF gets `/odom` data
- EKF publishes `/odometry/filtered`
- SLAM publishes `/pose`
- Waypoint generator creates waypoints every 0.5m ✓

## Testing Instructions

### Terminal 1: Start Mapping
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
```

You should see:
```
[✓] Motors enabled
[✓] Odometry publisher started (publishing to /odom at 50Hz)
[★] ROBOT IP ADDRESS: 192.168.x.x
```

### Terminal 2 (after 10 seconds): Activate SLAM
```bash
cd ~/SLAM/slam_ws && source install/setup.bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

You should see:
```
Transitioning successful
```

### Flutter App: Drive the Robot
- Connect to robot IP + port 5000
- Drive around for 3-5 minutes
- You should see in Terminal 1:
  ```
  [⬆️] Moving FORWARD at 30% speed
  [INFO] ✓ Created Point_A at (0.00, 0.00, 0.00) [5.0s elapsed]
  [DEBUG] Pos: (0.52, 0.03) | Distance: 0.52m | Time: 1.2s | Waypoints: 1
  [INFO] ✓ Created Point_B at (0.53, 0.03, 0.01) [0.5m traveled]
  [INFO] ✓ Created Point_C at (1.05, 0.08, 0.02) [0.5m traveled]
  ```

### Terminal 3: Verify Odometry is Publishing
```bash
cd ~/SLAM/slam_ws && source install/setup.bash
# Check /odom topic exists and has data
ros2 topic hz /odom
# Should show ~50Hz

ros2 topic echo /odom --once
# Should show position updating as robot moves
```

### Terminal 4: Save Map When Done
```bash
cd ~/SLAM/slam_ws && source install/setup.bash
python3 src/slam_robot/scripts/save_map.py MY_MAP_NAME
```

### Expected Results

1. **During driving**: You'll see waypoint creation logs every 0.5 meters
2. **After saving**: Files in `~/slam_maps/`:
   - `MY_MAP_NAME.pgm`
   - `MY_MAP_NAME.png`
   - `MY_MAP_NAME.yaml`
   - `MY_MAP_NAME_waypoints.yaml` ← THIS SHOULD NOW EXIST with multiple waypoints!

## Verification Commands

```bash
# Check waypoints were created
cat ~/slam_maps/MY_MAP_NAME_waypoints.yaml

# Should show multiple waypoints:
# waypoints:
# - label: Point_A
#   x: 0.0
#   y: 0.0
# - label: Point_B
#   x: 0.53
#   y: 0.03
# - label: Point_C
#   x: 1.05
#   y: 0.08
# ... etc
```

## What Changed

**File Modified**: `/home/zaid/SLAM/slam_ws/src/slam_robot/slam_robot/manual_control_server.py`

- Added odometry publishing functionality (100+ lines)
- Now publishes `/odom` topic at 50Hz
- Calculates position from encoder readings
- Broadcasts TF transforms

The fix ensures that in MANUAL mode, the complete odometry chain works:
**Encoders → Odometry → EKF → SLAM → Waypoints** ✓
