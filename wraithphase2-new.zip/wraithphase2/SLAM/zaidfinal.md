# SLAM Robot - Complete Command Guide

Complete guide for Wraith Robot SLAM and Autonomous Navigation system.

**Last Updated:** 2025-11-26
**Robot:** Wraith (Differential Drive)
**Hardware:** Raspberry Pi + RPLidar A2 + MPU6050 IMU + Wheel Encoders

---

## Table of Contents
1. [Hardware Setup](#hardware-setup)
2. [Phase 1: Mapping (SLAM)](#phase-1-mapping-slam)
3. [Phase 2: Navigation](#phase-2-navigation)
4. [Waypoint Visualization](#waypoint-visualization)
5. [Troubleshooting](#troubleshooting)

---

## Hardware Setup

### Required Permissions (Run After Reboot)

```bash
# RPLidar permission
sudo chmod 666 /dev/ttyUSB0

# I2C (IMU) permission
sudo chmod 666 /dev/i2c-1

# GPIO permission (one-time, requires logout)
sudo usermod -a -G gpio $USER
# Then logout and login again
```

### Verify Hardware

```bash
# Check RPLidar connected
ls /dev/ttyUSB0

# Check IMU connected (should show device at 0x68)
i2cdetect -y 1

# Check GPIO access
groups | grep gpio
```

---

## Phase 1: Mapping (SLAM)

Create a map of your environment and auto-generate waypoints.

### Option A: Manual Control via Flutter App (Recommended)

Control robot manually using your Flutter mobile app.

#### Terminal 1: Launch Mapping with Manual Control
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=manual
```

**Note the robot IP address shown in terminal output**

#### Terminal 2: Activate SLAM
```bash
# Activate SLAM Toolbox (required!)
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

#### Control Robot with Flutter App

1. Open your Flutter mobile app
2. Connect to robot IP (shown in Terminal 1)
3. Drive the robot around your space to build the map
4. Waypoints are automatically created every 15 seconds or 2.5 meters

**Drive for 3-5 minutes to cover your space**

#### Terminal 3: Save Map When Done
```bash
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_map_name
```

**Replace `my_map_name` with your map name (e.g., `office_map`, `warehouse_1`)**

### Option B: Autonomous Mapping

Robot explores automatically using obstacle avoidance.

#### Terminal 1: Launch Mapping
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=auto
```

#### Terminal 2: Activate SLAM
```bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

**Robot will now explore autonomously for 3-5 minutes.**

#### Terminal 3: Save Map
```bash
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_map_name
```

### Option C: Manual Control via HTTP

Control robot manually from any device on your network.

#### Terminal 1: Launch Mapping with Manual Control
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=manual
```

**Note the robot IP address shown in terminal output**

#### Terminal 2: Activate SLAM
```bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

#### Terminal 3: Control Robot via HTTP

**From any device on the network:**

```bash
# Get robot IP
curl http://<robot-ip>:5000/get_ip

# Move forward
curl -X POST http://<robot-ip>:5000/control -d "forward_start"
sleep 2
curl -X POST http://<robot-ip>:5000/control -d "forward_stop"

# Turn right
curl -X POST http://<robot-ip>:5000/control -d "right_start"
sleep 1
curl -X POST http://<robot-ip>:5000/control -d "right_stop"

# Turn left
curl -X POST http://<robot-ip>:5000/control -d "left_start"
sleep 1
curl -X POST http://<robot-ip>:5000/control -d "left_stop"

# Increase speed
curl -X POST http://<robot-ip>:5000/control -d "speed+"

# Decrease speed
curl -X POST http://<robot-ip>:5000/control -d "speed-"

# Enable autonomous mode temporarily
curl -X POST http://<robot-ip>:5000/control -d "auto_start"

# Back to manual control
curl -X POST http://<robot-ip>:5000/control -d "auto_stop"

# Check obstacle distance
curl http://<robot-ip>:5000/get_distance
```

#### Terminal 4: Save Map
```bash
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_map_name
```

### What Happens During Mapping

- **SLAM Toolbox** builds 2D occupancy grid map
- **Auto-waypoint generator** creates labeled waypoints every:
  - 15 seconds OR
  - 2.5 meters traveled
  - (whichever comes first)
- Waypoints labeled as: `Point_A`, `Point_B`, `Point_C`, ..., `Point_Z`, `Point_AA`, etc.
- Map saved to: `~/slam_maps/`

### Files Created

After saving, you'll have:
```
~/slam_maps/
├── my_map_name.pgm           # Map image (grayscale)
├── my_map_name.yaml          # Map metadata
└── my_map_name_waypoints.yaml # Waypoint labels and coordinates
```

---

## Phase 2: Navigation

Use the saved map to navigate autonomously to waypoints.

### Terminal 1: Launch Navigation

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_map_name
```

**Replace `my_map_name` with your actual map name (e.g., `test_qos_fix`)**

**Wait for all nodes to activate. Look for:**
```
[localization_lifecycle_manager]: Managed nodes are active
[lifecycle_manager_navigation]: Managed nodes are active
```

### Terminal 2: Open RViz for Visualization

```bash
rviz2
```

**RViz Setup:**

1. **Set Fixed Frame:**
   - Top left: Change "Fixed Frame" to `map`

2. **Add Map Display:**
   - Click "Add" → "By topic" → `/map` → "Map"
   - Map should appear immediately

3. **Add LaserScan Display:**
   - Click "Add" → "By topic" → `/scan` → "LaserScan"
   - Change "Color" to red or green for visibility
   - This shows what the robot sees

4. **Add Path Display:**
   - Click "Add" → "By topic" → `/plan` → "Path"
   - Change "Color" to green
   - Shows planned navigation path (appears when navigating)

5. **Set Initial Pose (IMPORTANT!):**
   - Click "2D Pose Estimate" button (top toolbar)
   - Click on map where robot actually is
   - Drag arrow in direction robot is facing
   - You should see green particle cloud converge around robot

**How to know where robot is?**
- LaserScan shows what robot sees
- Match the scan pattern to map features
- If robot is in a corner, scan shows L-shape
- If robot sees wall ahead, scan shows line in front

### Terminal 3: Visualize Waypoints on Map

```bash
ros2 run slam_robot waypoint_visualizer --map my_map_name
```

**In RViz:**
- Click "Add" → "MarkerArray"
- Set Topic: `/waypoint_markers`
- You'll see **green spheres with labels** showing all waypoints!

### Terminal 4: List and Navigate to Waypoints

```bash
# List all available waypoints
ros2 run slam_robot list_waypoints --map my_map_name
```

**Output:**
```
Available Waypoints for map 'my_map_name':
  Point_A: (x: 0.00, y: 0.00)
  Point_B: (x: -0.40, y: -0.09)
  Point_C: (x: -0.63, y: 0.25)
  Point_D: (x: -0.27, y: 0.15)
  Point_E: (x: -0.25, y: 0.45)
```

**Navigate to a waypoint:**
```bash
# Go to Point_B
ros2 run slam_robot go_to Point_B --map my_map_name

# Go to Point_C
ros2 run slam_robot go_to Point_C --map my_map_name

# Go to Point_A (return to start)
ros2 run slam_robot go_to Point_A --map my_map_name
```

**What you'll see in RViz:**
- Green path line from robot to goal
- Blue local trajectory
- Robot moving at **0.8 m/s** along the path

### Navigation Speed Settings

Current speed configuration:
- **Max velocity:** 0.8 m/s
- **Max acceleration:** 1.0 m/s²
- **Max rotation:** 2.0 rad/s

To verify speed settings:
```bash
ros2 param get /controller_server FollowPath.max_vel_x
ros2 param get /velocity_smoother max_velocity
```

---

## Waypoint Visualization

### Method 1: RViz Markers (Recommended)

**Terminal 1:** Launch navigation (see above)

**Terminal 2:** Launch waypoint visualizer
```bash
ros2 run slam_robot waypoint_visualizer --map my_map_name
```

**Terminal 3:** Open RViz
```bash
rviz2
```

**In RViz:**
- Add → MarkerArray
- Topic: `/waypoint_markers`
- See green spheres with labels on map!

### Method 2: Check Waypoint File

```bash
# View all waypoints
cat ~/slam_maps/my_map_name_waypoints.yaml
```

### Method 3: Echo Robot Position

```bash
# See current robot position
ros2 topic echo /amcl_pose --once
```

---

## Common Commands Reference

### Build Commands

```bash
# Full build
cd ~/SLAM/slam_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash

# Build single package (faster)
colcon build --packages-select slam_robot --symlink-install
```

### Diagnostic Commands

```bash
# Check ROS2 nodes running
ros2 node list

# Check topics
ros2 topic list

# Check transforms
ros2 run tf2_ros tf2_echo map base_footprint

# Check laser scan
ros2 topic echo /scan --once

# Check velocity commands
ros2 topic echo /cmd_vel

# Check robot position
ros2 topic echo /amcl_pose --once

# Check IMU data
ros2 topic echo /imu/data --once

# Check odometry
ros2 topic echo /odom --once
```

### Map Management

```bash
# List saved maps
ls ~/slam_maps/

# View map metadata
cat ~/slam_maps/my_map_name.yaml

# View waypoints
cat ~/slam_maps/my_map_name_waypoints.yaml

# Delete a map (careful!)
rm ~/slam_maps/my_map_name.*
```

---

## Troubleshooting

### "No scan received" during mapping

**Problem:** RPLidar not working

**Solution:**
```bash
sudo chmod 666 /dev/ttyUSB0
ros2 topic hz /scan  # Should show ~8Hz
```

### "IMU not found"

**Problem:** I2C permission or connection issue

**Solution:**
```bash
i2cdetect -y 1  # Should show device at 0x68
sudo chmod 666 /dev/i2c-1
```

### Robot doesn't move

**Problem:** GPIO permissions or motor controller not running

**Solution:**
```bash
# Check motor controller running
ros2 node list | grep motor_controller

# Check velocity commands being sent
ros2 topic echo /cmd_vel

# Check GPIO group membership
groups | grep gpio
# If not in gpio group:
sudo usermod -a -G gpio $USER
# Then logout and login
```

### "No map in RViz" during navigation

**Problem:** AMCL not receiving map

**Solution:**
1. Check map file exists:
   ```bash
   ls ~/slam_maps/my_map_name.*
   ```

2. Restart navigation with correct map name:
   ```bash
   ros2 launch slam_robot navigation.launch.py map:=my_map_name
   ```

3. Check map topic:
   ```bash
   ros2 topic echo /map --once
   ```

### "Unknown waypoint: Point_X"

**Problem:** Waypoint file doesn't exist or wrong map name

**Solution:**
```bash
# List available waypoints
ros2 run slam_robot list_waypoints --map my_map_name

# Check waypoint file exists
ls ~/slam_maps/my_map_name_waypoints.yaml
```

### Robot moves very slowly

**Problem:** Speed parameters not loaded or CPU overload

**Solution:**
```bash
# Check speed settings
ros2 param get /controller_server FollowPath.max_vel_x
# Should show: 0.8

# Check actual velocity commands
ros2 topic echo /cmd_vel

# Check CPU usage
htop
```

### AMCL particles scattered (poor localization)

**Problem:** Initial pose not set correctly

**Solution:**
1. In RViz, click "2D Pose Estimate"
2. Click where robot actually is
3. Drag in direction robot is facing
4. Drive robot around to let particles converge

### Navigation times out

**Problem:** Raspberry Pi CPU overloaded

**Solution:**
- Already optimized in current config
- EKF: 15Hz (reduced from 30Hz)
- Controller: 10Hz
- Planner: 5Hz
- Timeout: 60s

### "Failed to make progress"

**Problem:** Robot stuck or path blocked

**Solution:**
- Check for obstacles in path
- Try clearing costmaps:
  ```bash
  ros2 service call /local_costmap/clear_entirely_local_costmap std_srvs/srv/Empty
  ros2 service call /global_costmap/clear_entirely_global_costmap std_srvs/srv/Empty
  ```
- Send navigation goal again

---

## Quick Start Workflows

### Quick Mapping Workflow (Flutter App)

```bash
# Terminal 1 - Launch mapping
cd ~/SLAM/slam_ws && source install/setup.bash
ros2 launch slam_robot mapping.launch.py control_mode:=manual

# Terminal 2 - Activate SLAM
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# Now use Flutter app to drive robot for 3-5 minutes

# Terminal 3 - Save map
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py office_map
```

### Quick Navigation Workflow

```bash
# Terminal 1
cd ~/SLAM/slam_ws && source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=office_map

# Terminal 2
rviz2
# Set 2D Pose Estimate in RViz

# Terminal 3
ros2 run slam_robot waypoint_visualizer --map office_map

# Terminal 4
ros2 run slam_robot list_waypoints --map office_map
ros2 run slam_robot go_to Point_B --map office_map
```

---

## System Architecture

### Mapping Phase
```
Hardware Sensors → Sensor Nodes → SLAM Toolbox → Map + Waypoints
                                      ↓
                              Auto Waypoint Generator
                                      ↓
                              Save to ~/slam_maps/
```

### Navigation Phase
```
Saved Map → Map Server → AMCL (Localization) → Nav2 Stack
                            ↓                       ↓
                    Robot Position          Path Planning
                                                    ↓
                                            Motor Commands
```

### Key Nodes

**Sensor Nodes:**
- `rplidar_node` - LaserScan from lidar
- `imu_publisher` - IMU data from MPU6050
- `odometry_publisher` - Wheel encoder odometry
- `imu_filter_madgwick_node` - Filter IMU
- `ekf_filter_node` - Fuse odometry + IMU

**Control Nodes:**
- `motor_controller` - Drive motors via GPIO
- `obstacle_avoidance` - Autonomous exploration
- `manual_control_server` - HTTP API for manual control

**SLAM/Navigation Nodes:**
- `slam_toolbox` - SLAM mapping
- `auto_waypoint_generator` - Create waypoint labels
- `map_server` - Serve saved maps
- `amcl` - Localization on saved map
- `nav2` stack - Path planning and control
- `waypoint_navigator` - Navigate to labeled waypoints
- `waypoint_visualizer` - Visualize waypoints in RViz

### TF Tree
```
map → odom → base_footprint → base_link
                                  ├─ laser
                                  ├─ imu_link
                                  ├─ left_wheel
                                  └─ right_wheel
```

**Transform Providers:**
- Mapping: `slam_toolbox` provides `map→odom`
- Navigation: `amcl` provides `map→odom`
- Always: `ekf_filter_node` provides `odom→base_footprint`

---

## Performance Tuning

### Waypoint Generation (in mapping.launch.py)

```python
waypoint_interval_time: 15.0        # Seconds between waypoints
waypoint_interval_distance: 2.5     # Meters between waypoints
min_distance_between_waypoints: 0.5 # Minimum spacing
```

### Navigation Speed (in nav2_params.yaml)

```yaml
max_vel_x: 0.8          # Max forward speed (m/s)
max_vel_theta: 2.0      # Max rotation speed (rad/s)
acc_lim_x: 1.0          # Max acceleration (m/s²)
xy_goal_tolerance: 0.15 # Goal reached threshold (m)
```

### CPU Performance (in navigation.launch.py)

```python
ekf_frequency: 15.0           # EKF update rate (Hz)
controller_frequency: 10.0    # Controller rate (Hz)
planner_frequency: 5.0        # Planner rate (Hz)
```

---

## File Locations

### Workspace Structure
```
~/SLAM/
└── slam_ws/
    ├── src/slam_robot/
    │   ├── slam_robot/          # Python nodes
    │   ├── scripts/             # CLI tools
    │   ├── launch/              # Launch files
    │   ├── config/              # Config files
    │   └── urdf/                # Robot model
    ├── build/
    ├── install/
    └── log/
```

### Maps Directory
```
~/slam_maps/
├── map_name.pgm              # Map image
├── map_name.yaml             # Map metadata
└── map_name_waypoints.yaml   # Waypoints
```

---

## Support

For issues or questions:
- Check this guide first
- Review terminal output for errors
- Check hardware connections
- Verify permissions

**Common Error Messages:**
- "No scan received" → Check RPLidar permissions
- "IMU not found" → Check I2C permissions
- "Invalid frame ID" → Check lifecycle managers active
- "Timed out" → Check CPU load, increase timeouts

---

**Created by:** Zaid
**Robot:** Wraith
**System:** ROS2 Jazzy + Nav2 + SLAM Toolbox
**Hardware:** Raspberry Pi + RPLidar A2 + MPU6050 + Encoders
