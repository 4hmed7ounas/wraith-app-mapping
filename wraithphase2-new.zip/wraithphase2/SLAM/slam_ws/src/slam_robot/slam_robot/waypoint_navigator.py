#!/usr/bin/env python3
"""
Waypoint Navigator Node

Loads saved waypoints and provides navigation interface to labeled locations.
Publishes navigation goals to Nav2 stack.

Author: Wraith Robot Team
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import yaml
import math
import os


class WaypointNavigator(Node):
    """
    Navigate to labeled waypoints created during mapping.

    Reads waypoint YAML file and publishes navigation goals to /goal_pose topic.
    """

    def __init__(self, map_name=None, waypoints_file=None, maps_directory=None):
        super().__init__('waypoint_navigator')

        # Declare parameters with optional defaults
        self.declare_parameter('waypoints_file', waypoints_file or '')
        self.declare_parameter('map_name', map_name or '')
        self.declare_parameter('maps_directory', maps_directory or '/home/zaid/slam_maps')

        # Get parameters
        waypoints_file = self.get_parameter('waypoints_file').value
        map_name = self.get_parameter('map_name').value
        maps_dir = self.get_parameter('maps_directory').value

        # Determine waypoints file path
        if waypoints_file:
            self.waypoints_file = waypoints_file
        elif map_name:
            self.waypoints_file = os.path.join(maps_dir, f"{map_name}_waypoints.yaml")
        else:
            self.get_logger().error("Must provide either 'waypoints_file' or 'map_name' parameter!")
            self.waypoints = {}
            return

        # Publisher for navigation goals
        self.goal_pub = self.create_publisher(
            PoseStamped,
            '/goal_pose',
            10
        )

        # Load waypoints
        self.waypoints = {}
        self.load_waypoints()

    def load_waypoints(self):
        """Load waypoints from YAML file"""

        if not os.path.exists(self.waypoints_file):
            self.get_logger().error(f"Waypoints file not found: {self.waypoints_file}")
            return

        try:
            with open(self.waypoints_file, 'r') as f:
                data = yaml.safe_load(f)

            # Create dictionary: label -> waypoint data
            self.waypoints = {wp['label']: wp for wp in data['waypoints']}

            self.get_logger().info("=" * 60)
            self.get_logger().info(f"✓ Loaded {len(self.waypoints)} waypoints from:")
            self.get_logger().info(f"  {self.waypoints_file}")
            self.get_logger().info("=" * 60)
            self.get_logger().info("Available waypoints:")
            for label in sorted(self.waypoints.keys()):
                wp = self.waypoints[label]
                self.get_logger().info(f"  {label}: ({wp['x']:.2f}, {wp['y']:.2f})")
            self.get_logger().info("=" * 60)

        except Exception as e:
            self.get_logger().error(f"Failed to load waypoints: {e}")
            self.waypoints = {}

    def go_to(self, label):
        """
        Navigate to a labeled waypoint.

        Args:
            label: Waypoint label (e.g., "Point_A", "Point_B")

        Returns:
            bool: True if goal was published, False otherwise
        """

        if label not in self.waypoints:
            self.get_logger().error(f"Unknown waypoint: '{label}'")
            self.get_logger().info("Available waypoints:")
            for l in sorted(self.waypoints.keys()):
                self.get_logger().info(f"  - {l}")
            return False

        wp = self.waypoints[label]

        # Create goal pose message
        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.header.stamp = self.get_clock().now().to_msg()

        # Set position
        goal.pose.position.x = float(wp['x'])
        goal.pose.position.y = float(wp['y'])
        goal.pose.position.z = 0.0

        # Convert theta (yaw) to quaternion
        theta = float(wp['theta'])
        goal.pose.orientation.x = 0.0
        goal.pose.orientation.y = 0.0
        goal.pose.orientation.z = math.sin(theta / 2.0)
        goal.pose.orientation.w = math.cos(theta / 2.0)

        # Publish goal
        self.goal_pub.publish(goal)

        self.get_logger().info("=" * 60)
        self.get_logger().info(f"✓ Navigation goal sent: {label}")
        self.get_logger().info(f"  Target: ({wp['x']:.2f}, {wp['y']:.2f}, {theta:.2f} rad)")
        self.get_logger().info("=" * 60)

        return True

    def list_waypoints(self):
        """Print all available waypoints to logger"""

        if len(self.waypoints) == 0:
            self.get_logger().warn("No waypoints loaded!")
            return

        self.get_logger().info("=" * 60)
        self.get_logger().info(f"Available Waypoints ({len(self.waypoints)} total):")
        self.get_logger().info("=" * 60)

        for label in sorted(self.waypoints.keys()):
            wp = self.waypoints[label]
            self.get_logger().info(
                f"  {label:12s} → ({wp['x']:6.2f}, {wp['y']:6.2f}, {wp['theta']:5.2f} rad)"
            )

        self.get_logger().info("=" * 60)

    def get_waypoint_list(self):
        """
        Get list of all waypoint labels.

        Returns:
            list: Sorted list of waypoint labels
        """
        return sorted(self.waypoints.keys())


def main(args=None):
    rclpy.init(args=args)
    navigator = WaypointNavigator()

    try:
        rclpy.spin(navigator)
    except KeyboardInterrupt:
        navigator.get_logger().info("Shutting down waypoint navigator...")
    finally:
        navigator.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
