#!/usr/bin/env python3
"""
Feature-Based Localizer Node

Uses environmental features (cardinal direction obstacle distances) from saved waypoints
to localize the robot on the map. Provides:
- Automatic initial pose estimation
- Map verification
- AMCL confidence monitoring
- Localization recovery

Author: Wraith Robot Team
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseArray
from std_msgs.msg import String, Bool
from std_srvs.srv import Trigger
import yaml
import math
import numpy as np
import os
from typing import Dict, List, Tuple, Optional


class FeatureBasedLocalizer(Node):
    """
    Localizes robot using environmental feature matching.

    Features:
    - Loads waypoint environmental signatures from YAML
    - Extracts current environmental features from laser scan
    - Matches current features to saved waypoints
    - Publishes initial pose estimate for AMCL
    - Monitors AMCL particle convergence
    - Detects and recovers from localization failures
    """

    def __init__(self):
        super().__init__('feature_based_localizer')

        # Declare parameters
        self.declare_parameter('map_name', 'auto_generated_map')
        self.declare_parameter('waypoints_directory', '/home/zaid/slam_maps')
        self.declare_parameter('auto_initialize', True)  # Auto-set initial pose
        self.declare_parameter('match_threshold', 0.3)  # Max avg distance error for match (meters)
        self.declare_parameter('confidence_threshold', 0.7)  # AMCL confidence threshold
        self.declare_parameter('verification_interval', 5.0)  # Seconds between verifications

        # Get parameters
        self.map_name = self.get_parameter('map_name').value
        self.waypoints_dir = self.get_parameter('waypoints_directory').value
        self.auto_initialize = self.get_parameter('auto_initialize').value
        self.match_threshold = self.get_parameter('match_threshold').value
        self.confidence_threshold = self.get_parameter('confidence_threshold').value
        self.verification_interval = self.get_parameter('verification_interval').value

        # State
        self.waypoints = []
        self.current_scan = None
        self.amcl_pose = None
        self.amcl_particles = None
        self.is_localized = False
        self.map_verified = False
        self.initialization_done = False

        # Load waypoints
        self.load_waypoints()

        # QoS profiles
        scan_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        amcl_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        # Subscribers
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            scan_qos
        )

        self.amcl_pose_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/amcl_pose',
            self.amcl_pose_callback,
            amcl_qos
        )

        self.particle_sub = self.create_subscription(
            PoseArray,
            '/particlecloud',
            self.particle_callback,
            amcl_qos
        )

        # Publishers
        self.initial_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped,
            '/initialpose',
            10
        )

        self.map_verification_pub = self.create_publisher(
            Bool,
            '/map_verified',
            10
        )

        self.localization_status_pub = self.create_publisher(
            String,
            '/localization_status',
            10
        )

        # Services
        self.init_service = self.create_service(
            Trigger,
            '/relocalize',
            self.relocalize_callback
        )

        # Timers
        self.verify_timer = self.create_timer(
            self.verification_interval,
            self.verify_map_and_localization
        )

        self.get_logger().info("=" * 70)
        self.get_logger().info("Feature-Based Localizer Started")
        self.get_logger().info("=" * 70)
        self.get_logger().info(f"Map: {self.map_name}")
        self.get_logger().info(f"Loaded {len(self.waypoints)} waypoints with features")
        self.get_logger().info(f"Auto-initialize: {self.auto_initialize}")
        self.get_logger().info(f"Match threshold: {self.match_threshold}m")
        self.get_logger().info("=" * 70)

    def load_waypoints(self):
        """Load waypoint data from YAML file"""
        waypoint_file = os.path.join(
            self.waypoints_dir,
            f"{self.map_name}_waypoints.yaml"
        )

        try:
            with open(waypoint_file, 'r') as f:
                data = yaml.safe_load(f)
                self.waypoints = data.get('waypoints', [])

            # Filter waypoints that have environmental features
            self.waypoints = [
                wp for wp in self.waypoints
                if 'environmental_features' in wp and wp['environmental_features'] is not None
            ]

            self.get_logger().info(
                f"Loaded {len(self.waypoints)} waypoints with environmental features"
            )

        except FileNotFoundError:
            self.get_logger().error(f"Waypoint file not found: {waypoint_file}")
            self.waypoints = []
        except Exception as e:
            self.get_logger().error(f"Error loading waypoints: {e}")
            self.waypoints = []

    def scan_callback(self, msg):
        """Store latest laser scan"""
        self.current_scan = msg

        # Auto-initialize as soon as we have scan data
        # Try every scan until successful (max 10 attempts)
        if self.auto_initialize and not self.initialization_done and len(self.waypoints) > 0:
            if not hasattr(self, '_init_attempts'):
                self._init_attempts = 0

            if self._init_attempts < 10:
                self._init_attempts += 1
                self.get_logger().info(
                    f"Auto-initializing pose using feature matching (attempt {self._init_attempts}/10)..."
                )
                success = self.estimate_initial_pose()
                if success:
                    self.initialization_done = True
                    self.get_logger().info("✓ Auto-initialization successful!")
            else:
                self.get_logger().warn("Auto-initialization failed after 10 attempts. Use RViz 2D Pose Estimate.")
                self.initialization_done = True  # Stop trying

    def amcl_pose_callback(self, msg):
        """Track AMCL's pose estimate"""
        self.amcl_pose = msg

    def particle_callback(self, msg):
        """Monitor AMCL particle cloud for convergence"""
        self.amcl_particles = msg

        # Calculate particle spread to assess localization confidence
        if len(msg.poses) > 0:
            confidence = self.calculate_particle_confidence(msg.poses)

            if confidence > self.confidence_threshold:
                if not self.is_localized:
                    self.get_logger().info(f"✓ Localized! Confidence: {confidence:.2f}")
                self.is_localized = True
            else:
                if self.is_localized:
                    self.get_logger().warn(
                        f"⚠ Lost localization! Confidence: {confidence:.2f} "
                        f"(threshold: {self.confidence_threshold})"
                    )
                self.is_localized = False

    def relocalize_callback(self, request, response):
        """
        Service callback to manually trigger relocalization.
        Call with: ros2 service call /relocalize std_srvs/Trigger
        """
        self.get_logger().info("=== Manual Relocalization Requested ===")

        if self.current_scan is None:
            response.success = False
            response.message = "No scan data available. Cannot relocalize."
            return response

        if len(self.waypoints) == 0:
            response.success = False
            response.message = "No waypoints loaded. Cannot relocalize."
            return response

        # Force re-initialization
        self.initialization_done = False
        success = self.estimate_initial_pose()

        if success:
            response.success = True
            response.message = "Relocalization successful! Initial pose published to AMCL."
            self.initialization_done = True
        else:
            response.success = False
            response.message = "Relocalization failed. No matching waypoints found."

        return response

    def calculate_particle_confidence(self, particles: List) -> float:
        """
        Calculate localization confidence from particle spread.

        Returns value between 0 (scattered) and 1 (converged)
        """
        if len(particles) < 2:
            return 0.0

        # Calculate mean position
        mean_x = np.mean([p.position.x for p in particles])
        mean_y = np.mean([p.position.y for p in particles])

        # Calculate standard deviation
        std_dev = np.mean([
            np.sqrt((p.position.x - mean_x)**2 + (p.position.y - mean_y)**2)
            for p in particles
        ])

        # Convert to confidence (0.5m spread = 0.5 confidence, 0.1m = 0.9, etc.)
        confidence = max(0.0, min(1.0, 1.0 - std_dev))

        return confidence

    def extract_cardinal_distances(self, scan: LaserScan) -> Optional[Dict[str, float]]:
        """
        Extract obstacle distances in 8 cardinal directions from laser scan.
        Same implementation as auto_waypoint_generator.
        """
        if scan is None:
            return None

        cardinal_angles = {
            'north': 0.0,
            'northeast': np.pi / 4,
            'east': np.pi / 2,
            'southeast': 3 * np.pi / 4,
            'south': np.pi,
            'southwest': -3 * np.pi / 4,
            'west': -np.pi / 2,
            'northwest': -np.pi / 4
        }

        distances = {}

        for direction, target_angle in cardinal_angles.items():
            angle_diff = target_angle - scan.angle_min

            # Handle wraparound
            while angle_diff > np.pi:
                angle_diff -= 2 * np.pi
            while angle_diff < -np.pi:
                angle_diff += 2 * np.pi

            if scan.angle_increment != 0:
                index = int(round(angle_diff / scan.angle_increment))
                index = max(0, min(index, len(scan.ranges) - 1))

                distance = scan.ranges[index]

                if np.isfinite(distance) and scan.range_min <= distance <= scan.range_max:
                    distances[direction] = float(distance)
                else:
                    distances[direction] = float(scan.range_max)
            else:
                distances[direction] = None

        return distances

    def calculate_feature_similarity(
        self,
        current_features: Dict[str, float],
        saved_features: Dict[str, float]
    ) -> Tuple[float, float]:
        """
        Calculate similarity between current and saved environmental features.

        Returns:
            (similarity_score, average_error) where:
            - similarity_score: 0-1, higher is better match
            - average_error: average distance error in meters
        """
        if current_features is None or saved_features is None:
            return 0.0, float('inf')

        errors = []
        for direction in current_features.keys():
            if direction in saved_features:
                current_dist = current_features[direction]
                saved_dist = saved_features[direction]

                if current_dist is not None and saved_dist is not None:
                    error = abs(current_dist - saved_dist)
                    errors.append(error)

        if len(errors) == 0:
            return 0.0, float('inf')

        avg_error = np.mean(errors)
        # Convert error to similarity score (exponential decay)
        similarity = np.exp(-avg_error / 1.0)  # 1m error = 0.37 similarity

        return similarity, avg_error

    def find_best_matching_waypoint(self) -> Optional[Tuple[dict, float, float]]:
        """
        Find waypoint that best matches current environment.

        Returns:
            (waypoint, similarity_score, avg_error) or None if no good match
        """
        if self.current_scan is None or len(self.waypoints) == 0:
            self.get_logger().warn("No scan data or no waypoints loaded")
            return None

        current_features = self.extract_cardinal_distances(self.current_scan)
        if current_features is None:
            self.get_logger().warn("Could not extract features from current scan")
            return None

        best_match = None
        best_similarity = 0.0
        best_error = float('inf')

        # Debug: Show current environment
        current_summary = ", ".join([
            f"{d[:2].upper()}:{dist:.2f}m"
            for d, dist in current_features.items()
        ])
        self.get_logger().info(f"Current environment: {current_summary}")

        # Try all waypoints and log scores
        for waypoint in self.waypoints:
            saved_features = waypoint.get('environmental_features')
            if saved_features is None:
                continue

            similarity, avg_error = self.calculate_feature_similarity(
                current_features,
                saved_features
            )

            label = waypoint.get('label', 'Unknown')
            self.get_logger().info(
                f"  {label}: similarity={similarity:.3f}, error={avg_error:.2f}m"
            )

            if similarity > best_similarity and avg_error < self.match_threshold:
                best_match = waypoint
                best_similarity = similarity
                best_error = avg_error

        if best_match:
            self.get_logger().info(
                f"Best match: {best_match['label']} (sim={best_similarity:.3f}, err={best_error:.2f}m)"
            )
            return best_match, best_similarity, best_error
        else:
            self.get_logger().warn(
                f"No matches under threshold {self.match_threshold}m. "
                f"Best was: similarity={best_similarity:.3f}, error={best_error:.2f}m"
            )
        return None

    def estimate_initial_pose(self):
        """
        Estimate robot's initial pose using feature matching.
        Publishes to /initialpose for AMCL initialization.

        Returns:
            bool: True if successful, False otherwise
        """
        result = self.find_best_matching_waypoint()

        if result is None:
            self.get_logger().warn("Could not find matching waypoint for initialization")
            return False

        waypoint, similarity, error = result

        self.get_logger().info(
            f"✓ Best match: {waypoint['label']} "
            f"(similarity: {similarity:.2f}, error: {error:.2f}m)"
        )

        # Create initial pose message
        pose_msg = PoseWithCovarianceStamped()
        pose_msg.header.stamp = self.get_clock().now().to_msg()
        pose_msg.header.frame_id = 'map'

        # Set position from matched waypoint
        pose_msg.pose.pose.position.x = waypoint['x']
        pose_msg.pose.pose.position.y = waypoint['y']
        pose_msg.pose.pose.position.z = 0.0

        # Set orientation from matched waypoint
        theta = waypoint['theta']
        pose_msg.pose.pose.orientation.z = math.sin(theta / 2.0)
        pose_msg.pose.pose.orientation.w = math.cos(theta / 2.0)

        # Set covariance (uncertainty)
        # Lower uncertainty for better matches
        uncertainty = error * 2.0  # Scale error to uncertainty
        covariance = [0.0] * 36
        covariance[0] = uncertainty  # x uncertainty
        covariance[7] = uncertainty  # y uncertainty
        covariance[35] = 0.1  # theta uncertainty
        pose_msg.pose.covariance = covariance

        # Publish initial pose
        self.initial_pose_pub.publish(pose_msg)

        self.get_logger().info(
            f"✓ Published initial pose at ({waypoint['x']:.2f}, {waypoint['y']:.2f}, {theta:.2f})"
        )

        return True

    def verify_map_and_localization(self):
        """
        Periodic verification of map correctness and localization quality.
        Called by timer every verification_interval seconds.
        """
        if self.current_scan is None or len(self.waypoints) == 0:
            return

        # Find best matching waypoint
        result = self.find_best_matching_waypoint()

        if result is None:
            # No matches found - might be wrong map or bad location
            self.map_verified = False
            self.map_verification_pub.publish(Bool(data=False))

            status_msg = String()
            status_msg.data = "WARN: No matching waypoints found. Wrong map or unmapped area?"
            self.localization_status_pub.publish(status_msg)

            self.get_logger().warn(
                "⚠ No waypoint matches found! "
                "Robot might be on wrong map or in unmapped area."
            )
            return

        waypoint, similarity, error = result

        # Map is verified if we have good matches
        if similarity > 0.5 and error < self.match_threshold * 2:
            if not self.map_verified:
                self.get_logger().info("✓ Map verified! Environment matches saved data.")

            self.map_verified = True
            self.map_verification_pub.publish(Bool(data=True))

            # Check if AMCL pose agrees with feature-based match
            if self.amcl_pose is not None:
                amcl_x = self.amcl_pose.pose.pose.position.x
                amcl_y = self.amcl_pose.pose.pose.position.y

                distance_to_match = math.sqrt(
                    (amcl_x - waypoint['x'])**2 +
                    (amcl_y - waypoint['y'])**2
                )

                if distance_to_match > 2.0:  # AMCL disagrees by >2m
                    self.get_logger().warn(
                        f"⚠ AMCL pose mismatch! Feature match: {waypoint['label']}, "
                        f"AMCL distance: {distance_to_match:.2f}m. "
                        f"Consider re-initialization."
                    )

                    status_msg = String()
                    status_msg.data = f"WARN: Localization drift detected ({distance_to_match:.2f}m)"
                    self.localization_status_pub.publish(status_msg)
                else:
                    status_msg = String()
                    status_msg.data = f"OK: Near {waypoint['label']} (error: {error:.2f}m)"
                    self.localization_status_pub.publish(status_msg)
        else:
            self.map_verified = False
            self.map_verification_pub.publish(Bool(data=False))


def main(args=None):
    rclpy.init(args=args)
    node = FeatureBasedLocalizer()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down Feature-Based Localizer...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
