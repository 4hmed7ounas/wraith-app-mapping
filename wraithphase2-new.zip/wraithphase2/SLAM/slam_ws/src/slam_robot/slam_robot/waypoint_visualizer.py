#!/usr/bin/env python3
"""
Waypoint Visualizer

Publishes waypoint markers to RViz for visualization.
Shows waypoint labels and positions on the map.

Usage:
    ros2 run slam_robot waypoint_visualizer --map test_qos_fix
"""

import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
import yaml
import os


class WaypointVisualizer(Node):
    def __init__(self, map_name=None):
        super().__init__('waypoint_visualizer')

        # Declare parameters
        self.declare_parameter('map_name', map_name if map_name else 'auto_generated_map')
        self.declare_parameter('maps_directory', '/home/zaid/slam_maps')

        # Get parameters
        self.map_name = self.get_parameter('map_name').value
        self.maps_directory = self.get_parameter('maps_directory').value

        # Publisher for waypoint markers
        self.marker_pub = self.create_publisher(
            MarkerArray,
            '/waypoint_markers',
            10
        )

        # Load waypoints
        self.waypoints = self.load_waypoints()

        # Publish markers every 2 seconds to keep them visible
        self.timer = self.create_timer(2.0, self.publish_markers)

        self.get_logger().info(f"Waypoint Visualizer started for map '{map_name}'")
        self.get_logger().info(f"Publishing {len(self.waypoints)} waypoint markers to /waypoint_markers")
        self.get_logger().info("Add 'MarkerArray' display in RViz with topic /waypoint_markers")

    def load_waypoints(self):
        """Load waypoints from YAML file"""
        waypoints_file = os.path.join(
            self.maps_directory,
            f"{self.map_name}_waypoints.yaml"
        )

        if not os.path.exists(waypoints_file):
            self.get_logger().error(f"Waypoints file not found: {waypoints_file}")
            return []

        with open(waypoints_file, 'r') as f:
            data = yaml.safe_load(f)

        waypoints = data.get('waypoints', [])
        self.get_logger().info(f"Loaded {len(waypoints)} waypoints from {waypoints_file}")

        return waypoints

    def publish_markers(self):
        """Publish waypoint markers for RViz visualization"""
        marker_array = MarkerArray()

        for idx, waypoint in enumerate(self.waypoints):
            label = waypoint.get('label', f'Point_{idx}')
            x = waypoint.get('x', 0.0)
            y = waypoint.get('y', 0.0)

            # Create sphere marker for waypoint position
            sphere_marker = Marker()
            sphere_marker.header.frame_id = "map"
            sphere_marker.header.stamp = self.get_clock().now().to_msg()
            sphere_marker.ns = "waypoint_spheres"
            sphere_marker.id = idx
            sphere_marker.type = Marker.SPHERE
            sphere_marker.action = Marker.ADD

            # Position
            sphere_marker.pose.position.x = x
            sphere_marker.pose.position.y = y
            sphere_marker.pose.position.z = 0.0
            sphere_marker.pose.orientation.w = 1.0

            # Size
            sphere_marker.scale.x = 0.2
            sphere_marker.scale.y = 0.2
            sphere_marker.scale.z = 0.2

            # Color: Green
            sphere_marker.color.r = 0.0
            sphere_marker.color.g = 1.0
            sphere_marker.color.b = 0.0
            sphere_marker.color.a = 1.0

            # Duration
            sphere_marker.lifetime.sec = 0  # 0 = forever

            marker_array.markers.append(sphere_marker)

            # Create text marker for waypoint label
            text_marker = Marker()
            text_marker.header.frame_id = "map"
            text_marker.header.stamp = self.get_clock().now().to_msg()
            text_marker.ns = "waypoint_labels"
            text_marker.id = idx + 1000  # Offset ID to avoid collision
            text_marker.type = Marker.TEXT_VIEW_FACING
            text_marker.action = Marker.ADD

            # Position (slightly above sphere)
            text_marker.pose.position.x = x
            text_marker.pose.position.y = y
            text_marker.pose.position.z = 0.3
            text_marker.pose.orientation.w = 1.0

            # Text
            text_marker.text = label

            # Size
            text_marker.scale.z = 0.15  # Text height

            # Color: White
            text_marker.color.r = 1.0
            text_marker.color.g = 1.0
            text_marker.color.b = 1.0
            text_marker.color.a = 1.0

            # Duration
            text_marker.lifetime.sec = 0  # 0 = forever

            marker_array.markers.append(text_marker)

        # Publish markers
        self.marker_pub.publish(marker_array)


def main():
    import sys

    # Parse map name argument
    map_name = ''
    if len(sys.argv) > 1:
        if sys.argv[1] == '--map' and len(sys.argv) > 2:
            map_name = sys.argv[2]
        else:
            map_name = sys.argv[1]

    if not map_name:
        print("=" * 60)
        print("ERROR: Map name required!")
        print("=" * 60)
        print("Usage:")
        print("  ros2 run slam_robot waypoint_visualizer --map <map_name>")
        print("\nExample:")
        print("  ros2 run slam_robot waypoint_visualizer --map test_qos_fix")
        print("=" * 60)
        sys.exit(1)

    # Initialize ROS2
    rclpy.init()

    try:
        node = WaypointVisualizer(map_name=map_name)

        print("=" * 60)
        print("Waypoint Visualizer Running")
        print("=" * 60)
        print(f"Map: {map_name}")
        print(f"Waypoints: {len(node.waypoints)}")
        print("\nIn RViz:")
        print("  1. Click 'Add' button")
        print("  2. Select 'MarkerArray'")
        print("  3. Set Topic: /waypoint_markers")
        print("  4. You'll see green spheres with labels!")
        print("=" * 60)

        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\nShutting down waypoint visualizer...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
