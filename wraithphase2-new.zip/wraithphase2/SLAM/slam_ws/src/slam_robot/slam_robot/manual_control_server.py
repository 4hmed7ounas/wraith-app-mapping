#!/usr/bin/env python3
"""
Manual Control Server Node - Flask-based web API for manual robot control

Provides HTTP endpoints for manual control during SLAM mapping:
- GET  /              - API status
- GET  /get_ip        - Get robot's IP address
- GET  /get_distance  - Get ultrasonic sensor reading
- POST /control       - Send control commands

Control commands:
- forward_start, forward_stop
- backward_start, backward_stop
- left_start, left_stop
- right_start, right_stop
- speed+, speed- (adjust speed)
- auto_start, auto_stop (toggle autonomous mode)

Usage:
    ros2 run slam_robot manual_control_server

Then control via HTTP:
    curl -X POST http://<robot-ip>:5000/control -d "forward_start"
    curl -X POST http://<robot-ip>:5000/control -d "forward_stop"

Author: Wraith Robot Team
"""

import rclpy
from rclpy.node import Node
from flask import Flask, request, jsonify
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from gpiozero import PWMOutputDevice, OutputDevice, Button, DistanceSensor, AngularServo
from time import sleep
import threading
import fcntl
import struct
import socket
import signal
import sys
import math

app = Flask(__name__)

# Global reference to ROS node (set in main)
ros_node = None

# ——— Motor A Control Pins (BTS7960) ———
RPWM_A = PWMOutputDevice(18)
LPWM_A = PWMOutputDevice(23)
REN_A = OutputDevice(24)
LEN_A = OutputDevice(25)

# ——— Motor B Control Pins (BTS7960) ———
RPWM_B = PWMOutputDevice(22)
LPWM_B = PWMOutputDevice(27)
REN_B = OutputDevice(5)
LEN_B = OutputDevice(6)

# ——— Encoder Pins ———
ENC_A_A = Button(17, bounce_time=0.005)
ENC_A_B = Button(4)
ENC_B_A = Button(19, bounce_time=0.005)
ENC_B_B = Button(13)

# ——— Distance Sensor & Servo (for auto mode) ———
sensor = DistanceSensor(echo=21, trigger=20)
servo = AngularServo(12, min_angle=-85, max_angle=85,
                     min_pulse_width=0.0005, max_pulse_width=0.0025)

# ——— Specs & Globals ———
PULSES_PER_REV = 500
WHEEL_CIRCUMFERENCE_CM = 20.42
WHEEL_CIRCUMFERENCE_M = 0.2042  # meters
WHEEL_SEPARATION_M = 0.21336  # meters (0.7 feet)

tick_count_A = tick_count_B = 0
direction_A = direction_B = 1
lock_A = threading.Lock()
lock_B = threading.Lock()

current_speed = 0.3
obstacle_threshold = 20  # cm
auto_mode = False
auto_thread = None


# ——— Encoder Callbacks ———
def on_encoder_tick_A():
    global tick_count_A, direction_A
    direction_A = 1 if ENC_A_B.value == 0 else -1
    with lock_A:
        tick_count_A += direction_A


def on_encoder_tick_B():
    global tick_count_B, direction_B
    direction_B = 1 if ENC_B_B.value == 0 else -1
    with lock_B:
        tick_count_B += direction_B


ENC_A_A.when_pressed = on_encoder_tick_A
ENC_B_A.when_pressed = on_encoder_tick_B


# ——— Motor primitives ———
def set_motor_A(speed):
    speed = max(min(speed, 1.0), -1.0)
    if speed > 0:
        LPWM_A.value = 0
        RPWM_A.value = speed
    elif speed < 0:
        RPWM_A.value = 0
        LPWM_A.value = abs(speed)
    else:
        RPWM_A.value = LPWM_A.value = 0


def set_motor_B(speed):
    speed = max(min(speed, 1.0), -1.0)
    if speed > 0:
        LPWM_B.value = 0
        RPWM_B.value = speed
    elif speed < 0:
        RPWM_B.value = 0
        LPWM_B.value = abs(speed)
    else:
        RPWM_B.value = LPWM_B.value = 0


def enable_motors():
    REN_A.on()
    LEN_A.on()
    REN_B.on()
    LEN_B.on()


def disable_motors():
    RPWM_A.value = LPWM_A.value = 0
    REN_A.off()
    LEN_A.off()
    RPWM_B.value = LPWM_B.value = 0
    REN_B.off()
    LEN_B.off()


# ——— Movement funcs matching old API ———
def move_forward(speed):
    set_motor_A(speed)
    set_motor_B(speed)


def move_backward(speed):
    set_motor_A(-speed)
    set_motor_B(-speed)


def move_left(speed):
    set_motor_A(speed)
    set_motor_B(-speed)


def move_right(speed):
    set_motor_A(-speed)
    set_motor_B(speed)


def stop_motors():
    set_motor_A(0)
    set_motor_B(0)


def increase_speed():
    global current_speed
    current_speed = min(current_speed + 0.1, 1.0)
    return current_speed


def decrease_speed():
    global current_speed
    current_speed = max(current_speed - 0.1, 0.0)
    return current_speed


# ——— Smooth Servo Sweep ———
def sweep_servo(target, step=5, delay=0.03):
    target = max(-85, min(85, target))
    cur = int(servo.angle or 0)
    rng = range(cur, target + 1, step) if target > cur else range(cur, target - 1, -step)
    for a in rng:
        servo.angle = max(-85, min(85, a))
        sleep(delay)


# ——— Auto Mode Logic ———
def auto_mode_function():
    global auto_mode
    enable_motors()
    if ros_node:
        ros_node.get_logger().info('Auto mode started')

    while auto_mode:
        try:
            sweep_servo(0)
            front = sensor.distance * 100

            if front < obstacle_threshold:
                stop_motors()
                # scan right
                sweep_servo(85)
                right = sensor.distance * 100
                # scan left
                sweep_servo(-85)
                left = sensor.distance * 100
                sweep_servo(0)

                move_backward(current_speed)
                sleep(0.5)
                stop_motors()

                if right > left:
                    move_right(current_speed)
                else:
                    move_left(current_speed)
                sleep(0.6)
                stop_motors()
            else:
                move_forward(current_speed)

            sleep(0.1)
        except Exception as e:
            if ros_node:
                ros_node.get_logger().error(f'Auto mode error: {e}')
            stop_motors()

    stop_motors()
    if ros_node:
        ros_node.get_logger().info('Auto mode stopped')


# ——— IP helper ———
def get_ip_address(ifname='wlan0'):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ip = fcntl.ioctl(
            s.fileno(), 0x8915,
            struct.pack('256s', bytes(ifname[:15], 'utf-8'))
        )[20:24]
        return socket.inet_ntoa(ip)
    except:
        return '127.0.0.1'


# ——— Flask Routes ———
@app.route('/', methods=['GET'])
def index():
    if ros_node:
        ros_node.get_logger().info('[📱] Flutter app connected - Status check')
    return 'Manual Control Server Online - ROS2 SLAM Robot\n'


@app.route('/get_ip', methods=['GET'])
def get_ip():
    if ros_node:
        ros_node.get_logger().info('[📱] Flutter app requested IP address')
    return jsonify({'ip': get_ip_address()})


@app.route('/get_distance', methods=['GET'])
def get_distance():
    dist = round(sensor.distance * 100, 2)
    if ros_node:
        ros_node.get_logger().info(f'[📏] Distance sensor: {dist} cm')
    return jsonify({'distance': dist})


@app.route('/control', methods=['POST'])
def control():
    global auto_mode, auto_thread
    cmd = request.data.decode().strip()

    # — Auto Mode Commands —
    if cmd == 'auto_start':
        if not auto_mode:
            auto_mode = True
            auto_thread = threading.Thread(target=auto_mode_function, daemon=True)
            auto_thread.start()
            if ros_node:
                ros_node.get_logger().info('='*70)
                ros_node.get_logger().info('[🤖] AUTO MODE ENABLED - Robot exploring autonomously')
                ros_node.get_logger().info('='*70)
            return 'Auto mode started\n'
        return 'Already in auto mode\n'

    if cmd == 'auto_stop':
        if auto_mode:
            auto_mode = False
            stop_motors()
            enable_motors()
            if ros_node:
                ros_node.get_logger().info('='*70)
                ros_node.get_logger().info('[👤] MANUAL MODE ENABLED - Waiting for app commands')
                ros_node.get_logger().info('='*70)
            return 'Auto mode stopped\n'
        return 'Auto mode not active\n'

    # — Manual Commands —
    actions = {
        'forward_start': lambda: move_forward(current_speed),
        'forward_stop': stop_motors,
        'backward_start': lambda: move_backward(current_speed),
        'backward_stop': stop_motors,
        'left_start': lambda: move_left(current_speed),
        'left_stop': stop_motors,
        'right_start': lambda: move_right(current_speed),
        'right_stop': stop_motors,
        'speed+': increase_speed,
        'speed-': decrease_speed
    }

    if cmd in actions:
        # if manual command issued, immediately stop auto mode
        if auto_mode:
            auto_mode = False
            stop_motors()
            enable_motors()
            if ros_node:
                ros_node.get_logger().info('[!] Auto mode interrupted by manual command')

        # Always ensure motors are enabled before manual commands
        enable_motors()
        result = actions[cmd]()

        # Enhanced logging for all commands
        if ros_node:
            if cmd == 'forward_start':
                ros_node.get_logger().info(f'[⬆️] Moving FORWARD at {current_speed*100:.0f}% speed')
            elif cmd == 'backward_start':
                ros_node.get_logger().info(f'[⬇️] Moving BACKWARD at {current_speed*100:.0f}% speed')
            elif cmd == 'left_start':
                ros_node.get_logger().info(f'[⬅️] Turning LEFT at {current_speed*100:.0f}% speed')
            elif cmd == 'right_start':
                ros_node.get_logger().info(f'[➡️] Turning RIGHT at {current_speed*100:.0f}% speed')
            elif cmd.endswith('_stop'):
                ros_node.get_logger().info('[⏹️] STOPPED')
            elif cmd == 'speed+':
                ros_node.get_logger().info(f'[⚡] Speed INCREASED to {current_speed*100:.0f}%')
            elif cmd == 'speed-':
                ros_node.get_logger().info(f'[🐌] Speed DECREASED to {current_speed*100:.0f}%')

        return f'{cmd} executed\n'

    return 'Unknown command\n', 400


# ——— ROS2 Node Wrapper ———
class ManualControlServerNode(Node):
    def __init__(self):
        super().__init__('manual_control_server')

        # Get parameters
        self.declare_parameter('port', 5000)
        self.port = self.get_parameter('port').value

        # Odometry state (for publishing /odom topic)
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_time = self.get_clock().now()

        # Create odometry publisher and TF broadcaster
        self.odom_pub = self.create_publisher(Odometry, 'odom', 50)
        self.tf_broadcaster = TransformBroadcaster(self)

        # Timer for odometry calculation (50Hz, same as odometry_publisher)
        self.odom_timer = self.create_timer(0.02, self.update_odometry)

        self.get_logger().info('='*70)
        self.get_logger().info('      MANUAL CONTROL SERVER - WAITING FOR FLUTTER APP')
        self.get_logger().info('='*70)

        # Enable motors on startup
        enable_motors()
        self.get_logger().info('[✓] Motors enabled')
        self.get_logger().info('[✓] Odometry publisher started (publishing to /odom at 50Hz)')

        # Get and display IP address
        ip = get_ip_address()
        self.get_logger().info('')
        self.get_logger().info('  █████████████████████████████████████████████████████████████')
        self.get_logger().info(f'  ███  ROBOT IP ADDRESS: {ip.ljust(38)}███')
        self.get_logger().info(f'  ███  PORT: {str(self.port).ljust(53)}███')
        self.get_logger().info('  █████████████████████████████████████████████████████████████')
        self.get_logger().info('')
        self.get_logger().info(f'[★] Enter this IP in your Flutter app: {ip}')
        self.get_logger().info(f'[★] Server listening on: http://{ip}:{self.port}')
        self.get_logger().info('')
        self.get_logger().info('='*70)
        self.get_logger().info('Flutter App Commands Supported:')
        self.get_logger().info('='*70)
        self.get_logger().info('  • forward_start, forward_stop    - Move forward/stop')
        self.get_logger().info('  • backward_start, backward_stop  - Move backward/stop')
        self.get_logger().info('  • left_start, left_stop          - Turn left/stop')
        self.get_logger().info('  • right_start, right_stop        - Turn right/stop')
        self.get_logger().info('  • speed+, speed-                 - Increase/decrease speed')
        self.get_logger().info('  • auto_start, auto_stop          - Toggle autonomous mode')
        self.get_logger().info('='*70)
        self.get_logger().info(f'Current speed: {current_speed * 100:.0f}%')
        self.get_logger().info('='*70)

        # Start Flask in separate thread
        self.flask_thread = threading.Thread(
            target=self._run_flask_server,
            daemon=True
        )
        self.flask_thread.start()

        self.get_logger().info('')
        self.get_logger().info('[✓] HTTP server started successfully')
        self.get_logger().info('[⏳] Waiting for Flutter app to connect...')
        self.get_logger().info('')
        self.get_logger().info('='*70)

    def _run_flask_server(self):
        """Run Flask server in background thread"""
        app.run(host='0.0.0.0', port=self.port, debug=False, use_reloader=False)

    def update_odometry(self):
        """
        Calculate and publish odometry from encoder ticks.
        Called at 50Hz by timer. Same logic as odometry_publisher.py
        """
        global tick_count_A, tick_count_B, lock_A, lock_B

        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9

        if dt <= 0:
            return

        # Get encoder ticks and reset
        with lock_A:
            ticks_A = tick_count_A
            tick_count_A = 0

        with lock_B:
            ticks_B = tick_count_B
            tick_count_B = 0

        # Calculate distance traveled by each wheel
        dist_A = (ticks_A / PULSES_PER_REV) * WHEEL_CIRCUMFERENCE_M
        dist_B = (ticks_B / PULSES_PER_REV) * WHEEL_CIRCUMFERENCE_M

        # Calculate robot displacement
        dist_center = (dist_A + dist_B) / 2.0
        delta_theta = (dist_B - dist_A) / WHEEL_SEPARATION_M

        # Update pose
        if abs(delta_theta) < 1e-6:
            # Straight line motion
            delta_x = dist_center * math.cos(self.theta)
            delta_y = dist_center * math.sin(self.theta)
        else:
            # Arc motion
            radius = dist_center / delta_theta
            delta_x = radius * (math.sin(self.theta + delta_theta) - math.sin(self.theta))
            delta_y = -radius * (math.cos(self.theta + delta_theta) - math.cos(self.theta))

        self.x += delta_x
        self.y += delta_y
        self.theta += delta_theta

        # Normalize theta
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

        # Calculate velocities
        vx = dist_center / dt if dt > 0 else 0.0
        vth = delta_theta / dt if dt > 0 else 0.0

        # Publish odometry message
        odom = Odometry()
        odom.header.stamp = current_time.to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_footprint'

        # Position
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0

        # Orientation (quaternion from theta)
        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0
        odom.pose.pose.orientation.z = math.sin(self.theta / 2.0)
        odom.pose.pose.orientation.w = math.cos(self.theta / 2.0)

        # Velocity
        odom.twist.twist.linear.x = vx
        odom.twist.twist.linear.y = 0.0
        odom.twist.twist.angular.z = vth

        # Covariance
        odom.pose.covariance[0] = 0.01   # x
        odom.pose.covariance[7] = 0.01   # y
        odom.pose.covariance[35] = 0.01  # theta

        self.odom_pub.publish(odom)

        # Publish transform
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_footprint'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = math.sin(self.theta / 2.0)
        t.transform.rotation.w = math.cos(self.theta / 2.0)

        self.tf_broadcaster.sendTransform(t)

        self.last_time = current_time

    def cleanup(self):
        """Cleanup on shutdown"""
        global auto_mode
        self.get_logger().info('Shutting down manual control server...')
        auto_mode = False
        disable_motors()
        self.get_logger().info('Motors disabled')


def main(args=None):
    global ros_node

    # Initialize ROS2
    rclpy.init(args=args)

    # Create node
    ros_node = ManualControlServerNode()

    # Setup signal handlers for graceful shutdown
    def signal_handler(sig, frame):
        ros_node.get_logger().info('Interrupt received, shutting down...')
        ros_node.cleanup()
        rclpy.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        # Spin the node
        rclpy.spin(ros_node)
    except KeyboardInterrupt:
        pass
    finally:
        ros_node.cleanup()
        ros_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
