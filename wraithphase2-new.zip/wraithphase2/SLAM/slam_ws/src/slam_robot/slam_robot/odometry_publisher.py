#!/usr/bin/env python3
"""
Odometry publisher node - uses wheel encoders to calculate and publish odometry
"""
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from gpiozero import Button
import math
import threading

class OdometryPublisher(Node):
    def __init__(self):
        super().__init__('odometry_publisher')

        # Encoder pins
        self.ENC_A_A = Button(17, bounce_time=0.005)
        self.ENC_A_B = Button(4)
        self.ENC_B_A = Button(19, bounce_time=0.005)
        self.ENC_B_B = Button(13)

        # Robot specs
        self.PULSES_PER_REV = 500
        self.WHEEL_CIRCUMFERENCE = 0.2042  # meters (20.42cm)
        self.WHEEL_SEPARATION = 0.21336  # meters (0.7 feet)

        # Encoder state
        self.tick_count_A = 0
        self.tick_count_B = 0
        self.direction_A = 1
        self.direction_B = 1
        self.lock_A = threading.Lock()
        self.lock_B = threading.Lock()

        # Odometry state
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_time = self.get_clock().now()

        # Setup encoder callbacks
        self.ENC_A_A.when_pressed = self.on_encoder_tick_A
        self.ENC_B_A.when_pressed = self.on_encoder_tick_B

        # Publishers
        self.odom_pub = self.create_publisher(Odometry, 'odom', 50)
        self.tf_broadcaster = TransformBroadcaster(self)

        # Timer for odometry calculation
        self.timer = self.create_timer(0.02, self.update_odometry)  # 50Hz

        self.get_logger().info('Odometry publisher node started')

    def on_encoder_tick_A(self):
        """Callback for encoder A"""
        self.direction_A = 1 if self.ENC_A_B.value == 0 else -1
        with self.lock_A:
            self.tick_count_A += self.direction_A

    def on_encoder_tick_B(self):
        """Callback for encoder B"""
        self.direction_B = 1 if self.ENC_B_B.value == 0 else -1
        with self.lock_B:
            self.tick_count_B += self.direction_B

    def update_odometry(self):
        """Calculate and publish odometry"""
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9

        if dt <= 0:
            return

        # Get encoder ticks and reset
        with self.lock_A:
            ticks_A = self.tick_count_A
            self.tick_count_A = 0

        with self.lock_B:
            ticks_B = self.tick_count_B
            self.tick_count_B = 0

        # Calculate distance traveled by each wheel
        dist_A = (ticks_A / self.PULSES_PER_REV) * self.WHEEL_CIRCUMFERENCE
        dist_B = (ticks_B / self.PULSES_PER_REV) * self.WHEEL_CIRCUMFERENCE

        # Calculate robot displacement
        dist_center = (dist_A + dist_B) / 2.0
        delta_theta = (dist_B - dist_A) / self.WHEEL_SEPARATION

        # Update pose
        if abs(delta_theta) < 1e-6:
            # Straight line motion
            delta_x = dist_center * math.cos(self.theta)
            delta_y = dist_center * math.sin(self.theta)
        else:
            # Arc motion
            radius = dist_center / delta_theta
            delta_x = radius * (math.sin(self.theta + delta_theta) - math.sin(self.theta))
            delta_y = -radius * (math.cos(self.theta + delta_theta) - math.cos(self.theta))

        self.x += delta_x
        self.y += delta_y
        self.theta += delta_theta

        # Normalize theta
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

        # Calculate velocities
        vx = dist_center / dt
        vth = delta_theta / dt

        # Publish odometry message
        odom = Odometry()
        odom.header.stamp = current_time.to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_footprint'

        # Position
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0

        # Orientation (quaternion from theta)
        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0
        odom.pose.pose.orientation.z = math.sin(self.theta / 2.0)
        odom.pose.pose.orientation.w = math.cos(self.theta / 2.0)

        # Velocity
        odom.twist.twist.linear.x = vx
        odom.twist.twist.linear.y = 0.0
        odom.twist.twist.angular.z = vth

        # Covariance (tune these values based on your robot)
        odom.pose.covariance[0] = 0.01   # x
        odom.pose.covariance[7] = 0.01   # y
        odom.pose.covariance[35] = 0.01  # theta

        self.odom_pub.publish(odom)

        # Publish transform
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_footprint'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = math.sin(self.theta / 2.0)
        t.transform.rotation.w = math.cos(self.theta / 2.0)

        self.tf_broadcaster.sendTransform(t)

        self.last_time = current_time

def main(args=None):
    rclpy.init(args=args)
    node = OdometryPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
