#!/usr/bin/env python3
"""
Flask Control Server - Complete ROS2 SLAM System Control via HTTP API
Wraith Robot - Raspberry Pi 5 Flask Server for Flutter App

This server provides complete control over:
- Robot connection and status
- SLAM mapping (start/stop with terminal management)
- SLAM activation (lifecycle commands)
- Manual robot control (D-pad)
- Auto mode (autonomous exploration)
- Map saving with waypoints
- Navigation system launch
- Waypoint-based navigation

Author: Wraith Robot Team
Date: December 2025
"""

import rclpy
from rclpy.node import Node
from flask import Flask, request, jsonify
from flask_cors import CORS
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from gpiozero import PWMOutputDevice, OutputDevice, Button, DistanceSensor, AngularServo
from time import sleep
import threading
import fcntl
import struct
import socket
import signal
import sys
import math
import subprocess
import os
import yaml
import glob
import base64
from pathlib import Path

app = Flask(__name__)
CORS(app)  # Enable CORS for Flutter web app

# Global reference to ROS node
ros_node = None

# ==================== GPIO HARDWARE SETUP ====================
# Motor A Control Pins (BTS7960)
RPWM_A = PWMOutputDevice(18)
LPWM_A = PWMOutputDevice(23)
REN_A = OutputDevice(24)
LEN_A = OutputDevice(25)

# Motor B Control Pins (BTS7960)
RPWM_B = PWMOutputDevice(22)
LPWM_B = PWMOutputDevice(27)
REN_B = OutputDevice(5)
LEN_B = OutputDevice(6)

# Encoder Pins
ENC_A_A = Button(17, bounce_time=0.005)
ENC_A_B = Button(4)
ENC_B_A = Button(19, bounce_time=0.005)
ENC_B_B = Button(13)

# Distance Sensor & Servo
sensor = DistanceSensor(echo=21, trigger=20)
servo = AngularServo(12, min_angle=-85, max_angle=85,
                     min_pulse_width=0.0005, max_pulse_width=0.0025)

# ==================== ROBOT SPECIFICATIONS ====================
PULSES_PER_REV = 500
WHEEL_CIRCUMFERENCE_CM = 20.42
WHEEL_CIRCUMFERENCE_M = 0.2042  # meters
WHEEL_SEPARATION_M = 0.21336  # meters (0.7 feet)

# ==================== GLOBAL STATE VARIABLES ====================
# Encoder tracking
tick_count_A = tick_count_B = 0
direction_A = direction_B = 1
lock_A = threading.Lock()
lock_B = threading.Lock()

# Movement state
current_speed = 0.3
obstacle_threshold = 20  # cm
auto_mode = False
auto_thread = None

# ROS2 subprocess management
mapping_process = None
navigation_process = None
slam_activation_done = False

# Paths
WORKSPACE_PATH = Path.home() / "SLAM" / "slam_ws"
MAPS_PATH = Path.home() / "slam_maps"
SCRIPTS_PATH = WORKSPACE_PATH / "src" / "slam_robot" / "scripts"

# Ensure maps directory exists
MAPS_PATH.mkdir(parents=True, exist_ok=True)


# ==================== ENCODER CALLBACKS ====================
def on_encoder_tick_A():
    global tick_count_A, direction_A
    direction_A = 1 if ENC_A_B.value == 0 else -1
    with lock_A:
        tick_count_A += direction_A


def on_encoder_tick_B():
    global tick_count_B, direction_B
    direction_B = 1 if ENC_B_B.value == 0 else -1
    with lock_B:
        tick_count_B += direction_B


ENC_A_A.when_pressed = on_encoder_tick_A
ENC_B_A.when_pressed = on_encoder_tick_B


# ==================== MOTOR CONTROL FUNCTIONS ====================
def set_motor_A(speed):
    speed = max(min(speed, 1.0), -1.0)
    if speed > 0:
        LPWM_A.value = 0
        RPWM_A.value = speed
    elif speed < 0:
        RPWM_A.value = 0
        LPWM_A.value = abs(speed)
    else:
        RPWM_A.value = LPWM_A.value = 0


def set_motor_B(speed):
    speed = max(min(speed, 1.0), -1.0)
    if speed > 0:
        LPWM_B.value = 0
        RPWM_B.value = speed
    elif speed < 0:
        RPWM_B.value = 0
        LPWM_B.value = abs(speed)
    else:
        RPWM_B.value = LPWM_B.value = 0


def enable_motors():
    REN_A.on()
    LEN_A.on()
    REN_B.on()
    LEN_B.on()


def disable_motors():
    RPWM_A.value = LPWM_A.value = 0
    REN_A.off()
    LEN_A.off()
    RPWM_B.value = LPWM_B.value = 0
    REN_B.off()
    LEN_B.off()


def move_forward(speed):
    set_motor_A(speed)
    set_motor_B(speed)


def move_backward(speed):
    set_motor_A(-speed)
    set_motor_B(-speed)


def move_left(speed):
    set_motor_A(speed)
    set_motor_B(-speed)


def move_right(speed):
    set_motor_A(-speed)
    set_motor_B(speed)


def stop_motors():
    set_motor_A(0)
    set_motor_B(0)


def increase_speed():
    global current_speed
    current_speed = min(current_speed + 0.1, 1.0)
    return current_speed


def decrease_speed():
    global current_speed
    current_speed = max(current_speed - 0.1, 0.0)
    return current_speed


# ==================== SERVO & AUTO MODE ====================
def sweep_servo(target, step=5, delay=0.03):
    target = max(-85, min(85, target))
    cur = int(servo.angle or 0)
    rng = range(cur, target + 1, step) if target > cur else range(cur, target - 1, -step)
    for a in rng:
        servo.angle = max(-85, min(85, a))
        sleep(delay)


def auto_mode_function():
    global auto_mode
    enable_motors()
    if ros_node:
        ros_node.get_logger().info('🤖 Auto mode started')

    while auto_mode:
        try:
            sweep_servo(0)
            front = sensor.distance * 100

            if front < obstacle_threshold:
                stop_motors()
                sweep_servo(85)
                right = sensor.distance * 100
                sweep_servo(-85)
                left = sensor.distance * 100
                sweep_servo(0)

                move_backward(current_speed)
                sleep(0.5)
                stop_motors()

                if right > left:
                    move_right(current_speed)
                else:
                    move_left(current_speed)
                sleep(0.6)
                stop_motors()
            else:
                move_forward(current_speed)

            sleep(0.1)
        except Exception as e:
            if ros_node:
                ros_node.get_logger().error(f'Auto mode error: {e}')
            stop_motors()

    stop_motors()
    if ros_node:
        ros_node.get_logger().info('🛑 Auto mode stopped')


# ==================== UTILITY FUNCTIONS ====================
def get_ip_address(ifname='wlan0'):
    """Get IP address of specified interface"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ip = fcntl.ioctl(
            s.fileno(), 0x8915,
            struct.pack('256s', bytes(ifname[:15], 'utf-8'))
        )[20:24]
        return socket.inet_ntoa(ip)
    except:
        # Try eth0 if wlan0 fails
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            ip = fcntl.ioctl(
                s.fileno(), 0x8915,
                struct.pack('256s', bytes('eth0'[:15], 'utf-8'))
            )[20:24]
            return socket.inet_ntoa(ip)
        except:
            return '127.0.0.1'


def run_bash_command(command):
    """Execute bash command and return output"""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return "", str(e), -1


# ==================== FLASK API ENDPOINTS ====================

# ========== CONNECTION & STATUS ==========
@app.route('/', methods=['GET'])
def index():
    """API root - health check"""
    return jsonify({
        'status': 'online',
        'robot': 'Wraith SLAM Robot',
        'version': '2.0',
        'platform': 'Raspberry Pi 5 + ROS2 Jazzy'
    })


@app.route('/status', methods=['GET'])
def status():
    """Check robot status"""
    return jsonify({
        'status': 'ok',
        'connected': True,
        'mapping_active': mapping_process is not None and mapping_process.poll() is None,
        'navigation_active': navigation_process is not None and navigation_process.poll() is None,
        'slam_activated': slam_activation_done,
        'auto_mode': auto_mode,
        'speed': current_speed * 100
    })


@app.route('/get_ip', methods=['GET'])
def get_ip():
    """Get robot IP address"""
    if ros_node:
        ros_node.get_logger().info('[📱] Flutter app requested IP address')
    return jsonify({'ip': get_ip_address()})


@app.route('/get_distance', methods=['GET'])
def get_distance():
    """Get ultrasonic sensor distance"""
    dist = round(sensor.distance * 100, 2)
    if ros_node:
        ros_node.get_logger().info(f'[📏] Distance sensor: {dist} cm')
    return jsonify({'distance': dist})


# ========== MAPPING CONTROL ==========
@app.route('/mapping/start', methods=['POST'])
def start_mapping():
    """Start SLAM mapping in new terminal/subprocess"""
    global mapping_process, slam_activation_done

    if mapping_process and mapping_process.poll() is None:
        return jsonify({
            'status': 'error',
            'message': 'Mapping already running'
        }), 400

    try:
        # Source ROS2 and launch mapping with manual control mode
        launch_command = f"""
        cd {WORKSPACE_PATH} && \
        source /opt/ros/jazzy/setup.bash && \
        source install/setup.bash && \
        ros2 launch slam_robot mapping.launch.py control_mode:=manual
        """

        # Start mapping process in background
        mapping_process = subprocess.Popen(
            launch_command,
            shell=True,
            executable='/bin/bash',
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid  # Create new process group for easy termination
        )

        slam_activation_done = False  # Reset SLAM activation flag

        if ros_node:
            ros_node.get_logger().info('='*70)
            ros_node.get_logger().info('[🗺️] MAPPING STARTED - Process ID: {}'.format(mapping_process.pid))
            ros_node.get_logger().info('='*70)

        # Wait a moment to check if process started successfully
        sleep(2)
        if mapping_process.poll() is not None:
            return jsonify({
                'status': 'error',
                'message': 'Mapping process failed to start'
            }), 500

        return jsonify({
            'status': 'ok',
            'message': 'Mapping started successfully',
            'pid': mapping_process.pid,
            'note': 'Now activate SLAM using /slam/activate endpoint'
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error starting mapping: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/mapping/stop', methods=['POST'])
def stop_mapping():
    """Stop SLAM mapping process"""
    global mapping_process, slam_activation_done

    if not mapping_process or mapping_process.poll() is not None:
        return jsonify({
            'status': 'error',
            'message': 'Mapping is not running'
        }), 400

    try:
        # Kill entire process group (including all child processes)
        os.killpg(os.getpgid(mapping_process.pid), signal.SIGINT)
        mapping_process.wait(timeout=5)
        mapping_process = None
        slam_activation_done = False

        if ros_node:
            ros_node.get_logger().info('[🛑] Mapping stopped')

        return jsonify({
            'status': 'ok',
            'message': 'Mapping stopped successfully'
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error stopping mapping: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/slam/activate', methods=['POST'])
def activate_slam():
    """Activate SLAM Toolbox lifecycle (configure + activate)"""
    global slam_activation_done

    if not mapping_process or mapping_process.poll() is not None:
        return jsonify({
            'status': 'error',
            'message': 'Start mapping first'
        }), 400

    if slam_activation_done:
        return jsonify({
            'status': 'ok',
            'message': 'SLAM already activated'
        })

    try:
        # Wait for SLAM Toolbox node to be ready
        sleep(3)

        # Configure SLAM Toolbox
        configure_cmd = "ros2 lifecycle set /slam_toolbox configure"
        stdout, stderr, code = run_bash_command(configure_cmd)

        if code != 0:
            raise Exception(f"Configure failed: {stderr}")

        sleep(1)

        # Activate SLAM Toolbox
        activate_cmd = "ros2 lifecycle set /slam_toolbox activate"
        stdout, stderr, code = run_bash_command(activate_cmd)

        if code != 0:
            raise Exception(f"Activate failed: {stderr}")

        slam_activation_done = True

        if ros_node:
            ros_node.get_logger().info('='*70)
            ros_node.get_logger().info('[✅] SLAM TOOLBOX ACTIVATED')
            ros_node.get_logger().info('[🗺️] Robot is now mapping the environment')
            ros_node.get_logger().info('='*70)

        return jsonify({
            'status': 'ok',
            'message': 'SLAM activated successfully',
            'mapping_active': True
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error activating SLAM: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/mapping/save', methods=['POST'])
def save_mapping():
    """Save current map with waypoints"""
    if not mapping_process or mapping_process.poll() is not None:
        return jsonify({
            'status': 'error',
            'message': 'No active mapping session'
        }), 400

    # Get map name from request
    map_name = request.json.get('map_name', 'wraith_map') if request.is_json else 'wraith_map'

    try:
        # Run save_map.py script
        save_command = f"""
        cd {WORKSPACE_PATH} && \
        source /opt/ros/jazzy/setup.bash && \
        source install/setup.bash && \
        python3 {SCRIPTS_PATH}/save_map.py {map_name}
        """

        stdout, stderr, code = run_bash_command(save_command)

        if code != 0:
            raise Exception(f"Save failed: {stderr}")

        # Check if files were created
        map_files = {
            'pgm': MAPS_PATH / f"{map_name}.pgm",
            'png': MAPS_PATH / f"{map_name}.png",
            'yaml': MAPS_PATH / f"{map_name}.yaml",
            'waypoints': MAPS_PATH / f"{map_name}_waypoints.yaml"
        }

        files_exist = all(f.exists() for f in map_files.values())

        if not files_exist:
            raise Exception("Map files not created properly")

        if ros_node:
            ros_node.get_logger().info('='*70)
            ros_node.get_logger().info(f'[💾] MAP SAVED: {map_name}')
            ros_node.get_logger().info(f'[📍] Location: {MAPS_PATH}')
            ros_node.get_logger().info('='*70)

        # Read PNG image and encode to base64 for Flutter display
        png_data = None
        try:
            with open(map_files['png'], 'rb') as f:
                png_data = base64.b64encode(f.read()).decode('utf-8')
        except:
            pass

        return jsonify({
            'status': 'ok',
            'message': 'Map saved successfully',
            'map_name': map_name,
            'files': {
                'pgm': str(map_files['pgm']),
                'png': str(map_files['png']),
                'yaml': str(map_files['yaml']),
                'waypoints': str(map_files['waypoints'])
            },
            'png_base64': png_data  # For Flutter to display
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error saving map: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


# ========== MANUAL CONTROL ==========
@app.route('/control', methods=['POST'])
def control():
    """Manual robot control and auto mode toggle"""
    global auto_mode, auto_thread

    cmd = request.data.decode().strip()

    # Auto mode commands
    if cmd == 'auto_start':
        if not auto_mode:
            auto_mode = True
            auto_thread = threading.Thread(target=auto_mode_function, daemon=True)
            auto_thread.start()
            if ros_node:
                ros_node.get_logger().info('[🤖] AUTO MODE ENABLED')
            return jsonify({'status': 'ok', 'message': 'Auto mode started'})
        return jsonify({'status': 'ok', 'message': 'Already in auto mode'})

    if cmd == 'auto_stop':
        if auto_mode:
            auto_mode = False
            stop_motors()
            enable_motors()
            if ros_node:
                ros_node.get_logger().info('[👤] MANUAL MODE ENABLED')
            return jsonify({'status': 'ok', 'message': 'Auto mode stopped'})
        return jsonify({'status': 'ok', 'message': 'Auto mode not active'})

    # Manual movement commands
    actions = {
        'forward_start': lambda: move_forward(current_speed),
        'forward_stop': stop_motors,
        'backward_start': lambda: move_backward(current_speed),
        'backward_stop': stop_motors,
        'left_start': lambda: move_left(current_speed),
        'left_stop': stop_motors,
        'right_start': lambda: move_right(current_speed),
        'right_stop': stop_motors,
        'speed+': increase_speed,
        'speed-': decrease_speed
    }

    if cmd in actions:
        # Stop auto mode if manual command issued
        if auto_mode:
            auto_mode = False
            stop_motors()
            enable_motors()

        enable_motors()
        result = actions[cmd]()

        # Logging
        if ros_node:
            log_messages = {
                'forward_start': f'[⬆️] Moving FORWARD at {current_speed*100:.0f}%',
                'backward_start': f'[⬇️] Moving BACKWARD at {current_speed*100:.0f}%',
                'left_start': f'[⬅️] Turning LEFT at {current_speed*100:.0f}%',
                'right_start': f'[➡️] Turning RIGHT at {current_speed*100:.0f}%',
                'speed+': f'[⚡] Speed INCREASED to {current_speed*100:.0f}%',
                'speed-': f'[🐌] Speed DECREASED to {current_speed*100:.0f}%'
            }
            if cmd in log_messages:
                ros_node.get_logger().info(log_messages[cmd])
            elif cmd.endswith('_stop'):
                ros_node.get_logger().info('[⏹️] STOPPED')

        return jsonify({'status': 'ok', 'message': f'{cmd} executed'})

    return jsonify({'status': 'error', 'message': 'Unknown command'}), 400


# Legacy endpoints for backward compatibility
@app.route('/mode/auto/start', methods=['POST'])
def auto_mode_start_legacy():
    """Legacy endpoint - redirect to /control"""
    return control()  # Simulates auto_start command


@app.route('/mode/auto/stop', methods=['POST'])
def auto_mode_stop_legacy():
    """Legacy endpoint - redirect to /control"""
    return control()  # Simulates auto_stop command


# ========== NAVIGATION CONTROL ==========
@app.route('/navigation/start', methods=['POST'])
def start_navigation():
    """Start navigation system with saved map"""
    global navigation_process

    if navigation_process and navigation_process.poll() is None:
        return jsonify({
            'status': 'error',
            'message': 'Navigation already running'
        }), 400

    # Get map name from request
    map_name = request.json.get('map_name', 'wraith_map') if request.is_json else 'wraith_map'

    # Check if map exists
    map_yaml = MAPS_PATH / f"{map_name}.yaml"
    if not map_yaml.exists():
        return jsonify({
            'status': 'error',
            'message': f'Map not found: {map_name}'
        }), 404

    try:
        # Launch navigation
        nav_command = f"""
        cd {WORKSPACE_PATH} && \
        source /opt/ros/jazzy/setup.bash && \
        source install/setup.bash && \
        ros2 launch slam_robot navigation.launch.py map:={map_name}
        """

        navigation_process = subprocess.Popen(
            nav_command,
            shell=True,
            executable='/bin/bash',
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid
        )

        if ros_node:
            ros_node.get_logger().info('='*70)
            ros_node.get_logger().info(f'[🧭] NAVIGATION STARTED - Map: {map_name}')
            ros_node.get_logger().info(f'[🤖] Process ID: {navigation_process.pid}')
            ros_node.get_logger().info('='*70)

        # Wait to verify startup
        sleep(3)
        if navigation_process.poll() is not None:
            return jsonify({
                'status': 'error',
                'message': 'Navigation process failed to start'
            }), 500

        return jsonify({
            'status': 'ok',
            'message': 'Navigation started successfully',
            'map_name': map_name,
            'pid': navigation_process.pid,
            'note': 'Feature-based localizer will auto-initialize robot pose'
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error starting navigation: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/navigation/stop', methods=['POST'])
def stop_navigation():
    """Stop navigation system"""
    global navigation_process

    if not navigation_process or navigation_process.poll() is not None:
        return jsonify({
            'status': 'error',
            'message': 'Navigation is not running'
        }), 400

    try:
        os.killpg(os.getpgid(navigation_process.pid), signal.SIGINT)
        navigation_process.wait(timeout=5)
        navigation_process = None

        if ros_node:
            ros_node.get_logger().info('[🛑] Navigation stopped')

        return jsonify({
            'status': 'ok',
            'message': 'Navigation stopped successfully'
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error stopping navigation: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/navigate', methods=['POST'])
def navigate_to_waypoint():
    """Navigate to specific waypoint"""
    if not navigation_process or navigation_process.poll() is not None:
        return jsonify({
            'status': 'error',
            'message': 'Navigation system not running. Start navigation first.'
        }), 400

    # Get waypoint from request
    data = request.json if request.is_json else {}
    waypoint = data.get('waypoint', '')

    if not waypoint:
        return jsonify({
            'status': 'error',
            'message': 'Waypoint label required'
        }), 400

    try:
        # Execute go_to command
        goto_command = f"""
        source /opt/ros/jazzy/setup.bash && \
        source {WORKSPACE_PATH}/install/setup.bash && \
        ros2 run slam_robot go_to {waypoint}
        """

        # Run in background (non-blocking)
        subprocess.Popen(
            goto_command,
            shell=True,
            executable='/bin/bash',
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        if ros_node:
            ros_node.get_logger().info(f'[🎯] Navigating to waypoint: {waypoint}')

        return jsonify({
            'status': 'ok',
            'message': f'Navigation to {waypoint} started',
            'waypoint': waypoint
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error navigating to waypoint: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


# ========== MAPS & WAYPOINTS ==========
@app.route('/maps/list', methods=['GET'])
def list_maps():
    """List all saved maps"""
    try:
        # Find all .yaml map files
        map_files = list(MAPS_PATH.glob("*.yaml"))
        # Exclude waypoint files
        map_files = [f for f in map_files if not f.name.endswith('_waypoints.yaml')]

        maps = []
        for map_file in map_files:
            map_name = map_file.stem

            # Check if all required files exist
            pgm_file = MAPS_PATH / f"{map_name}.pgm"
            png_file = MAPS_PATH / f"{map_name}.png"
            waypoints_file = MAPS_PATH / f"{map_name}_waypoints.yaml"

            # Load waypoint count
            waypoint_count = 0
            if waypoints_file.exists():
                try:
                    with open(waypoints_file, 'r') as f:
                        waypoint_data = yaml.safe_load(f)
                        waypoint_count = waypoint_data.get('total_waypoints', 0)
                except:
                    pass

            # Load PNG as base64
            png_base64 = None
            if png_file.exists():
                try:
                    with open(png_file, 'rb') as f:
                        png_base64 = base64.b64encode(f.read()).decode('utf-8')
                except:
                    pass

            maps.append({
                'name': map_name,
                'has_pgm': pgm_file.exists(),
                'has_png': png_file.exists(),
                'has_waypoints': waypoints_file.exists(),
                'waypoint_count': waypoint_count,
                'png_base64': png_base64,
                'created': map_file.stat().st_mtime
            })

        # Sort by creation time (newest first)
        maps.sort(key=lambda x: x['created'], reverse=True)

        return jsonify({
            'status': 'ok',
            'maps': maps,
            'total': len(maps)
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error listing maps: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/maps/<map_name>/waypoints', methods=['GET'])
def get_waypoints(map_name):
    """Get waypoints for specific map"""
    try:
        waypoints_file = MAPS_PATH / f"{map_name}_waypoints.yaml"

        if not waypoints_file.exists():
            return jsonify({
                'status': 'error',
                'message': f'Waypoints not found for map: {map_name}'
            }), 404

        with open(waypoints_file, 'r') as f:
            waypoint_data = yaml.safe_load(f)

        # Format waypoints for Flutter
        waypoints = waypoint_data.get('waypoints', [])
        formatted_waypoints = []

        for wp in waypoints:
            formatted_waypoints.append({
                'label': wp.get('label', ''),
                'x': wp.get('x', 0.0),
                'y': wp.get('y', 0.0),
                'theta': wp.get('theta', 0.0),
                'timestamp': wp.get('timestamp', 0),
                'distance_from_previous': wp.get('distance_from_previous', 0.0),
                'environmental_features': wp.get('environmental_features', {})
            })

        return jsonify({
            'status': 'ok',
            'map_name': waypoint_data.get('map_name', map_name),
            'total_waypoints': waypoint_data.get('total_waypoints', 0),
            'waypoints': formatted_waypoints
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error getting waypoints: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/maps/<map_name>/image', methods=['GET'])
def get_map_image(map_name):
    """Get map PNG image as base64"""
    try:
        png_file = MAPS_PATH / f"{map_name}.png"

        if not png_file.exists():
            return jsonify({
                'status': 'error',
                'message': f'Map image not found: {map_name}'
            }), 404

        with open(png_file, 'rb') as f:
            png_data = base64.b64encode(f.read()).decode('utf-8')

        return jsonify({
            'status': 'ok',
            'map_name': map_name,
            'png_base64': png_data
        })

    except Exception as e:
        if ros_node:
            ros_node.get_logger().error(f'Error getting map image: {e}')
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


# ==================== ROS2 NODE WRAPPER ====================
class FlaskControlServerNode(Node):
    def __init__(self):
        super().__init__('flask_control_server')

        self.declare_parameter('port', 5000)
        self.port = self.get_parameter('port').value

        # Odometry state
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_time = self.get_clock().now()

        # Publishers
        self.odom_pub = self.create_publisher(Odometry, 'odom', 50)
        self.tf_broadcaster = TransformBroadcaster(self)

        # Odometry timer (50Hz)
        self.odom_timer = self.create_timer(0.02, self.update_odometry)

        self.print_startup_banner()

        # Enable motors
        enable_motors()
        self.get_logger().info('[✓] Motors enabled')
        self.get_logger().info('[✓] Odometry publisher started (50Hz)')

        # Start Flask server
        self.flask_thread = threading.Thread(
            target=self._run_flask_server,
            daemon=True
        )
        self.flask_thread.start()

        self.get_logger().info('[✓] Flask API server started')
        self.get_logger().info(f'[⏳] Listening on http://{get_ip_address()}:{self.port}')
        self.get_logger().info('='*70)

    def print_startup_banner(self):
        ip = get_ip_address()
        self.get_logger().info('')
        self.get_logger().info('='*70)
        self.get_logger().info('     WRAITH ROBOT - COMPLETE FLASK CONTROL SERVER')
        self.get_logger().info('='*70)
        self.get_logger().info(f'  Robot IP: {ip}')
        self.get_logger().info(f'  Port: {self.port}')
        self.get_logger().info(f'  Base URL: http://{ip}:{self.port}')
        self.get_logger().info('='*70)
        self.get_logger().info('Available API Endpoints:')
        self.get_logger().info('  Connection:')
        self.get_logger().info('    GET  /status                  - Robot status')
        self.get_logger().info('    GET  /get_ip                  - Get IP address')
        self.get_logger().info('    GET  /get_distance            - Ultrasonic sensor')
        self.get_logger().info('')
        self.get_logger().info('  Mapping:')
        self.get_logger().info('    POST /mapping/start           - Start SLAM mapping')
        self.get_logger().info('    POST /slam/activate           - Activate SLAM Toolbox')
        self.get_logger().info('    POST /mapping/stop            - Stop mapping')
        self.get_logger().info('    POST /mapping/save            - Save map + waypoints')
        self.get_logger().info('')
        self.get_logger().info('  Control:')
        self.get_logger().info('    POST /control                 - Manual D-pad control')
        self.get_logger().info('         Body: forward_start, backward_start, left_start, right_start')
        self.get_logger().info('               forward_stop, backward_stop, left_stop, right_stop')
        self.get_logger().info('               speed+, speed-, auto_start, auto_stop')
        self.get_logger().info('')
        self.get_logger().info('  Navigation:')
        self.get_logger().info('    POST /navigation/start        - Start navigation (JSON: map_name)')
        self.get_logger().info('    POST /navigation/stop         - Stop navigation')
        self.get_logger().info('    POST /navigate                - Go to waypoint (JSON: waypoint)')
        self.get_logger().info('')
        self.get_logger().info('  Maps & Waypoints:')
        self.get_logger().info('    GET  /maps/list               - List all saved maps')
        self.get_logger().info('    GET  /maps/<name>/waypoints   - Get waypoint list')
        self.get_logger().info('    GET  /maps/<name>/image       - Get map PNG image')
        self.get_logger().info('='*70)
        self.get_logger().info('')

    def _run_flask_server(self):
        app.run(host='0.0.0.0', port=self.port, debug=False, use_reloader=False)

    def update_odometry(self):
        """Calculate and publish odometry from encoders (50Hz)"""
        global tick_count_A, tick_count_B, lock_A, lock_B

        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9

        if dt <= 0:
            return

        with lock_A:
            ticks_A = tick_count_A
            tick_count_A = 0

        with lock_B:
            ticks_B = tick_count_B
            tick_count_B = 0

        dist_A = (ticks_A / PULSES_PER_REV) * WHEEL_CIRCUMFERENCE_M
        dist_B = (ticks_B / PULSES_PER_REV) * WHEEL_CIRCUMFERENCE_M

        dist_center = (dist_A + dist_B) / 2.0
        delta_theta = (dist_B - dist_A) / WHEEL_SEPARATION_M

        if abs(delta_theta) < 1e-6:
            delta_x = dist_center * math.cos(self.theta)
            delta_y = dist_center * math.sin(self.theta)
        else:
            radius = dist_center / delta_theta
            delta_x = radius * (math.sin(self.theta + delta_theta) - math.sin(self.theta))
            delta_y = -radius * (math.cos(self.theta + delta_theta) - math.cos(self.theta))

        self.x += delta_x
        self.y += delta_y
        self.theta += delta_theta
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

        vx = dist_center / dt if dt > 0 else 0.0
        vth = delta_theta / dt if dt > 0 else 0.0

        # Publish odometry
        odom = Odometry()
        odom.header.stamp = current_time.to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_footprint'

        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0

        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0
        odom.pose.pose.orientation.z = math.sin(self.theta / 2.0)
        odom.pose.pose.orientation.w = math.cos(self.theta / 2.0)

        odom.twist.twist.linear.x = vx
        odom.twist.twist.linear.y = 0.0
        odom.twist.twist.angular.z = vth

        odom.pose.covariance[0] = 0.01
        odom.pose.covariance[7] = 0.01
        odom.pose.covariance[35] = 0.01

        self.odom_pub.publish(odom)

        # Publish TF
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_footprint'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = math.sin(self.theta / 2.0)
        t.transform.rotation.w = math.cos(self.theta / 2.0)

        self.tf_broadcaster.sendTransform(t)
        self.last_time = current_time

    def cleanup(self):
        global auto_mode, mapping_process, navigation_process
        self.get_logger().info('Shutting down...')

        auto_mode = False
        disable_motors()

        if mapping_process:
            try:
                os.killpg(os.getpgid(mapping_process.pid), signal.SIGINT)
            except:
                pass

        if navigation_process:
            try:
                os.killpg(os.getpgid(navigation_process.pid), signal.SIGINT)
            except:
                pass

        self.get_logger().info('Cleanup complete')


# ==================== MAIN ====================
def main(args=None):
    global ros_node

    rclpy.init(args=args)
    ros_node = FlaskControlServerNode()

    def signal_handler(sig, frame):
        ros_node.get_logger().info('Interrupt received...')
        ros_node.cleanup()
        rclpy.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        rclpy.spin(ros_node)
    except KeyboardInterrupt:
        pass
    finally:
        ros_node.cleanup()
        ros_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
