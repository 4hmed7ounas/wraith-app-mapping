#!/usr/bin/env python3
"""
Auto Waypoint Generator Node

Automatically creates labeled waypoints (Point_A, Point_B, etc.) during SLAM mapping.
Creates waypoints based on time elapsed OR distance traveled (hybrid approach).

Author: Wraith Robot Team
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from sensor_msgs.msg import LaserScan
import yaml
import math
import os
import numpy as np


class AutoWaypointGenerator(Node):
    """
    Automatically generate waypoints during SLAM mapping with environmental features.

    Strategy:
    - Create waypoint every X seconds OR Y meters traveled (whichever comes first)
    - Prevents duplicate waypoints at same location (minimum distance check)
    - Records obstacle distances in 8 cardinal directions for localization
    - Stores distance from previous waypoint for trajectory validation
    - Auto-saves to YAML file when node is shutdown

    Feature Extraction:
    - Cardinal directions: N, NE, E, SE, S, SW, W, NW (relative to robot orientation)
    - Uses laser scan data to create unique "fingerprint" for each waypoint
    """

    def __init__(self):
        super().__init__('auto_waypoint_generator')

        # Declare parameters with defaults
        self.declare_parameter('waypoint_interval_time', 15.0)      # seconds
        self.declare_parameter('waypoint_interval_distance', 2.5)   # meters
        self.declare_parameter('min_distance_between_waypoints', 0.5)  # meters
        self.declare_parameter('map_name', 'auto_generated_map')
        self.declare_parameter('output_directory', '/home/zaid/slam_maps')

        # Get parameters
        self.waypoint_interval_time = self.get_parameter('waypoint_interval_time').value
        self.waypoint_interval_distance = self.get_parameter('waypoint_interval_distance').value
        self.min_distance = self.get_parameter('min_distance_between_waypoints').value
        self.map_name = self.get_parameter('map_name').value
        self.output_dir = self.get_parameter('output_directory').value

        # State tracking
        self.waypoint_counter = 0
        self.last_waypoint_time = self.get_clock().now()
        self.last_waypoint_pose = None
        self.current_pose = None
        self.current_scan = None
        self.waypoints = []

        # QoS profile for SLAM Toolbox compatibility
        # SLAM Toolbox uses VOLATILE durability (default), so we must match it
        slam_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,  # Changed from TRANSIENT_LOCAL
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        # QoS profile for odometry (uses default Volatile)
        odom_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        # Subscribe to robot pose (try multiple possible topics)
        # SLAM Toolbox publishes pose on /pose topic
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/pose',
            self.pose_callback,
            slam_qos  # Use SLAM-compatible QoS
        )

        # Backup: also try filtered odometry
        self.odom_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/odometry/filtered',
            self.odom_callback,
            odom_qos  # Use standard odometry QoS
        )

        # Subscribe to laser scan for environmental features
        scan_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,  # Lidar uses best effort
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            scan_qos
        )

        # Timer to check if waypoint should be created (every 1 second)
        self.timer = self.create_timer(1.0, self.check_should_create_waypoint)

        self.get_logger().info("=" * 60)
        self.get_logger().info("Auto-Waypoint Generator Started")
        self.get_logger().info("=" * 60)
        self.get_logger().info(f"Interval: {self.waypoint_interval_time}s OR {self.waypoint_interval_distance}m")
        self.get_logger().info(f"Min distance between waypoints: {self.min_distance}m")
        self.get_logger().info(f"Map name: {self.map_name}")
        self.get_logger().info(f"Output directory: {self.output_dir}")
        self.get_logger().info("=" * 60)

    def pose_callback(self, msg):
        """Update current robot position from SLAM pose"""
        self.current_pose = msg.pose.pose

    def odom_callback(self, msg):
        """Backup: update from filtered odometry if SLAM pose not available"""
        if self.current_pose is None:
            self.current_pose = msg.pose.pose

    def scan_callback(self, msg):
        """Store latest laser scan data for feature extraction"""
        self.current_scan = msg

    def check_should_create_waypoint(self):
        """
        Called every second to check if a new waypoint should be created.

        Creates waypoint if:
        1. Time elapsed >= interval_time OR distance traveled >= interval_distance
        2. AND minimum distance from last waypoint is satisfied
        """

        if self.current_pose is None:
            # Log every 10 seconds that we're waiting for pose
            if not hasattr(self, '_no_pose_count'):
                self._no_pose_count = 0
            self._no_pose_count += 1
            if self._no_pose_count % 10 == 0:
                self.get_logger().warn(
                    f'Still waiting for pose data... ({self._no_pose_count}s elapsed)'
                )
            return  # No position data yet

        # Calculate time since last waypoint
        current_time = self.get_clock().now()
        time_elapsed = (current_time - self.last_waypoint_time).nanoseconds / 1e9

        # Calculate distance since last waypoint
        if self.last_waypoint_pose:
            distance_traveled = self.calculate_distance(
                self.current_pose,
                self.last_waypoint_pose
            )
        else:
            # First waypoint - always create
            distance_traveled = 999.0

        # DEBUG: Log current status every 5 seconds
        if not hasattr(self, '_debug_count'):
            self._debug_count = 0
        self._debug_count += 1
        if self._debug_count % 5 == 0:
            self.get_logger().info(
                f'[DEBUG] Pos: ({self.current_pose.position.x:.2f}, {self.current_pose.position.y:.2f}) | '
                f'Distance: {distance_traveled:.2f}m | Time: {time_elapsed:.1f}s | '
                f'Waypoints: {self.waypoint_counter}'
            )

        # Check if minimum distance requirement is met
        if self.last_waypoint_pose and distance_traveled < self.min_distance:
            # Robot hasn't moved enough - don't create duplicate
            return

        # Determine if waypoint should be created
        should_create = False
        reason = ""

        if time_elapsed >= self.waypoint_interval_time:
            should_create = True
            reason = f"{time_elapsed:.1f}s elapsed"

        if distance_traveled >= self.waypoint_interval_distance:
            should_create = True
            reason = f"{distance_traveled:.1f}m traveled"

        if should_create:
            self.create_waypoint(reason)

    def create_waypoint(self, reason):
        """
        Save current location as a labeled waypoint with environmental features.

        Args:
            reason: String explaining why waypoint was created
        """

        # Generate label (A, B, C, ... Z, AA, AB, ...)
        label = self.generate_label(self.waypoint_counter)

        # Get orientation (yaw angle)
        theta = self.get_yaw_from_quaternion(self.current_pose.orientation)

        # Get current timestamp
        current_time = self.get_clock().now()

        # Calculate distance from previous waypoint
        distance_from_previous = 0.0
        if self.last_waypoint_pose:
            distance_from_previous = self.calculate_distance(
                self.current_pose,
                self.last_waypoint_pose
            )

        # Extract cardinal direction obstacle distances
        cardinal_distances = self.extract_cardinal_distances()

        # Build waypoint data structure
        waypoint = {
            'label': label,
            'x': float(self.current_pose.position.x),
            'y': float(self.current_pose.position.y),
            'theta': float(theta),
            'timestamp': current_time.to_msg().sec,
            'distance_from_previous': float(distance_from_previous)
        }

        # Add environmental features if scan data is available
        if cardinal_distances is not None:
            waypoint['environmental_features'] = cardinal_distances

            # Log feature summary
            feature_summary = ", ".join([
                f"{d[:2].upper()}:{dist:.2f}m"
                for d, dist in cardinal_distances.items()
            ])
        else:
            waypoint['environmental_features'] = None
            feature_summary = "No scan data"

        self.waypoints.append(waypoint)
        self.waypoint_counter += 1

        # Update tracking
        self.last_waypoint_time = self.get_clock().now()
        self.last_waypoint_pose = self.current_pose

        self.get_logger().info(
            f"✓ Created {label} at ({waypoint['x']:.2f}, {waypoint['y']:.2f}, {waypoint['theta']:.2f}) "
            f"| Dist from prev: {distance_from_previous:.2f}m [{reason}]"
        )
        self.get_logger().info(f"  Features: {feature_summary}")

        # Auto-save waypoints after each creation (so they're never lost)
        self.save_waypoints_to_file()

    def extract_cardinal_distances(self):
        """
        Extract obstacle distances in 8 cardinal directions from laser scan.

        Cardinal directions (relative to robot's current orientation):
        - N (North/Forward): 0°
        - NE (Northeast): 45°
        - E (East/Right): 90°
        - SE (Southeast): 135°
        - S (South/Backward): 180°
        - SW (Southwest): 225° or -135°
        - W (West/Left): 270° or -90°
        - NW (Northwest): 315° or -45°

        Returns:
            dict: Distances in meters for each cardinal direction, or None if no scan data
        """
        if self.current_scan is None:
            return None

        scan = self.current_scan

        # Define target angles for each cardinal direction (in radians)
        # RPLidar typically has 0° at front, increases counter-clockwise
        cardinal_angles = {
            'north': 0.0,           # Forward
            'northeast': np.pi / 4,     # 45°
            'east': np.pi / 2,          # 90° Left
            'southeast': 3 * np.pi / 4, # 135°
            'south': np.pi,             # 180° Backward
            'southwest': -3 * np.pi / 4, # -135° or 225°
            'west': -np.pi / 2,         # -90° or 270° Right
            'northwest': -np.pi / 4     # -45° or 315°
        }

        distances = {}

        for direction, target_angle in cardinal_angles.items():
            # Find the index in the scan that corresponds to this angle
            # LaserScan: angle = angle_min + index * angle_increment
            # So: index = (angle - angle_min) / angle_increment

            # Normalize target angle to scan's angle range
            angle_diff = target_angle - scan.angle_min

            # Handle wraparound
            while angle_diff > np.pi:
                angle_diff -= 2 * np.pi
            while angle_diff < -np.pi:
                angle_diff += 2 * np.pi

            # Calculate index
            if scan.angle_increment != 0:
                index = int(round(angle_diff / scan.angle_increment))

                # Clamp index to valid range
                index = max(0, min(index, len(scan.ranges) - 1))

                # Get distance at this angle
                distance = scan.ranges[index]

                # Filter invalid readings (inf, nan, out of range)
                if np.isfinite(distance) and scan.range_min <= distance <= scan.range_max:
                    distances[direction] = float(distance)
                else:
                    # No obstacle detected in this direction (too far or invalid)
                    distances[direction] = float(scan.range_max)
            else:
                distances[direction] = None

        return distances

    def generate_label(self, index):
        """
        Generate label from index: 0->Point_A, 1->Point_B, ..., 26->Point_AA

        Args:
            index: Integer index

        Returns:
            Label string like "Point_A", "Point_B", etc.
        """
        if index < 26:
            return f"Point_{chr(65 + index)}"  # A-Z
        else:
            # For >26 waypoints: AA, AB, AC, ...
            first = chr(65 + (index // 26) - 1)
            second = chr(65 + (index % 26))
            return f"Point_{first}{second}"

    def calculate_distance(self, pose1, pose2):
        """
        Calculate 2D Euclidean distance between two poses.

        Args:
            pose1, pose2: Pose objects with position.x and position.y

        Returns:
            Distance in meters
        """
        dx = pose1.position.x - pose2.position.x
        dy = pose1.position.y - pose2.position.y
        return math.sqrt(dx**2 + dy**2)

    def get_yaw_from_quaternion(self, q):
        """
        Convert quaternion to yaw angle (rotation around Z-axis).

        Args:
            q: Quaternion with x, y, z, w components

        Returns:
            Yaw angle in radians
        """
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def save_waypoints_to_file(self):
        """
        Save waypoints to YAML file in the output directory.
        Called automatically after each waypoint creation.
        """

        if len(self.waypoints) == 0:
            return  # Nothing to save yet

        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)

        filename = os.path.join(self.output_dir, f"{self.map_name}_waypoints.yaml")

        data = {
            'map_name': self.map_name,
            'map_file': os.path.join(self.output_dir, f"{self.map_name}.yaml"),
            'generation_mode': 'automatic_time_distance',
            'interval_time_seconds': self.waypoint_interval_time,
            'interval_distance_meters': self.waypoint_interval_distance,
            'min_distance_meters': self.min_distance,
            'total_waypoints': len(self.waypoints),
            'waypoints': self.waypoints
        }

        try:
            with open(filename, 'w') as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)

            # Only log full summary on shutdown, not after every waypoint
            # self.get_logger().info(f"✓ Waypoints saved to {filename}")

        except Exception as e:
            self.get_logger().error(f"Failed to save waypoints: {e}")

    def save_waypoints(self):
        """
        Save waypoints and print summary.
        Called on node shutdown.
        """
        if len(self.waypoints) == 0:
            self.get_logger().warn("No waypoints created during mapping session!")
            return

        # Save to file
        self.save_waypoints_to_file()

        # Print summary
        filename = os.path.join(self.output_dir, f"{self.map_name}_waypoints.yaml")
        self.get_logger().info("=" * 60)
        self.get_logger().info(f"✓ Saved {len(self.waypoints)} waypoints to:")
        self.get_logger().info(f"  {filename}")
        self.get_logger().info("=" * 60)
        self.get_logger().info("Waypoint labels:")
        for wp in self.waypoints:
            self.get_logger().info(f"  {wp['label']}: ({wp['x']:.2f}, {wp['y']:.2f})")
        self.get_logger().info("=" * 60)

    def destroy_node(self):
        """Override to save waypoints before shutting down"""
        self.save_waypoints()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = AutoWaypointGenerator()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down, saving waypoints...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
