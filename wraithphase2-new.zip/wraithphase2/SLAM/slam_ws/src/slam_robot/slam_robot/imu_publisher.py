#!/usr/bin/env python3
"""
IMU publisher node - reads MPU6050 data and publishes sensor_msgs/Imu
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import smbus2
import math
import time

class IMUPublisher(Node):
    def __init__(self):
        super().__init__('imu_publisher')

        # MPU6050 Configuration
        self.MPU6050_ADDR = 0x68
        self.PWR_MGMT_1 = 0x6B
        self.ACCEL_XOUT_H = 0x3B
        self.GYRO_XOUT_H = 0x43

        # Scale factors
        self.ACCEL_SCALE = 16384.0  # For ±2g range
        self.GYRO_SCALE = 131.0     # For ±250°/s range

        # I2C bus
        self.bus = smbus2.SMBus(1)

        # Initialize MPU6050
        self.initialize_mpu6050()

        # Calibration offsets (calculate these during calibration)
        self.gyro_x_offset = 0.0
        self.gyro_y_offset = 0.0
        self.gyro_z_offset = 0.0

        # Calibrate on startup
        self.calibrate()

        # Publisher
        self.imu_pub = self.create_publisher(Imu, 'imu/data_raw', 50)

        # Timer for IMU reading
        self.timer = self.create_timer(0.01, self.publish_imu)  # 100Hz

        self.get_logger().info('IMU publisher node started')

    def initialize_mpu6050(self):
        """Wake up MPU6050 and configure it"""
        try:
            # Wake up MPU6050
            self.bus.write_byte_data(self.MPU6050_ADDR, self.PWR_MGMT_1, 0)
            time.sleep(0.1)
            self.get_logger().info('MPU6050 initialized successfully')
        except Exception as e:
            self.get_logger().error(f'Failed to initialize MPU6050: {e}')

    def read_word_2c(self, addr):
        """Read 16-bit signed value"""
        high = self.bus.read_byte_data(self.MPU6050_ADDR, addr)
        low = self.bus.read_byte_data(self.MPU6050_ADDR, addr + 1)
        val = (high << 8) + low
        if val >= 0x8000:
            return -((65535 - val) + 1)
        else:
            return val

    def read_imu_data(self):
        """Read accelerometer and gyroscope data"""
        # Read accelerometer
        accel_x = self.read_word_2c(self.ACCEL_XOUT_H) / self.ACCEL_SCALE
        accel_y = self.read_word_2c(self.ACCEL_XOUT_H + 2) / self.ACCEL_SCALE
        accel_z = self.read_word_2c(self.ACCEL_XOUT_H + 4) / self.ACCEL_SCALE

        # Read gyroscope
        gyro_x = (self.read_word_2c(self.GYRO_XOUT_H) / self.GYRO_SCALE) - self.gyro_x_offset
        gyro_y = (self.read_word_2c(self.GYRO_XOUT_H + 2) / self.GYRO_SCALE) - self.gyro_y_offset
        gyro_z = (self.read_word_2c(self.GYRO_XOUT_H + 4) / self.GYRO_SCALE) - self.gyro_z_offset

        # Convert gyro from deg/s to rad/s
        gyro_x_rad = math.radians(gyro_x)
        gyro_y_rad = math.radians(gyro_y)
        gyro_z_rad = math.radians(gyro_z)

        # Convert accel to m/s² (multiply by gravity)
        accel_x_ms2 = accel_x * 9.81
        accel_y_ms2 = accel_y * 9.81
        accel_z_ms2 = accel_z * 9.81

        return accel_x_ms2, accel_y_ms2, accel_z_ms2, gyro_x_rad, gyro_y_rad, gyro_z_rad

    def calibrate(self):
        """Calibrate gyroscope by averaging readings while stationary"""
        self.get_logger().info('Calibrating IMU... Keep robot stationary!')

        samples = 100
        gyro_x_sum = 0.0
        gyro_y_sum = 0.0
        gyro_z_sum = 0.0

        for _ in range(samples):
            gyro_x = self.read_word_2c(self.GYRO_XOUT_H) / self.GYRO_SCALE
            gyro_y = self.read_word_2c(self.GYRO_XOUT_H + 2) / self.GYRO_SCALE
            gyro_z = self.read_word_2c(self.GYRO_XOUT_H + 4) / self.GYRO_SCALE

            gyro_x_sum += gyro_x
            gyro_y_sum += gyro_y
            gyro_z_sum += gyro_z

            time.sleep(0.01)

        self.gyro_x_offset = gyro_x_sum / samples
        self.gyro_y_offset = gyro_y_sum / samples
        self.gyro_z_offset = gyro_z_sum / samples

        self.get_logger().info(f'Calibration complete. Offsets: x={self.gyro_x_offset:.3f}, '
                               f'y={self.gyro_y_offset:.3f}, z={self.gyro_z_offset:.3f}')

    def publish_imu(self):
        """Read and publish IMU data"""
        try:
            accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z = self.read_imu_data()

            msg = Imu()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'imu_link'

            # Linear acceleration
            msg.linear_acceleration.x = accel_x
            msg.linear_acceleration.y = accel_y
            msg.linear_acceleration.z = accel_z

            # Angular velocity
            msg.angular_velocity.x = gyro_x
            msg.angular_velocity.y = gyro_y
            msg.angular_velocity.z = gyro_z

            # Orientation not provided by raw IMU (set to 0)
            msg.orientation.x = 0.0
            msg.orientation.y = 0.0
            msg.orientation.z = 0.0
            msg.orientation.w = 0.0

            # Covariance matrices (tune based on your sensor)
            msg.orientation_covariance[0] = -1  # -1 means orientation not available
            msg.angular_velocity_covariance[0] = 0.01
            msg.angular_velocity_covariance[4] = 0.01
            msg.angular_velocity_covariance[8] = 0.01
            msg.linear_acceleration_covariance[0] = 0.01
            msg.linear_acceleration_covariance[4] = 0.01
            msg.linear_acceleration_covariance[8] = 0.01

            self.imu_pub.publish(msg)

        except Exception as e:
            self.get_logger().error(f'Error reading IMU: {e}')

def main(args=None):
    rclpy.init(args=args)
    node = IMUPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
