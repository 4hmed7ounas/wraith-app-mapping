#!/usr/bin/env python3
"""
Obstacle avoidance node - uses ultrasonic sensor and servo for random exploration
Publishes cmd_vel to move robot randomly while avoiding obstacles
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from gpiozero import DistanceSensor, AngularServo
import random
import time
import threading

class ObstacleAvoidance(Node):
    def __init__(self):
        super().__init__('obstacle_avoidance')

        # Ultrasonic sensor and servo
        self.sensor = DistanceSensor(echo=21, trigger=20)
        self.servo = AngularServo(12, min_angle=-85, max_angle=85,
                                   min_pulse_width=0.0005, max_pulse_width=0.0025)

        # Parameters
        self.obstacle_threshold = 30.0  # cm
        self.base_speed = 1.0  # 50% of 0.3 max speed
        self.turn_speed = 0.3

        # State
        self.is_active = True
        self.current_servo_angle = 0

        # Publisher
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)

        # Timer for main control loop
        self.timer = self.create_timer(0.1, self.control_loop)  # 10Hz

        # Center servo
        self.set_servo_angle(0)

        self.get_logger().info('Obstacle avoidance node started - Random exploration mode')

    def set_servo_angle(self, target_angle):
        """Smoothly move servo to target angle"""
        target_angle = max(-85, min(85, target_angle))
        current = self.current_servo_angle
        step = 5 if target_angle > current else -5

        if target_angle == current:
            return

        angle_range = range(current, target_angle + 1, step) if target_angle > current else \
                     range(current, target_angle - 1, step)

        for angle in angle_range:
            self.servo.angle = max(-85, min(85, angle))
            time.sleep(0.02)

        self.servo.angle = target_angle
        self.current_servo_angle = target_angle
        time.sleep(0.1)

    def get_distance(self):
        """Get distance from ultrasonic sensor in cm"""
        try:
            return self.sensor.distance * 100
        except:
            return 100.0  # Return safe distance on error

    def scan_environment(self):
        """Scan left, center, right and return distances"""
        # Center
        self.set_servo_angle(0)
        center_dist = self.get_distance()

        # Right
        self.set_servo_angle(60)
        right_dist = self.get_distance()

        # Left
        self.set_servo_angle(-60)
        left_dist = self.get_distance()

        # Return to center
        self.set_servo_angle(0)

        return center_dist, left_dist, right_dist

    def publish_cmd_vel(self, linear_x, angular_z):
        """Publish velocity command"""
        msg = Twist()
        msg.linear.x = linear_x
        msg.angular.z = angular_z
        self.cmd_vel_pub.publish(msg)

    def stop(self):
        """Stop the robot"""
        self.publish_cmd_vel(0.0, 0.0)

    def control_loop(self):
        """Main control loop for random exploration with obstacle avoidance"""
        if not self.is_active:
            return

        # Quick check front distance
        front_dist = self.get_distance()

        if front_dist < self.obstacle_threshold:
            # Obstacle detected - stop and scan
            self.stop()
            time.sleep(0.2)

            center_dist, left_dist, right_dist = self.scan_environment()

            self.get_logger().info(f'Obstacle! Distances - C:{center_dist:.1f} L:{left_dist:.1f} R:{right_dist:.1f}')

            # Back up a bit
            self.publish_cmd_vel(-self.base_speed, 0.0)
            time.sleep(0.5)
            self.stop()

            # Decide turn direction based on scan
            if left_dist > right_dist and left_dist > self.obstacle_threshold:
                # Turn left
                turn_time = random.uniform(0.5, 1.0)
                self.publish_cmd_vel(0.0, self.turn_speed)
                self.get_logger().info(f'Turning left for {turn_time:.1f}s')
                time.sleep(turn_time)
            elif right_dist > left_dist and right_dist > self.obstacle_threshold:
                # Turn right
                turn_time = random.uniform(0.5, 1.0)
                self.publish_cmd_vel(0.0, -self.turn_speed)
                self.get_logger().info(f'Turning right for {turn_time:.1f}s')
                time.sleep(turn_time)
            else:
                # Both sides blocked - turn around
                self.publish_cmd_vel(0.0, self.turn_speed)
                self.get_logger().info('Turning around')
                time.sleep(1.5)

            self.stop()
            time.sleep(0.1)

        else:
            # No obstacle - move forward with slight random variations
            # Add small random variations to make exploration more thorough
            random_turn = random.uniform(-0.1, 0.1) if random.random() > 0.8 else 0.0
            speed_variation = random.uniform(0.8, 1.0)

            self.publish_cmd_vel(self.base_speed * speed_variation, random_turn)

    def shutdown(self):
        """Clean shutdown"""
        self.is_active = False
        self.stop()
        self.set_servo_angle(0)

def main(args=None):
    rclpy.init(args=args)
    node = ObstacleAvoidance()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
