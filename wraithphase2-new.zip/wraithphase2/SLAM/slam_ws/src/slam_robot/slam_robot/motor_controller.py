#!/usr/bin/env python3
"""
Motor controller node - interfaces with gpiozero to control BTS7960 motors
Subscribes to /cmd_vel and controls robot motors
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from gpiozero import PWMOutputDevice, OutputDevice
import signal
import sys

class MotorController(Node):
    def __init__(self):
        super().__init__('motor_controller')

        # Motor A Control Pins (BTS7960)
        self.RPWM_A = PWMOutputDevice(18)
        self.LPWM_A = PWMOutputDevice(23)
        self.REN_A = OutputDevice(24)
        self.LEN_A = OutputDevice(25)

        # Motor B Control Pins (BTS7960)
        self.RPWM_B = PWMOutputDevice(22)
        self.LPWM_B = PWMOutputDevice(27)
        self.REN_B = OutputDevice(5)
        self.LEN_B = OutputDevice(6)

        # Robot physical parameters
        self.wheel_separation = 0.21336  # 0.7 feet in meters
        self.wheel_radius = 0.0325  # 6.5cm diameter

        # Speed limits (50% as requested)
        self.max_speed = 0.3

        # Enable motors
        self.enable_motors()

        # Subscribe to cmd_vel
        self.subscription = self.create_subscription(
            Twist,
            'cmd_vel',
            self.cmd_vel_callback,
            10
        )

        self.get_logger().info('Motor controller node started')

        # Setup signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

    def enable_motors(self):
        """Enable both motors"""
        self.REN_A.on()
        self.LEN_A.on()
        self.REN_B.on()
        self.LEN_B.on()

    def disable_motors(self):
        """Disable both motors"""
        self.RPWM_A.value = 0
        self.LPWM_A.value = 0
        self.REN_A.off()
        self.LEN_A.off()
        self.RPWM_B.value = 0
        self.LPWM_B.value = 0
        self.REN_B.off()
        self.LEN_B.off()

    def set_motor_A(self, speed):
        """Set motor A speed (-1.0 to 1.0)"""
        speed = max(min(speed, 1.0), -1.0)
        if speed > 0:
            self.LPWM_A.value = 0
            self.RPWM_A.value = speed
        elif speed < 0:
            self.RPWM_A.value = 0
            self.LPWM_A.value = abs(speed)
        else:
            self.RPWM_A.value = 0
            self.LPWM_A.value = 0

    def set_motor_B(self, speed):
        """Set motor B speed (-1.0 to 1.0)"""
        speed = max(min(speed, 1.0), -1.0)
        if speed > 0:
            self.LPWM_B.value = 0
            self.RPWM_B.value = speed
        elif speed < 0:
            self.RPWM_B.value = 0
            self.LPWM_B.value = abs(speed)
        else:
            self.RPWM_B.value = 0
            self.LPWM_B.value = 0

    def cmd_vel_callback(self, msg):
        """
        Convert cmd_vel to motor speeds
        Differential drive: v = linear velocity, w = angular velocity
        left_vel = v - (w * wheel_separation / 2)
        right_vel = v + (w * wheel_separation / 2)
        """
        linear_vel = msg.linear.x  # Forward velocity (m/s)
        angular_vel = msg.angular.z  # Rotation velocity (rad/s)

        # Calculate wheel velocities
        left_vel = linear_vel - (angular_vel * self.wheel_separation / 2.0)
        right_vel = linear_vel + (angular_vel * self.wheel_separation / 2.0)

        # Convert to motor speeds (-1 to 1), limit to max_speed
        max_wheel_vel = 1  # m/s - adjust based on your motor specs
        left_speed = (left_vel / max_wheel_vel) * self.max_speed
        right_speed = (right_vel / max_wheel_vel) * self.max_speed

        # Clamp values
        left_speed = max(min(left_speed, self.max_speed), -self.max_speed)
        right_speed = max(min(right_speed, self.max_speed), -self.max_speed)

        # Set motor speeds
        self.set_motor_A(left_speed)
        self.set_motor_B(right_speed)

    def signal_handler(self, sig, frame):
        """Handle shutdown signals"""
        self.get_logger().info('Shutting down motor controller...')
        self.disable_motors()
        sys.exit(0)

    def __del__(self):
        """Cleanup on deletion"""
        self.disable_motors()

def main(args=None):
    rclpy.init(args=args)
    node = MotorController()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.disable_motors()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
