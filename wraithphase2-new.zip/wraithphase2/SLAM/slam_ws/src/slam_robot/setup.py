from setuptools import find_packages, setup

package_name = 'slam_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/mapping.launch.py',
                                                'launch/rplidar.launch.py',
                                                'launch/slam_toolbox.launch.py',
                                                'launch/navigation.launch.py']),
        ('share/' + package_name + '/config', ['config/slam_toolbox_params.yaml',
                                                'config/amcl_params.yaml',
                                                'config/nav2_params.yaml']),
        ('share/' + package_name + '/urdf', ['urdf/robot.urdf']),
        ('share/' + package_name + '/scripts', ['scripts/save_map.py',
                                                 'scripts/go_to.py',
                                                 'scripts/list_waypoints.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='zaid',
    maintainer_email='zaid@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'motor_controller = slam_robot.motor_controller:main',
            'odometry_publisher = slam_robot.odometry_publisher:main',
            'imu_publisher = slam_robot.imu_publisher:main',
            'obstacle_avoidance = slam_robot.obstacle_avoidance:main',
            'manual_control_server = slam_robot.manual_control_server:main',
            'auto_waypoint_generator = slam_robot.auto_waypoint_generator:main',
            'waypoint_navigator = slam_robot.waypoint_navigator:main',
            'waypoint_visualizer = slam_robot.waypoint_visualizer:main',
            'feature_based_localizer = slam_robot.feature_based_localizer:main',
            'go_to = scripts.go_to:main',
            'list_waypoints = scripts.list_waypoints:main',
        ],
    },
)
