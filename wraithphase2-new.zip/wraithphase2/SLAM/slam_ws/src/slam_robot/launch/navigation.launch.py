"""
Navigation Launch File

Launches autonomous navigation stack with:
- Map server (loads saved map)
- AMCL localization
- Nav2 navigation stack
- Waypoint navigator for label-based navigation
- All sensor nodes (lidar, odometry, IMU)
- Motor controller

Usage:
    ros2 launch slam_robot navigation.launch.py map:=unimap2

Author: Wraith Robot Team
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_share = get_package_share_directory('slam_robot')
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    # Declare launch arguments
    map_name_arg = DeclareLaunchArgument(
        'map',
        default_value='unimap2',
        description='Name of the map file (without extension)'
    )

    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='false',
        description='Use simulation time'
    )

    # Get launch configurations
    map_name = LaunchConfiguration('map')
    use_sim_time = LaunchConfiguration('use_sim_time')

    # Map file paths
    maps_dir = '/home/zaid/slam_maps'
    map_yaml_file = PathJoinSubstitution([maps_dir, [map_name, '.yaml']])

    # Config file paths
    amcl_config = os.path.join(pkg_share, 'config', 'amcl_params.yaml')
    nav2_config = os.path.join(pkg_share, 'config', 'nav2_params.yaml')
    urdf_file = os.path.join(pkg_share, 'urdf', 'robot.urdf')

    # Read URDF
    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # ========== ROBOT HARDWARE NODES ==========

    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_desc, 'use_sim_time': use_sim_time}]
    )

    # RPLidar
    rplidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('slam_robot'),
                'launch',
                'rplidar.launch.py'
            ])
        ])
    )

    # Motor Controller
    motor_controller = Node(
        package='slam_robot',
        executable='motor_controller',
        name='motor_controller',
        output='screen'
    )

    # Odometry Publisher
    odometry_publisher = Node(
        package='slam_robot',
        executable='odometry_publisher',
        name='odometry_publisher',
        output='screen'
    )

    # IMU Publisher
    imu_publisher = Node(
        package='slam_robot',
        executable='imu_publisher',
        name='imu_publisher',
        output='screen'
    )

    # IMU Filter
    imu_filter = Node(
        package='imu_filter_madgwick',
        executable='imu_filter_madgwick_node',
        name='imu_filter',
        parameters=[{
            'use_mag': False,
            'publish_tf': False,
            'world_frame': 'enu',
            'fixed_frame': 'odom'
        }],
        remappings=[
            ('imu/data_raw', 'imu/data_raw'),
            ('imu/data', 'imu/data')
        ],
        output='screen'
    )

    # Robot Localization (EKF) - fuses odometry and IMU
    ekf_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[{
            'frequency': 15.0,  # Reduced from 30.0 for Raspberry Pi CPU
            'two_d_mode': True,
            'publish_tf': True,
            'map_frame': 'map',
            'odom_frame': 'odom',
            'base_link_frame': 'base_footprint',
            'world_frame': 'odom',

            'odom0': 'odom',
            'odom0_config': [
                True,  True,  False,
                False, False, True,
                True,  True,  False,
                False, False, True,
                False, False, False
            ],

            'imu0': 'imu/data',
            'imu0_config': [
                False, False, False,
                False, False, True,
                False, False, False,
                False, False, True,
                False, False, False
            ],
            'imu0_differential': False,
            'imu0_relative': False,
        }]
    )

    # ========== NAVIGATION NODES ==========

    # Map Server
    map_server = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[{
            'yaml_filename': map_yaml_file,
            'use_sim_time': use_sim_time
        }]
    )

    # AMCL (Adaptive Monte Carlo Localization)
    amcl = Node(
        package='nav2_amcl',
        executable='amcl',
        name='amcl',
        output='screen',
        parameters=[amcl_config]
    )

    # Localization Lifecycle Manager (manages map_server and amcl in sequence)
    # map_server MUST activate before amcl to provide the map
    localization_lifecycle_manager = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='localization_lifecycle_manager',
        output='screen',
        parameters=[{
            'autostart': True,
            'node_names': ['map_server', 'amcl'],
            'bond_timeout': 4.0
        }]
    )

    # Nav2 Bringup (full navigation stack)
    nav2_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_bringup_dir, 'launch', 'navigation_launch.py')
        ),
        launch_arguments={
            'use_sim_time': use_sim_time,
            'params_file': nav2_config,
            'autostart': 'true'
        }.items()
    )

    # Waypoint Navigator (for label-based navigation)
    waypoint_navigator = Node(
        package='slam_robot',
        executable='waypoint_navigator',
        name='waypoint_navigator',
        output='screen',
        parameters=[{
            'map_name': map_name,
            'maps_directory': maps_dir
        }]
    )

    # Feature-Based Localizer (automatic initial pose + map verification)
    # Auto-initialization works with maps that have environmental features (ghar5, etc.)
    feature_based_localizer = Node(
        package='slam_robot',
        executable='feature_based_localizer',
        name='feature_based_localizer',
        output='screen',
        parameters=[{
            'map_name': map_name,
            'waypoints_directory': maps_dir,
            'auto_initialize': True,  # ✓ ENABLED - automatic localization!
            'match_threshold': 2.0,  # Max 2m average error for match (more lenient)
            'confidence_threshold': 0.7,  # AMCL confidence threshold
            'verification_interval': 5.0  # Check every 5 seconds
        }]
    )

    # Waypoint Visualizer (shows waypoints in RViz2)
    waypoint_visualizer = Node(
        package='slam_robot',
        executable='waypoint_visualizer',
        name='waypoint_visualizer',
        output='screen',
        parameters=[{
            'map_name': map_name,
            'maps_directory': maps_dir
        }]
    )

    # ========== LAUNCH DESCRIPTION ==========

    ld = LaunchDescription()

    # Add arguments
    ld.add_action(map_name_arg)
    ld.add_action(use_sim_time_arg)

    # Add robot hardware nodes
    ld.add_action(robot_state_publisher)
    ld.add_action(rplidar_launch)
    ld.add_action(motor_controller)
    ld.add_action(odometry_publisher)
    ld.add_action(imu_publisher)
    ld.add_action(imu_filter)
    ld.add_action(ekf_node)

    # Add navigation nodes
    ld.add_action(map_server)
    ld.add_action(amcl)
    ld.add_action(localization_lifecycle_manager)
    ld.add_action(nav2_bringup)
    ld.add_action(waypoint_navigator)
    ld.add_action(feature_based_localizer)
    ld.add_action(waypoint_visualizer)

    return ld
