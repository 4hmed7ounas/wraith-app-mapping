from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, PythonExpression
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('slam_robot')
    urdf_file = os.path.join(pkg_share, 'urdf', 'robot.urdf')

    # Launch arguments - control_mode defaults to 'manual' for Flutter app
    control_mode_arg = DeclareLaunchArgument(
        'control_mode',
        default_value='manual',
        description='Control mode: "manual" for Flutter app control (default), "auto" for autonomous exploration'
    )

    # Get launch configurations
    control_mode = LaunchConfiguration('control_mode')

    # Read URDF
    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_desc}]
    )

    # RPLidar
    rplidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('slam_robot'),
                'launch',
                'rplidar.launch.py'
            ])
        ])
    )

    # Motor Controller - Only in AUTO mode (manual_control_server handles it in manual mode)
    motor_controller = Node(
        package='slam_robot',
        executable='motor_controller',
        name='motor_controller',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", control_mode, "' == 'auto'"])
        )
    )

    # Odometry Publisher - Only in AUTO mode (manual_control_server handles it in manual mode)
    odometry_publisher = Node(
        package='slam_robot',
        executable='odometry_publisher',
        name='odometry_publisher',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", control_mode, "' == 'auto'"])
        )
    )

    # IMU Publisher
    imu_publisher = Node(
        package='slam_robot',
        executable='imu_publisher',
        name='imu_publisher',
        output='screen'
    )

    # IMU Filter (for orientation estimation)
    imu_filter = Node(
        package='imu_filter_madgwick',
        executable='imu_filter_madgwick_node',
        name='imu_filter',
        parameters=[{
            'use_mag': False,
            'publish_tf': False,
            'world_frame': 'enu',
            'fixed_frame': 'odom'
        }],
        remappings=[
            ('imu/data_raw', 'imu/data_raw'),
            ('imu/data', 'imu/data')
        ],
        output='screen'
    )

    # Robot Localization (EKF) - fuses odometry and IMU
    ekf_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[{
            'frequency': 30.0,
            'two_d_mode': True,
            'publish_tf': True,
            'map_frame': 'map',
            'odom_frame': 'odom',
            'base_link_frame': 'base_footprint',
            'world_frame': 'odom',

            'odom0': 'odom',
            'odom0_config': [
                True,  True,  False,  # x, y, z
                False, False, True,   # roll, pitch, yaw
                True,  True,  False,  # vx, vy, vz
                False, False, True,   # vroll, vpitch, vyaw
                False, False, False   # ax, ay, az
            ],

            'imu0': 'imu/data',
            'imu0_config': [
                False, False, False,  # x, y, z
                False, False, True,   # roll, pitch, yaw
                False, False, False,  # vx, vy, vz
                False, False, True,   # vroll, vpitch, vyaw
                False, False, False   # ax, ay, az
            ],
            'imu0_differential': False,
            'imu0_relative': False,
        }]
    )

    # Obstacle Avoidance (Random Exploration) - Only in AUTO mode
    obstacle_avoidance = Node(
        package='slam_robot',
        executable='obstacle_avoidance',
        name='obstacle_avoidance',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", control_mode, "' == 'auto'"])
        )
    )

    # Manual Control Server (HTTP API) - Only in MANUAL mode
    manual_control_server = Node(
        package='slam_robot',
        executable='manual_control_server',
        name='manual_control_server',
        output='screen',
        parameters=[{
            'port': 5000
        }],
        condition=IfCondition(
            PythonExpression(["'", control_mode, "' == 'manual'"])
        )
    )

    # Auto Waypoint Generator (NEW - creates labeled waypoints during mapping)
    auto_waypoint_generator = Node(
        package='slam_robot',
        executable='auto_waypoint_generator',
        name='auto_waypoint_generator',
        output='screen',
        parameters=[{
            'waypoint_interval_time': 5.0,       # Create waypoint every 5 seconds
            'waypoint_interval_distance': 0.5,   # OR every 0.5 meters traveled
            'min_distance_between_waypoints': 0.3,  # Minimum 0.3m between waypoints
            'map_name': 'auto_generated_map',    # Will be updated by save_map.py
            'output_directory': '/home/zaid/slam_maps'
        }]
    )

    # SLAM Toolbox
    slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('slam_robot'),
                'launch',
                'slam_toolbox.launch.py'
            ])
        ])
    )

    ld = LaunchDescription()

    # Add launch arguments
    ld.add_action(control_mode_arg)

    # Add all nodes
    ld.add_action(robot_state_publisher)
    ld.add_action(rplidar_launch)
    ld.add_action(motor_controller)
    ld.add_action(odometry_publisher)
    ld.add_action(imu_publisher)
    ld.add_action(imu_filter)
    ld.add_action(ekf_node)
    ld.add_action(obstacle_avoidance)  # Only launches in AUTO mode
    ld.add_action(manual_control_server)  # Only launches in MANUAL mode
    ld.add_action(auto_waypoint_generator)  # Auto waypoint generation
    ld.add_action(slam_launch)

    return ld
