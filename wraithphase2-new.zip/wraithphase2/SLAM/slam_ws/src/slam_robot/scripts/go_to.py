#!/usr/bin/env python3
"""
Go To Waypoint Command

Simple command-line tool to navigate to labeled waypoints.

Usage:
    ros2 run slam_robot go_to Point_A
    ros2 run slam_robot go_to Point_B
"""

import sys
import rclpy
from slam_robot.waypoint_navigator import WaypointNavigator


def main():
    """Main entry point for go_to command"""

    # Check arguments
    if len(sys.argv) < 2:
        print("=" * 60)
        print("Usage: ros2 run slam_robot go_to <label> --map <map_name>")
        print("=" * 60)
        print("Examples:")
        print("  ros2 run slam_robot go_to Point_A --map test_qos_fix")
        print("  ros2 run slam_robot go_to Point_B --map test_qos_fix")
        print("=" * 60)
        print("\nTo see available waypoints, run:")
        print("  ros2 run slam_robot list_waypoints --map test_qos_fix")
        print("=" * 60)
        sys.exit(1)

    label = sys.argv[1]

    # Parse optional map name
    map_name = ''
    if len(sys.argv) > 2:
        if sys.argv[2] == '--map' and len(sys.argv) > 3:
            map_name = sys.argv[3]
        else:
            map_name = sys.argv[2]

    if not map_name:
        print("=" * 60)
        print("ERROR: Map name required!")
        print("=" * 60)
        print("Usage:")
        print("  ros2 run slam_robot go_to <label> --map <map_name>")
        print("\nExample:")
        print("  ros2 run slam_robot go_to Point_B --map test_qos_fix")
        print("=" * 60)
        sys.exit(1)

    # Initialize ROS2
    rclpy.init()

    try:
        # Create navigator node with map name
        navigator = WaypointNavigator(map_name=map_name)

        # Give node time to initialize
        rclpy.spin_once(navigator, timeout_sec=1.0)

        # Send navigation goal
        success = navigator.go_to(label)

        if success:
            print(f"✓ Navigation goal sent to '{label}'")
            print("  Watch robot navigate in RViz or check /goal_pose topic")
        else:
            print(f"✗ Failed to navigate to '{label}'")
            print("\nRun 'ros2 run slam_robot list_waypoints' to see available waypoints")
            sys.exit(1)

    except KeyboardInterrupt:
        print("\nInterrupted by user")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        navigator.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
