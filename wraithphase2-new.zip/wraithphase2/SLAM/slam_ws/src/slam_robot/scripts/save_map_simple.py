#!/usr/bin/env python3
"""
Simple map saving script - saves map directly without hanging
Usage: python3 save_map_simple.py <map_name>
"""
import sys
import subprocess
import os
from datetime import datetime

def save_map(map_name=None):
    """Save the current map using map_saver CLI"""

    # Create maps directory if it doesn't exist
    maps_dir = os.path.expanduser('~/slam_maps')
    os.makedirs(maps_dir, exist_ok=True)

    # Generate map name if not provided
    if map_name is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        map_name = f'slam_map_{timestamp}'

    # Full path for map
    map_path = os.path.join(maps_dir, map_name)

    print(f'Saving map to: {map_path}')

    try:
        # Save map using ROS2 map_saver with shorter timeout
        cmd = [
            'ros2', 'run', 'nav2_map_server', 'map_saver_cli',
            '-f', map_path,
            '--ros-args',
            '-p', 'save_map_timeout:=5000.0'
        ]

        print('Running map saver (this may take 5-10 seconds)...')
        result = subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=15)
        print(result.stdout)

        # Check if files were created
        pgm_file = f'{map_path}.pgm'
        yaml_file = f'{map_path}.yaml'

        if not os.path.exists(pgm_file):
            print(f'ERROR: Map file not created: {pgm_file}')
            print('Make sure SLAM is running and publishing /map topic')
            sys.exit(1)

        # Convert PGM to PNG for better compatibility
        png_file = f'{map_path}.png'
        try:
            from PIL import Image
            img = Image.open(pgm_file)
            img.save(png_file)
            print(f'✓ Map saved as PNG: {png_file}')
        except ImportError:
            print('Note: PIL not installed, skipping PNG conversion')

        print(f'✓ Map metadata saved as: {yaml_file}')

        print('\n=== Map Saved Successfully ===')
        print(f'Location: {maps_dir}')
        print(f'Files created:')
        print(f'  - {map_name}.pgm (original)')
        if os.path.exists(png_file):
            print(f'  - {map_name}.png (for visualization)')
        print(f'  - {map_name}.yaml (metadata for navigation)')

        # Check for waypoints file
        waypoints_file = f'{map_path}_waypoints.yaml'
        if os.path.exists(waypoints_file):
            print(f'  - {map_name}_waypoints.yaml (auto-generated waypoints) ✓')
        else:
            print(f'\nNote: Waypoints file not found yet.')
            print(f'If auto_waypoint_generator was running, it will save on shutdown.')

        print('\nYou can use this map for navigation with Nav2!')

    except subprocess.TimeoutExpired:
        print('\nERROR: Map saver timed out!')
        print('This usually means:')
        print('  1. SLAM is not publishing /map topic')
        print('  2. SLAM was stopped before saving')
        print('\nTry:')
        print('  ros2 topic echo /map --once')
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f'Error saving map: {e}')
        if e.stderr:
            print(f'stderr: {e.stderr}')
        sys.exit(1)
    except Exception as e:
        print(f'Error: {e}')
        sys.exit(1)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        save_map(sys.argv[1])
    else:
        save_map()
