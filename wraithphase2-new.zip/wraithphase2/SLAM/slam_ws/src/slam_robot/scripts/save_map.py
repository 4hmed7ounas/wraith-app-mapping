#!/usr/bin/env python3
"""
Map saving script - saves map in PNG and YAML formats for navigation
Also triggers waypoint saving from auto_waypoint_generator node

Usage: python3 save_map.py <map_name>
"""
import sys
import subprocess
import os
from datetime import datetime
import rclpy
from rclpy.node import Node

def save_map(map_name=None):
    """Save the current map using map_saver CLI"""

    # Create maps directory if it doesn't exist
    maps_dir = os.path.expanduser('~/slam_maps')
    os.makedirs(maps_dir, exist_ok=True)

    # Generate map name if not provided
    if map_name is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        map_name = f'slam_map_{timestamp}'

    # Full path for map
    map_path = os.path.join(maps_dir, map_name)

    print(f'Saving map to: {map_path}')

    try:
        # Save map using ROS2 map_saver
        # This will create map_name.pgm and map_name.yaml
        cmd = [
            'ros2', 'run', 'nav2_map_server', 'map_saver_cli',
            '-f', map_path,
            '--ros-args',
            '-p', 'save_map_timeout:=10000.0'
        ]

        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print(result.stdout)

        # Convert PGM to PNG for better compatibility
        pgm_file = f'{map_path}.pgm'
        png_file = f'{map_path}.png'

        if os.path.exists(pgm_file):
            try:
                from PIL import Image
                img = Image.open(pgm_file)
                img.save(png_file)
                print(f'Map saved as PNG: {png_file}')
                print(f'Map metadata saved as: {map_path}.yaml')
            except ImportError:
                print('PIL/Pillow not installed. Installing...')
                subprocess.run(['pip3', 'install', 'Pillow'], check=True)
                from PIL import Image
                img = Image.open(pgm_file)
                img.save(png_file)
                print(f'Map saved as PNG: {png_file}')
                print(f'Map metadata saved as: {map_path}.yaml')

        print('\n=== Map Saved Successfully ===')
        print(f'Location: {maps_dir}')
        print(f'Files created:')
        print(f'  - {map_name}.pgm (original)')
        print(f'  - {map_name}.png (for visualization)')
        print(f'  - {map_name}.yaml (metadata for navigation)')

        # Update waypoint file name (waypoints are auto-saved after each creation)
        print('\nChecking for waypoints...')

        # First, try to update the parameter on the running node
        try:
            param_cmd = [
                'ros2', 'param', 'set',
                '/auto_waypoint_generator',
                'map_name',
                map_name
            ]
            result = subprocess.run(param_cmd, capture_output=True, timeout=3, text=True)

            if result.returncode == 0:
                print(f'  ✓ Parameter updated on waypoint generator node')
                # Give the node a moment to re-save with new name
                import time
                time.sleep(1)
        except Exception:
            # Node might not be running, that's okay
            pass

        # Now always check for and rename waypoint files
        waypoint_file = os.path.join(maps_dir, f'{map_name}_waypoints.yaml')
        old_file = os.path.join(maps_dir, 'auto_generated_map_waypoints.yaml')

        if os.path.exists(waypoint_file):
            print(f'  ✓ Waypoints already saved: {map_name}_waypoints.yaml')
        elif os.path.exists(old_file):
            import shutil
            shutil.copy2(old_file, waypoint_file)
            print(f'  ✓ Copied waypoints to: {map_name}_waypoints.yaml')
            print(f'  ℹ Original file preserved: auto_generated_map_waypoints.yaml')
        else:
            print(f'  ℹ No waypoints created during this mapping session')

        print('\nYou can use this map for navigation with Nav2!')

    except subprocess.CalledProcessError as e:
        print(f'Error saving map: {e}')
        print(f'stderr: {e.stderr}')
        sys.exit(1)
    except Exception as e:
        print(f'Error: {e}')
        sys.exit(1)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        save_map(sys.argv[1])
    else:
        save_map()
