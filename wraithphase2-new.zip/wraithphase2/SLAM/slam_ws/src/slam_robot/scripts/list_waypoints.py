#!/usr/bin/env python3
"""
List Waypoints Command

Display all available waypoints from a saved map.

Usage:
    ros2 run slam_robot list_waypoints
    ros2 run slam_robot list_waypoints --map unimap2
"""

import sys
import rclpy
from slam_robot.waypoint_navigator import WaypointNavigator


def main():
    """Main entry point for list_waypoints command"""

    # Parse optional map name argument
    map_name = ''
    if len(sys.argv) > 1:
        if sys.argv[1] in ['--help', '-h']:
            print("=" * 60)
            print("List Waypoints - Display available navigation waypoints")
            print("=" * 60)
            print("Usage:")
            print("  ros2 run slam_robot list_waypoints --map <map_name>")
            print("=" * 60)
            print("Examples:")
            print("  ros2 run slam_robot list_waypoints --map test_qos_fix")
            print("  ros2 run slam_robot list_waypoints --map unimap2")
            print("=" * 60)
            sys.exit(0)
        elif sys.argv[1] == '--map' and len(sys.argv) > 2:
            map_name = sys.argv[2]
        else:
            map_name = sys.argv[1]

    if not map_name:
        print("=" * 60)
        print("ERROR: Map name required!")
        print("=" * 60)
        print("Usage:")
        print("  ros2 run slam_robot list_waypoints --map <map_name>")
        print("\nExample:")
        print("  ros2 run slam_robot list_waypoints --map test_qos_fix")
        print("=" * 60)
        sys.exit(1)

    # Initialize ROS2
    rclpy.init()

    try:
        # Create navigator node with map name
        navigator = WaypointNavigator(map_name=map_name)

        # Give node time to initialize
        rclpy.spin_once(navigator, timeout_sec=1.0)

        # List waypoints
        navigator.list_waypoints()

        waypoint_list = navigator.get_waypoint_list()

        if len(waypoint_list) > 0:
            print("\n" + "=" * 60)
            print("To navigate to a waypoint, use:")
            print("  ros2 run slam_robot go_to <label>")
            print("=" * 60)
            print("Examples:")
            for i, label in enumerate(waypoint_list[:3]):  # Show first 3 examples
                print(f"  ros2 run slam_robot go_to {label}")
            if len(waypoint_list) > 3:
                print(f"  ... and {len(waypoint_list) - 3} more")
            print("=" * 60)
        else:
            print("\n" + "=" * 60)
            print("No waypoints found!")
            print("=" * 60)
            print("Make sure you:")
            print("  1. Completed mapping with auto-waypoint generation")
            print("  2. Saved the map with waypoints")
            print("  3. Specified correct map name if using --map option")
            print("=" * 60)

    except KeyboardInterrupt:
        print("\nInterrupted by user")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        navigator.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
