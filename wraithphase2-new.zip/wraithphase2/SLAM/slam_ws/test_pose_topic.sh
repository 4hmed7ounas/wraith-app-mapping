#!/bin/bash
# Test script to check SLAM pose topic

echo "==================================="
echo "CHECKING SLAM POSE TOPIC"
echo "==================================="

echo ""
echo "1. Checking if /pose topic exists..."
ros2 topic list | grep pose

echo ""
echo "2. Checking topic info..."
ros2 topic info /pose

echo ""
echo "3. Checking topic type..."
ros2 topic type /pose

echo ""
echo "4. Checking publishers on /pose..."
ros2 topic info /pose -v

echo ""
echo "5. Trying to get ONE message (waiting 10 seconds)..."
timeout 10 ros2 topic echo /pose --once || echo "NO DATA RECEIVED!"

echo ""
echo "6. Checking SLAM Toolbox topics..."
ros2 topic list | grep slam

echo ""
echo "7. Checking if SLAM publishes anything..."
ros2 node info /slam_toolbox | grep -A 20 "Publishers:"

echo ""
echo "==================================="
echo "TEST COMPLETE"
echo "==================================="
