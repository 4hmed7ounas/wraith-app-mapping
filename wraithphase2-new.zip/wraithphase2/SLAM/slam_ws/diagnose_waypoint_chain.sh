#!/bin/bash
# Diagnose the full odometry → waypoint chain

echo "==========================================="
echo "WAYPOINT CHAIN DIAGNOSTICS"
echo "==========================================="
echo ""

echo "1. Checking /odom topic..."
ros2 topic info /odom
echo ""

echo "2. Checking /odometry/filtered topic (from EKF)..."
ros2 topic info /odometry/filtered
echo ""

echo "3. Checking /pose topic (from SLAM)..."
ros2 topic info /pose
echo ""

echo "4. Checking if auto_waypoint_generator node is running..."
ros2 node list | grep waypoint
echo ""

echo "5. Checking auto_waypoint_generator subscriptions..."
ros2 node info /auto_waypoint_generator | grep -A 20 "Subscribers:"
echo ""

echo "6. Getting ONE message from /odometry/filtered (10 sec timeout)..."
timeout 10 ros2 topic echo /odometry/filtered --once || echo "NO DATA!"
echo ""

echo "7. Getting ONE message from /pose (10 sec timeout)..."
timeout 10 ros2 topic echo /pose --once || echo "NO DATA!"
echo ""

echo "==========================================="
echo "DIAGNOSTICS COMPLETE"
echo "==========================================="
