#!/bin/bash
# Complete mapping startup script with diagnostics
# This script helps you start mapping with waypoint generation

cd /home/zaid/SLAM/slam_ws
source install/setup.bash

echo "╔══════════════════════════════════════════════════════════╗"
echo "║     Wraith Robot - Mapping with Auto-Waypoints         ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "This script will guide you through starting the mapping system."
echo ""

# Check if build is up to date
echo "Checking system..."
if [ ! -f "install/slam_robot/lib/slam_robot/auto_waypoint_generator" ]; then
    echo "⚠ Warning: auto_waypoint_generator not found!"
    echo "  Running: colcon build --packages-select slam_robot"
    colcon build --packages-select slam_robot
    source install/setup.bash
fi

echo "✓ System ready"
echo ""
echo "════════════════════════════════════════════════════════════"
echo " TERMINAL 1: Starting Mapping Launch"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "Command executing:"
echo "  ros2 launch slam_robot mapping.launch.py"
echo ""
echo "IMPORTANT: Watch for this line in the output:"
echo "  [auto_waypoint_generator]: Auto-Waypoint Generator Started"
echo ""
echo "If you DON'T see this line, press Ctrl+C and check:"
echo "  - Node list: ros2 node list"
echo "  - Topic list: ros2 topic list"
echo ""
echo "Starting in 3 seconds..."
sleep 1
echo "Starting in 2 seconds..."
sleep 1
echo "Starting in 1 second..."
sleep 1
echo ""
echo "LAUNCHING NOW..."
echo "════════════════════════════════════════════════════════════"

ros2 launch slam_robot mapping.launch.py
