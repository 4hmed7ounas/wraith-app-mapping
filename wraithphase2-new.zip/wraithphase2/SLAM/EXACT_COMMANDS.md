# 🎯 Exact Commands - Copy & Paste Ready

**Last Updated:** After fresh rebuild
**Status:** ✅ System verified and ready

---

## 🔍 Pre-Flight Check (Run Once)

```bash
cd /home/zaid/SLAM
./test_waypoint_system.sh
```

**Expected:** All checks should pass ✓

---

## 📍 MAPPING WITH AUTO-WAYPOINTS

### Option 1: Automated Scripts (Easiest)

#### Terminal 1:
```bash
cd /home/zaid/SLAM
./START_MAPPING_HERE.sh
```

#### Terminal 2:
```bash
cd /home/zaid/SLAM
./ACTIVATE_SLAM_TERMINAL2.sh
```

---

### Option 2: Manual Commands (Full Control)

#### Terminal 1: Launch Mapping
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
```

**IMPORTANT: Look for this line in the output:**
```
[auto_waypoint_generator]: Auto-Waypoint Generator Started
[auto_waypoint_generator]: ============================================================
[auto_waypoint_generator]: Interval: 15.0s OR 2.5m
```

If you **DON'T** see these lines, the node didn't start! Stop and debug.

---

#### Terminal 2: Activate SLAM & Verify

```bash
cd ~/SLAM/slam_ws
source install/setup.bash

# Wait 10 seconds for all nodes to start, then:

# Activate SLAM
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# CRITICAL: Verify waypoint generator is running
ros2 node list | grep auto_waypoint
```

**Expected output:**
```
/auto_waypoint_generator
```

**If you see this** → ✅ System is working!
**If you DON'T see this** → ❌ Node didn't start - see troubleshooting below

---

#### Terminal 2: Monitor Waypoint Creation

```bash
# Check parameters
ros2 param get /auto_waypoint_generator waypoint_interval_time
ros2 param get /auto_waypoint_generator waypoint_interval_distance

# Watch for waypoint messages in Terminal 1
# You should see every 15-20 seconds:
#   [auto_waypoint_generator]: ✓ Created Point_A at (0.00, 0.00)
#   [auto_waypoint_generator]: ✓ Created Point_B at (2.30, 1.50)
```

---

#### Wait 3-5 Minutes for Exploration

Let the robot map the area and create waypoints automatically.

---

#### Stop Mapping & Save

**Terminal 1:** Press `Ctrl+C` to stop mapping

**Terminal 2:**
```bash
cd ~/SLAM/slam_ws

# Save map (replace 'my_office' with your map name)
python3 src/slam_robot/scripts/save_map.py my_office

# Verify all files created
ls -lh ~/slam_maps/my_office*
```

**Expected files:**
```
my_office.pgm                   ← Map image
my_office.png                   ← Visualization
my_office.yaml                  ← Map metadata
my_office_waypoints.yaml        ← AUTO-GENERATED WAYPOINTS ✅
```

---

#### Verify Waypoints

```bash
cat ~/slam_maps/my_office_waypoints.yaml
```

**Expected content:**
```yaml
map_name: my_office
generation_mode: automatic_time_distance
interval_time_seconds: 15.0
interval_distance_meters: 2.5
total_waypoints: 12
waypoints:
  - label: Point_A
    x: 0.0
    y: 0.0
    theta: 0.0
  - label: Point_B
    x: 2.3
    y: 1.5
    theta: 1.57
  # ... more waypoints
```

---

## 🧭 NAVIGATION (After Mapping)

### Terminal 1: Launch Navigation

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_office
```

---

### Terminal 2: Set Initial Pose (RViz)

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
rviz2
```

**In RViz:**
1. Click **Add** → **By display type** → **Map** → Set topic: `/map`
2. Click **Add** → **By display type** → **LaserScan** → Set topic: `/scan`
3. Click **2D Pose Estimate** button (toolbar)
4. Click where robot is on map, drag to set orientation
5. Watch particles converge around robot

---

### Terminal 3: Navigate to Waypoints

```bash
cd ~/SLAM/slam_ws
source install/setup.bash

# List available waypoints
ros2 run slam_robot list_waypoints

# Navigate to waypoint
ros2 run slam_robot go_to Point_A
ros2 run slam_robot go_to Point_B
ros2 run slam_robot go_to Point_C
```

---

## 🐛 Troubleshooting

### Problem: auto_waypoint_generator not in node list

**Check 1: Is executable installed?**
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 pkg executables slam_robot | grep auto_waypoint
```

**Should show:**
```
slam_robot auto_waypoint_generator
```

**If not shown:**
```bash
cd ~/SLAM/slam_ws
colcon build --packages-select slam_robot
source install/setup.bash
```

---

**Check 2: Is launch file updated?**
```bash
cat install/slam_robot/share/slam_robot/launch/mapping.launch.py | grep -c "auto_waypoint"
```

**Should show:** `4` (or more)

**If shows `0`:**
```bash
rm -rf install/slam_robot
colcon build --packages-select slam_robot
source install/setup.bash
```

---

**Check 3: Does node start standalone?**
```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 run slam_robot auto_waypoint_generator
```

**Should show:**
```
[INFO] [auto_waypoint_generator]: Auto-Waypoint Generator Started
[INFO] [auto_waypoint_generator]: Interval: 15.0s OR 2.5m
```

Press Ctrl+C to stop.

**If errors appear:** Report the error message!

---

### Problem: No waypoints created during mapping

**Symptoms:**
- Node is running
- But no "Created Point_X" messages
- No waypoints file after saving

**Solution:**
```bash
# Check if /pose topic is publishing
ros2 topic hz /pose

# Check if robot is moving
ros2 topic echo /cmd_vel

# Check node parameters
ros2 param list /auto_waypoint_generator
```

**The node needs:**
1. `/pose` topic publishing (from SLAM)
2. Robot moving (to trigger distance-based waypoints)
3. Time passing (for time-based waypoints)

---

### Problem: Waypoints file not created after saving

**Solution:**
```bash
# Check if node saved waypoints before stopping
# Look in Terminal 1 output for:
#   [auto_waypoint_generator]: Saved X waypoints to ...

# If you didn't see this, the node might still be running
ros2 node list | grep auto_waypoint

# If still running, it will save on shutdown
# Stop the node or restart terminal
```

---

## 📋 Quick Reference

### Mapping Commands
```bash
# Terminal 1
cd ~/SLAM && ./START_MAPPING_HERE.sh

# Terminal 2
cd ~/SLAM && ./ACTIVATE_SLAM_TERMINAL2.sh

# After 3-5 min, Terminal 1: Ctrl+C
# Terminal 2:
cd ~/SLAM/slam_ws && python3 src/slam_robot/scripts/save_map.py <name>
```

### Navigation Commands
```bash
# Terminal 1
cd ~/SLAM/slam_ws && source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=<name>

# Terminal 2
rviz2  # Set initial pose

# Terminal 3
ros2 run slam_robot list_waypoints
ros2 run slam_robot go_to Point_X
```

---

## ✅ Success Checklist

During mapping, verify:
- [ ] `[auto_waypoint_generator]: Auto-Waypoint Generator Started` appears
- [ ] `ros2 node list | grep auto_waypoint` shows the node
- [ ] Terminal 1 shows "✓ Created Point_X" messages every 15-20 sec
- [ ] After Ctrl+C: "Saved X waypoints" message appears
- [ ] File exists: `~/slam_maps/<name>_waypoints.yaml`

---

## 🆘 Need Help?

**Run diagnostics:**
```bash
cd /home/zaid/SLAM
./test_waypoint_system.sh
```

**Check what's running:**
```bash
ros2 node list
ros2 topic list
```

**View logs:**
```bash
# In terminal where mapping is running, look for errors
# Check for red [ERROR] or [WARN] messages
```

---

**System is ready! Start with Terminal 1, then Terminal 2, and watch for waypoint creation!** 🚀
