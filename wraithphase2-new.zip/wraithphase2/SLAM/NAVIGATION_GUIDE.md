# Wraith Robot - Auto-Waypoint Navigation System

Complete guide for label-based autonomous navigation with automatically generated waypoints.

---

## 🎯 Overview

This system enables **label-based navigation** where the robot:
1. **Automatically creates waypoints** (Point_A, Point_B, etc.) during SLAM mapping
2. **Navigates to labeled locations** with simple commands like `go_to Point_B`
3. **Localizes itself** using AMCL and saved maps
4. **Avoids obstacles** autonomously using Nav2

**Key Features:**
- ✅ Zero manual waypoint marking (fully automatic!)
- ✅ User-friendly labels (no coordinate math needed)
- ✅ Time/distance-based waypoint generation
- ✅ Complete Nav2 integration with AMCL localization
- ✅ Simple command-line interface

---

## 📋 Table of Contents

1. [System Architecture](#system-architecture)
2. [Phase 1: Mapping with Auto-Waypoints](#phase-1-mapping-with-auto-waypoints)
3. [Phase 2: Autonomous Navigation](#phase-2-autonomous-navigation)
4. [Command Reference](#command-reference)
5. [Configuration](#configuration)
6. [Troubleshooting](#troubleshooting)
7. [File Structure](#file-structure)

---

## 🏗️ System Architecture

### Mapping Phase
```
Robot Explores → SLAM builds map → Auto-waypoint generator creates labels
                                   ↓
                        Saves: map.pgm + map.yaml + map_waypoints.yaml
```

### Navigation Phase
```
User: "go_to Point_B"
    ↓
Waypoint Navigator: Lookup Point_B coordinates
    ↓
Nav2: Plan path from current location to Point_B
    ↓
AMCL: Localize robot on map ("where am I?")
    ↓
Local Planner: Send velocity commands to avoid obstacles
    ↓
Motor Controller: Drive robot to destination ✓
```

---

## 📍 Phase 1: Mapping with Auto-Waypoints

### Step 1: Start Mapping

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot mapping.launch.py
```

**What happens:**
- Robot starts exploring autonomously
- SLAM builds map in real-time
- **Auto-waypoint generator creates labels every 15-20 seconds OR 2-3 meters**
- You'll see logs like:
  ```
  [INFO] ✓ Created Point_A at (0.00, 0.00, 0.00) [start]
  [INFO] ✓ Created Point_B at (2.30, 1.50, 1.57) [16.2s elapsed]
  [INFO] ✓ Created Point_C at (4.10, 3.20, 0.00) [2.7m traveled]
  ```

### Step 2: Activate SLAM (in new terminal)

```bash
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate
```

### Step 3: Let Robot Explore

Watch the robot explore for **3-5 minutes** (or however long needed for your area).

**Monitor progress:**
```bash
# See current waypoints being created
ros2 topic echo /auto_waypoint_generator/status

# Visualize in RViz (optional)
rviz2
# Add displays: Map, LaserScan, TF, RobotModel
```

### Step 4: Save Map and Waypoints

When mapping is complete:

```bash
# Stop the robot (Ctrl+C in mapping terminal)

# Save map with name
cd ~/SLAM/slam_ws
python3 src/slam_robot/scripts/save_map.py my_office_map
```

**Output:**
```
=== Map Saved Successfully ===
Files created:
  - my_office_map.pgm
  - my_office_map.png
  - my_office_map.yaml
  - my_office_map_waypoints.yaml  ← Auto-generated waypoints!

✓ 12 waypoints saved: Point_A through Point_L
```

### Step 5: Verify Waypoints

```bash
# View saved waypoints
cat ~/slam_maps/my_office_map_waypoints.yaml
```

**Example output:**
```yaml
map_name: my_office_map
generation_mode: automatic_time_distance
interval_time_seconds: 15.0
interval_distance_meters: 2.5
total_waypoints: 12

waypoints:
  - label: Point_A
    x: 0.0
    y: 0.0
    theta: 0.0
  - label: Point_B
    x: 2.3
    y: 1.5
    theta: 1.57
  # ... etc
```

---

## 🧭 Phase 2: Autonomous Navigation

### Step 1: Launch Navigation System

```bash
cd ~/SLAM/slam_ws
source install/setup.bash
ros2 launch slam_robot navigation.launch.py map:=my_office_map
```

**What starts:**
- Map server (loads your saved map)
- AMCL localization
- Nav2 navigation stack
- Waypoint navigator
- All sensor nodes (lidar, IMU, odometry)
- Motor controller

### Step 2: Set Initial Pose (IMPORTANT!)

AMCL needs to know robot's starting location. Two options:

#### Option A: Using RViz (Recommended)

```bash
# In new terminal
rviz2
```

1. Add display: **Map** → Topic: `/map`
2. Add display: **LaserScan** → Topic: `/scan`
3. Add display: **PoseArray** → Topic: `/particlecloud` (see AMCL particles)
4. Click **"2D Pose Estimate"** button (top toolbar)
5. Click where robot **actually is** on the map
6. Drag to set orientation
7. Watch particles converge around robot location ✓

#### Option B: Using Command Line

```bash
ros2 topic pub --once /initialpose geometry_msgs/msg/PoseWithCovarianceStamped '{
  header: {frame_id: "map"},
  pose: {
    pose: {
      position: {x: 0.0, y: 0.0, z: 0.0},
      orientation: {x: 0.0, y: 0.0, z: 0.0, w: 1.0}
    },
    covariance: [0.25, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.25, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.068]
  }
}'
```

### Step 3: List Available Waypoints

```bash
ros2 run slam_robot list_waypoints
```

**Output:**
```
============================================================
Available Waypoints (12 total):
============================================================
  Point_A      → (  0.00,   0.00,  0.00 rad)
  Point_B      → (  2.30,   1.50,  1.57 rad)
  Point_C      → (  4.10,   3.20,  0.00 rad)
  Point_D      → (  6.20,   2.80,  3.14 rad)
  ...
============================================================
```

### Step 4: Navigate to Waypoints!

```bash
# Go to Point_B
ros2 run slam_robot go_to Point_B

# Go to Point_F
ros2 run slam_robot go_to Point_F

# Return to start (Point_A)
ros2 run slam_robot go_to Point_A
```

**What you'll see:**
```
============================================================
✓ Navigation goal sent: Point_B
  Target: (2.30, 1.50, 1.57 rad)
============================================================
  Watch robot navigate in RViz or check /goal_pose topic
```

### Step 5: Monitor Navigation (Optional)

```bash
# Watch robot's current pose
ros2 topic echo /amcl_pose

# Watch navigation goals
ros2 topic echo /goal_pose

# Watch velocity commands
ros2 topic echo /cmd_vel

# Check navigation status
ros2 topic echo /navigate_to_pose/_action/status
```

---

## 📖 Command Reference

### Mapping Commands

```bash
# Start mapping with auto-waypoint generation
ros2 launch slam_robot mapping.launch.py

# Activate SLAM (in separate terminal after launch)
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# Save map and waypoints
python3 src/slam_robot/scripts/save_map.py <map_name>

# View waypoint file
cat ~/slam_maps/<map_name>_waypoints.yaml
```

### Navigation Commands

```bash
# Launch navigation with specific map
ros2 launch slam_robot navigation.launch.py map:=<map_name>

# List available waypoints
ros2 run slam_robot list_waypoints

# Navigate to a waypoint
ros2 run slam_robot go_to Point_A
ros2 run slam_robot go_to Point_B
# ... etc

# Set initial pose (if not using RViz)
ros2 topic pub --once /initialpose geometry_msgs/msg/PoseWithCovarianceStamped '...'
```

### Monitoring Commands

```bash
# View active nodes
ros2 node list

# Check AMCL status
ros2 node info /amcl

# View transforms
ros2 run tf2_ros tf2_echo map base_footprint

# Monitor topics
ros2 topic list
ros2 topic hz /scan
ros2 topic echo /amcl_pose
```

---

## ⚙️ Configuration

### Waypoint Generation Parameters

Edit in `launch/mapping.launch.py`:

```python
auto_waypoint_generator = Node(
    parameters=[{
        'waypoint_interval_time': 15.0,      # Seconds between waypoints
        'waypoint_interval_distance': 2.5,   # Meters between waypoints
        'min_distance_between_waypoints': 0.5,  # Minimum spacing
    }]
)
```

**Presets:**

| Use Case | Time (s) | Distance (m) | Result |
|----------|----------|--------------|--------|
| Dense coverage | 10 | 2.0 | More waypoints |
| Balanced (default) | 15 | 2.5 | Good coverage |
| Sparse coverage | 30 | 5.0 | Fewer waypoints |

### AMCL Localization Parameters

Edit `config/amcl_params.yaml`:

```yaml
amcl:
  ros__parameters:
    min_particles: 500        # Increase for better localization
    max_particles: 2000       # Decrease to save CPU
    update_min_d: 0.1         # Update every 10cm
    update_min_a: 0.2         # Update every 0.2 rad
    laser_max_beams: 60       # Increase for better accuracy
    odom_alpha1: 0.2          # Odometry noise (tune if drifting)
```

### Navigation Parameters

Edit `config/nav2_params.yaml`:

```yaml
controller_server:
  FollowPath:
    max_vel_x: 0.3            # Max forward speed (m/s)
    max_vel_theta: 1.0        # Max rotation speed (rad/s)
    xy_goal_tolerance: 0.15   # Goal reached threshold

local_costmap:
  local_costmap:
    width: 3                  # Local costmap size (meters)
    height: 3
    resolution: 0.05          # Grid resolution

global_costmap:
  global_costmap:
    resolution: 0.05          # Must match map resolution
    robot_radius: 0.15        # Safety buffer around robot
```

---

## 🔧 Troubleshooting

### Problem: No waypoints created during mapping

**Symptoms:**
- Mapping runs but no "Created Point_X" messages
- No `_waypoints.yaml` file after saving

**Solutions:**
1. Check auto_waypoint_generator is running:
   ```bash
   ros2 node list | grep auto_waypoint
   ```
2. Check if pose topic is publishing:
   ```bash
   ros2 topic hz /pose
   ros2 topic hz /odometry/filtered
   ```
3. Restart mapping and ensure SLAM is activated:
   ```bash
   ros2 lifecycle set /slam_toolbox configure
   ros2 lifecycle set /slam_toolbox activate
   ```

---

### Problem: Robot doesn't localize (AMCL particles scattered)

**Symptoms:**
- Particles spread across entire map
- Robot position jumps around
- Navigation fails immediately

**Solutions:**
1. **Set initial pose** accurately in RViz (2D Pose Estimate)
2. Drive robot around a bit to let AMCL converge
3. Increase particle count in `amcl_params.yaml`:
   ```yaml
   min_particles: 1000
   max_particles: 5000
   ```
4. Check lidar is working:
   ```bash
   ros2 topic hz /scan  # Should be ~8 Hz
   ```

---

### Problem: "Unknown waypoint: Point_B"

**Symptoms:**
- `go_to` command fails
- Error: "Unknown waypoint"

**Solutions:**
1. List available waypoints:
   ```bash
   ros2 run slam_robot list_waypoints
   ```
2. Check waypoints file exists:
   ```bash
   ls ~/slam_maps/<map_name>_waypoints.yaml
   ```
3. Verify map name matches in launch command:
   ```bash
   ros2 launch slam_robot navigation.launch.py map:=<correct_map_name>
   ```

---

### Problem: Robot plans path but doesn't move

**Symptoms:**
- Goal accepted, path shown in RViz
- Robot stays still

**Solutions:**
1. Check motor controller is running:
   ```bash
   ros2 node list | grep motor_controller
   ```
2. Check velocity commands are being published:
   ```bash
   ros2 topic hz /cmd_vel
   ros2 topic echo /cmd_vel
   ```
3. Check for GPIO permission errors in motor_controller logs
4. Verify wheels can spin (not stuck/obstructed)

---

### Problem: Robot navigates but crashes into obstacles

**Symptoms:**
- Path planning works
- Robot ignores obstacles

**Solutions:**
1. Check lidar data in costmap:
   ```bash
   ros2 topic echo /local_costmap/costmap
   ```
2. Increase inflation radius in `nav2_params.yaml`:
   ```yaml
   inflation_layer:
     inflation_radius: 0.50  # Increase from 0.35
   ```
3. Reduce max velocity:
   ```yaml
   max_vel_x: 0.2  # Slower = more reaction time
   ```

---

### Problem: Navigation too slow/cautious

**Symptoms:**
- Robot moves very slowly
- Takes long time to reach goal

**Solutions:**
1. Increase velocity limits in `nav2_params.yaml`:
   ```yaml
   max_vel_x: 0.4  # Increase from 0.3
   max_vel_theta: 1.5  # Increase from 1.0
   ```
2. Decrease inflation radius:
   ```yaml
   inflation_radius: 0.25  # Smaller safety buffer
   ```
3. Tune DWB planner parameters:
   ```yaml
   PathDist.scale: 48.0  # Follow path more aggressively
   ```

---

## 📁 File Structure

```
~/SLAM/slam_ws/src/slam_robot/
├── slam_robot/
│   ├── auto_waypoint_generator.py    ← NEW: Auto-creates waypoints
│   ├── waypoint_navigator.py         ← NEW: Navigate to labels
│   ├── motor_controller.py
│   ├── odometry_publisher.py
│   ├── imu_publisher.py
│   └── obstacle_avoidance.py
│
├── scripts/
│   ├── save_map.py                   ← UPDATED: Saves map + waypoints
│   ├── go_to.py                      ← NEW: CLI navigation command
│   └── list_waypoints.py             ← NEW: List available waypoints
│
├── launch/
│   ├── mapping.launch.py             ← UPDATED: Added waypoint generator
│   ├── navigation.launch.py          ← NEW: Full navigation stack
│   ├── rplidar.launch.py
│   └── slam_toolbox.launch.py
│
├── config/
│   ├── slam_toolbox_params.yaml
│   ├── amcl_params.yaml              ← NEW: AMCL localization config
│   └── nav2_params.yaml              ← NEW: Nav2 navigation config
│
├── urdf/
│   └── robot.urdf
│
└── setup.py                          ← UPDATED: New nodes registered

~/slam_maps/
├── my_office_map.pgm                 ← Map image
├── my_office_map.yaml                ← Map metadata
└── my_office_map_waypoints.yaml      ← Auto-generated waypoints!
```

---

## 🎓 How It Works

### Auto-Waypoint Generation Algorithm

```python
Every 1 second:
    Get current robot position from SLAM

    If (time >= 15 sec OR distance >= 2.5m) AND distance > 0.5m from last:
        Create waypoint with label Point_X
        Save position (x, y, theta)
        Increment counter

    Continue until mapping stops

On shutdown:
    Save all waypoints to YAML file
```

### Navigation Flow

```
1. User: ros2 run slam_robot go_to Point_B

2. Waypoint Navigator:
   - Reads waypoints YAML
   - Finds Point_B → (2.3, 1.5, 1.57)
   - Publishes to /goal_pose

3. Nav2 BT Navigator:
   - Receives goal
   - Triggers global planner

4. Global Planner:
   - Uses map costmap
   - Plans path: current → goal
   - Returns waypoint list

5. Local Planner (DWB):
   - Follows global path
   - Avoids dynamic obstacles
   - Sends /cmd_vel

6. Motor Controller:
   - Receives /cmd_vel
   - Drives motors
   - Robot moves!

7. AMCL:
   - Continuously localizes robot
   - Updates map→odom transform
   - Ensures accurate position

8. Loop until goal reached ✓
```

---

## 📊 Performance Tips

### For Better Localization
- Provide accurate initial pose
- Map should have distinctive features (not empty corridor)
- Drive slowly at first to let AMCL converge
- Increase particle count if environment is symmetric

### For Faster Navigation
- Increase velocity limits (but test safely!)
- Reduce costmap resolution (0.10m instead of 0.05m)
- Decrease DWB trajectory samples

### For Safer Navigation
- Increase inflation radius
- Lower velocity limits
- Add ultrasonic sensor to obstacle layer
- Tune costmap obstacle marking

---

## 🚀 Next Steps

### Add Custom Waypoint Names

Edit generated waypoints file to add meaningful names:

```yaml
waypoints:
  - label: Point_A
    alias: "Kitchen"      # Add this!
    x: 0.0
    y: 0.0
```

Then modify `waypoint_navigator.py` to support:
```bash
ros2 run slam_robot go_to Kitchen
```

### Multi-Floor Navigation

Save separate maps per floor:
```bash
python3 scripts/save_map.py floor1
python3 scripts/save_map.py floor2
```

Launch with specific floor:
```bash
ros2 launch slam_robot navigation.launch.py map:=floor1
```

### Waypoint Sequences

Create mission files:
```yaml
# patrol_mission.yaml
waypoints:
  - Point_A
  - Point_C
  - Point_F
  - Point_A  # Return home
```

Implement mission executor to visit all in sequence.

---

## 📞 Support

**Issues:**
- Check logs: `ros2 node list` and individual node info
- Verify topics: `ros2 topic list` and `ros2 topic hz <topic>`
- Test sensors individually before full navigation

**Common Log Locations:**
- `~/.ros/log/` - ROS2 logs
- Check node output for errors during launch

**Additional Resources:**
- Nav2 Documentation: https://navigation.ros.org/
- AMCL Tutorial: http://wiki.ros.org/amcl
- SLAM Toolbox: https://github.com/SteveMacenski/slam_toolbox

---

## ✅ Quick Start Summary

### Mapping Phase
```bash
# 1. Start mapping
ros2 launch slam_robot mapping.launch.py

# 2. Activate SLAM (new terminal)
ros2 lifecycle set /slam_toolbox configure
ros2 lifecycle set /slam_toolbox activate

# 3. Wait 3-5 minutes for exploration

# 4. Save map
python3 src/slam_robot/scripts/save_map.py my_map
```

### Navigation Phase
```bash
# 1. Launch navigation
ros2 launch slam_robot navigation.launch.py map:=my_map

# 2. Set initial pose in RViz (2D Pose Estimate)

# 3. List waypoints
ros2 run slam_robot list_waypoints

# 4. Navigate!
ros2 run slam_robot go_to Point_B
```

---

**🎉 Congratulations! You now have a fully autonomous label-based navigation system!**

The robot can map environments, auto-generate waypoints, and navigate to labeled locations with simple commands. No manual waypoint marking or coordinate calculations needed!

---

*Wraith Robot Navigation System v1.0*
*Auto-Waypoint Generation + AMCL Localization + Nav2 Integration*
